var flightIdFromService;
var flightIdval;
var poc3JsonData;
var poc3NewArray;
var airborneDtoList;
var groundDtoList;
var dynamicFlightIdForPoc3;
var pocDatatable;
var totalFlightDataList;
var multipleArrayPoc3=[];
var pressureAltitudeArray;
var airspeedArray;
var multiParamsDataArrayPoc3;
var chartTitlesArrayPoc3;
var takeoffTime;
var landingTime;
var clusterFlightId;
var clusterData;
var verticalAccelartion;
var clusterArray1;
var clusterArray2;
var clusterArray3;
var clusterArray4;
var clusterArray5;
var fireFlightMaxRange = '';
var cargoFlightMaxRange='';
var yasixToRangeMax = '';
 $(document).ready(function () {
		$("#analyticId").click(function(){
		  $(".greyBar").css("visibility", "visible");
		  $(".topDiv").css("visibility", "visible");
		  $(".homecontent").css("visibility", "hidden");
		  $(".loadingChart5").css("visibility", "visible");
		  loadFlightId();
		   
		   if (pocDatatable != null){
				pocDatatable.fnDestroy();
			}
		    $("#container6").hide();
			$("#airbornesegmentTableId").hide();
			$("#airtakeoff").html(0);
			$("#airtakeoffLanding").html(0);
			$("#airborneflightsegment").html(0);
		    $("#flightIdPoc3").val(0);
	 })
	 
	 
		$("#flightId").change(function(){
			if($("#flightSegmentationTab").parent().hasClass("active")) {
			$("#container6").html('');
			$("#segmentationId").val(0);
			$(".loadingChart5").css("visibility", "visible");
			$(".taborder").css("visibility", "visible");
			if (pocDatatable != null){
				pocDatatable.fnDestroy();
			}
			flightIdval=$(this).val();
		 
			getjsonDataForPoc3(flightIdval);
		
			$("#flightSegmentationTimeDetails").css("visibility", "visible");
			$("#flightSegmentationTableDetails").css("visibility", "visible");
			$("#flightsegmentationSelectDiv").css("visibility", "visible");
      }

			
	else if($("#flightDataGraph").parent().hasClass("active")){
                                                alert(".....2.......");
    }
    else if($("#clusterTab11").parent().hasClass("active")){
                                                alert(".....3.......");
    }
   else if($("#regressionTab11").parent().hasClass("active")){
                                                alert(".....4.......");
   }
	
		
	
}); 
	 
	 
	 
	 
	 
	 
	 
	 
	 
 })
 
 
 function loadFlightId(){
	var predixurl="https://predix-aircraft-demo3.run.aws-usw02-pr.ice.predix.io/getFlightIds";
				$.ajax({
				url:predixurl,
                type: "get", //send it through post method
                success: function(responseData) {
					
					flightIdFromService=responseData;
				 $(".loadingChart5").css("visibility", "hidden");
				$('#flightId').find('option:not(:first)').remove();
			for (var i = 0; i < flightIdFromService.length; i++) {
					$('#flightId').append($('<option>', { 
						value: JSON.stringify(flightIdFromService[i].flightId),
						text : 'TM-'+JSON.stringify(flightIdFromService[i].flightId)
				}));
           }
				},
                error: function ( xhr, status, error) {
				$("#loadingChart5").hide();
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				}
				});

}
 
 