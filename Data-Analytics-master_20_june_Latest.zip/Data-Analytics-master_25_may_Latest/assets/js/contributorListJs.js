 $(document).ready(function () {
	/*var predixurl="https://data-analytic-service-25thmay.run.aws-usw02-pr.ice.predix.io/data-analytic/getAllContributorList";
	
		     $.ajax({
		          url:predixurl,
                  type: "GET", //send it through GET method
                  success: function(responseData) {
                   /// alert(responseData.status);
					
						for (var i = 0; i < responseData.object.length; i++) {
					$('#sel1').append($('<option>', { 
						value: JSON.stringify(responseData.object[i].trim()),
						text : JSON.stringify(responseData.object[i].trim())
				}));
				}
					
					
					
					
     		     },
                 error: function ( xhr, status, error) {
				   console.log("Error while fetching Automation tracker data.");
	             }
		     });*/
			 
			 
   $("#contributorNameIdList").change(function () {	
   
   
	 var data=$(this).val();
	var predixurl="https://data-analytic-service-25thmay.run.aws-usw02-pr.ice.predix.io/data-analytic/getRewardDetailsForContriutor";
	
		     $.ajax({
		          url:predixurl+"/"+data,
                  type: "GET", //send it through GET method
                  success: function(responseData) {
                   alert(responseData);
					
						for (var i = 0; i < responseData.length; i++) {
							if(i==0){
								$("#businessName").html(responseData[0].businessName);
								$("#contributorNameId").html(responseData[0].contributorName);
							}
							
							$("#projectnameId").html(responseData[0].projectName);
				
						}
					
					
					
					
     		     },
                 error: function ( xhr, status, error) {
				   console.log("Error while fetching Automation tracker data.");
	             }
		     });

   });   
		 
	 
 });