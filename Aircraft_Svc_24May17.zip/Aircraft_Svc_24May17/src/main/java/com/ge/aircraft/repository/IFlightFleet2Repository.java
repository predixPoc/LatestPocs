package com.ge.aircraft.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.ge.aircraft.entity.FleetData2;

public interface IFlightFleet2Repository extends JpaRepository<FleetData2, Long> ,JpaSpecificationExecutor<FleetData2>, PagingAndSortingRepository<FleetData2, Long>{

	/*String GET_FLIGHT_DETAILS = "select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId  and a.flightMaster.startDate=?1 and a.flightMaster.startTime=?2 and a.recordType=?3 and a.triggerChannel=?4 and a.timestamp between ?5 and ?6 ";
*/
	
	String GET_FLIGHT_DETAILS = "select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.strainGauge9,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData2 a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId and a.flightMaster.startDate=?1 and a.flightMaster.startTime=?2 and a.recordType=?3 and a.triggerChannel=?4 ";
	//List<FlightMaster> findByStartDate(String startdate);
	
	String GET_FLIGHT_DETAILS_FLIGHTDT_TIME = "select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.strainGauge9,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData2 a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId and a.flightMaster.startDate=?1 and a.flightMaster.startTime=?2 ";

	String GET_FLIGHT_DETAILS_FLIGHTDT_TIME_RECORDTYPE = "select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.strainGauge9,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData2 a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId and a.flightMaster.startDate=?1 and a.flightMaster.startTime=?2 and a.recordType=?3";

	String GET_FLIGHT_DETAILS_FLIGHTDT_TIME_RECORDTYPE_TR ="select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.strainGauge9,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData2 a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId and a.flightMaster.startDate=?1 and a.flightMaster.startTime=?2 and a.recordType=?3 and a.triggerChannel=?4 ";
	
	
	String GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_TR_ENDTIME =  "select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.strainGauge9,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData2 a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId and a.flightMaster.startDate=?1 and a.flightMaster.startTime=?2 and a.recordType=?3 and a.triggerChannel=?4 ";

	String GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_TR_STARTTIME ="select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.strainGauge9,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData2 a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId and a.flightMaster.startDate=?1 and a.flightMaster.startTime=?2 and a.recordType=?3 and a.triggerChannel=?4 ";
	
	String GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_TR_WITHOUTTIME = "select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.strainGauge9,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData2 a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId and a.flightMaster.startDate=?1 and a.flightMaster.startTime=?2 and a.recordType=?3 and a.triggerChannel=?4 ";

	String GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_PE_ENDTIME = "select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.strainGauge9,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData2 a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId and a.flightMaster.startDate=?1 and a.flightMaster.startTime=?2 and a.recordType=?3  ";
	
	String GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_PE_STARTTIME = "select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.strainGauge9,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData2 a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId and a.flightMaster.startDate=?1 and a.flightMaster.startTime=?2 and a.recordType=?3 ";
	
	String GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_PE_WITHOUTTIME = "select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.strainGauge9,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData2 a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId and a.flightMaster.startDate=?1 and a.flightMaster.startTime=?2 and a.recordType=?3 ";

	String GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_TR_WITHTIME = "select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.strainGauge9,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData2 a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId and a.flightMaster.startDate=?1 and a.flightMaster.startTime=?2 and a.recordType=?3 and a.triggerChannel=?4 ";
	
	String GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_PE_WITHTIME = "select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.strainGauge9,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData2 a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId and a.flightMaster.startDate=?1 and a.flightMaster.startTime=?2 and a.recordType=?3 ";

	/*@Query(GET_FLIGHT_DETAILS)
	List<Object[]> getFlightDetails(@Param("startDate")  String startDate, @Param("startTime")  String startTime,
			@Param("recordType")  String recordType, @Param("triggerChannel") String triggerChannel,  @Param("startTimes")  String startTimes,
			 @Param("endTime")  String endTime);*/
	
	@Query(GET_FLIGHT_DETAILS + "  and  a.timestamp between ?5 and ?6")
	List<Object[]> getFlightDetails(String flightDate, String flightTime,
			String recordType, BigDecimal triggerChannel, String startTime,
			String endTime);

	@Query(GET_FLIGHT_DETAILS)
	List<Object[]> getFlightDetailss();

	@Query(GET_FLIGHT_DETAILS_FLIGHTDT_TIME)
	List<Object[]> getFlightDtlsFDateTimeFilter(String flightDate,
			String flightTime);

	@Query(GET_FLIGHT_DETAILS_FLIGHTDT_TIME_RECORDTYPE)
	List<Object[]> getFlightDtlsFDateTimeRecordTypeFilter(String flightDate,
			String flightTime, String recordType);



	@Query(GET_FLIGHT_DETAILS_FLIGHTDT_TIME_RECORDTYPE_TR)
	List<Object[]> getFlightDtlsFDateTimeRecordTypeTRFilter(String flightDate,
			String flightTime, String recordType,BigDecimal triggerChannel);
	
/*	@Query("select a from FleetData2 a, FlightMaster b where a.flightMaster.flightId = b.flightId and a.flightMaster.flightId = ?1 order by a.timestamp asc")
	List<FleetData2> getFlightPlottingData(long flightId);*/

	
	@Query(GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_TR_ENDTIME + "  and  a.timestamp < ?5 ")
	List<Object[]> getFlDtlsTREndTime(String flightDate, String flightTime,
			String recordType, BigDecimal triggerChannel, String endTime);

	@Query(GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_TR_STARTTIME + "  and  a.timestamp > ?5 ")
	List<Object[]> getFlDtlsTRStartTime(String flightDate, String flightTime,
			String recordType, BigDecimal triggerChannel, String startTime);

	
	@Query(GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_TR_WITHOUTTIME)
	List<Object[]> getFlDtlsTRWithoutTime(String flightDate, String flightTime,
			String recordType, BigDecimal triggerChannel);

	
	@Query(GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_PE_ENDTIME + "  and  a.timestamp < ?5 ")
	List<Object[]> getFlDtlsPEEndTime(String flightDate, String flightTime,
			String recordType, String endTime);

	@Query(GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_PE_STARTTIME + "  and  a.timestamp > ?5 ")
	List<Object[]> getFlDtlsPEStartTime(String flightDate, String flightTime,
			String recordType, String startTime);

	@Query(GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_PE_WITHOUTTIME)
	List<Object[]> getFlDtlsPEWithoutTime(String flightDate, String flightTime,
			String recordType);

	@Query(GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_TR_WITHTIME + "  and  a.elapsedTime between ?5 and ?6 ")
	List<Object[]> getFlDtlsTRWithBothTime(String flightDate,
			String flightTime, String recordType, BigDecimal triggerChannel,
			Double startTime, Double endTime);

	@Query(GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_PE_WITHTIME + "  and  a.elapsedTime between ?4 and ?5 ")
	List<Object[]> getFlDtlsPEWithTime(String flightDate, String flightTime,
			String recordType,Double startTime, Double endTime);
	
	String GET_FLIGHT_DTLS_FLIGHTDT_TIME_WITHOUT_RECORDTYPE_WITHTIME = "select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.strainGauge9,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData2 a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId and a.flightMaster.startDate=?1 and a.flightMaster.startTime=?2 ";

	
	
    @Query("select a from FleetData2 a where a.flightMaster.flightId = ?1 ")
List<FleetData2> getFlightPlottingData(long flightId);

    @Query("select a from FleetData2 a where a.flightMaster.flightId = ?1 and a.elapsedTime between ?2 and ?3 ")
List<FleetData2> getFlightPlottingDataElapsedTime(long flightId, Double startElapsedTime, Double endElapsedTime);
    
    @Query("select max(elapsedTime) as maxElapsedTime, min(elapsedTime) as minElapsedTime from FleetData2  where flight_id = ?1")
    List<Object[]> getFlightMinMaxElapsedTime(long flightId);
    
    
    @Query(GET_FLIGHT_DTLS_FLIGHTDT_TIME_WITHOUT_RECORDTYPE_WITHTIME + "  and  a.elapsedTime between ?3 and ?4 ")
	List<Object[]> getFlDtlsWithBothTime(String flightDate, String flightTime,
			Double startElapsedTm, Double endElapsedTm);
	
    //rakesh : 24-Apr-17 : start
	@Query("select max(elapsedTime) as maxElapsedTime, min(elapsedTime) as minElapsedTime from FleetData2 where flight_id in (?1)")
    List<Object[]> getFlightsMaxElapsedTime(List<Long> flightIdsList);
    
    String GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_TR_ENDTIME2 =  "select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.strainGauge9,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData2 a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId and a.flightMaster.flightId in (?1) and a.recordType=?2 and a.triggerChannel=?3 ";
    
    @Query(GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_TR_ENDTIME2 + "  and  a.elapsedTime < ?4 ")
	List<Object[]> getFlDtlsTREndTime2(List<Long> flightIdsList, String recordType, BigDecimal triggerChannel, Double endTime);
	
	String GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_TR_STARTTIME2 ="select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.strainGauge9,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData2 a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId and a.flightMaster.flightId in (?1) and a.recordType=?2 and a.triggerChannel=?3 ";
	
	@Query(GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_TR_STARTTIME2 + "  and  a.elapsedTime > ?4 ")
	List<Object[]> getFlDtlsTRStartTime2(List<Long> flightIdsList, String recordType, BigDecimal triggerChannel, Double startTime);
	
	String GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_TR_WITHOUTTIME2 = "select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.strainGauge9,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData2 a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId and a.flightMaster.flightId in (?1) and a.recordType=?2 and a.triggerChannel=?3 ";
	
	@Query(GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_TR_WITHOUTTIME2)
	List<Object[]> getFlDtlsTRWithoutTime2(List<Long> flightIdsList, String recordType, BigDecimal triggerChannel);
	
	String GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_TR_WITHTIME2 = "select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.strainGauge9,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData2 a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId and a.flightMaster.flightId in (?1) and a.recordType=?2 and a.triggerChannel=?3 ";
	
	@Query(GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_TR_WITHTIME2 + "  and  a.elapsedTime between ?4 and ?5 ")
	List<Object[]> getFlDtlsTRWithBothTime2(List<Long> flightIdsList, String recordType, BigDecimal triggerChannel,
			Double startTime, Double endTime);
	
	String GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_PE_ENDTIME2 = "select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.strainGauge9,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData2 a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId and a.flightMaster.flightId in (?1) and a.recordType=?2  ";
	
	@Query(GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_PE_ENDTIME2 + "  and  a.elapsedTime < ?3 ")
	List<Object[]> getFlDtlsPEEndTime2(List<Long> flightIdsList, String recordType, Double endTime);
	
	String GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_PE_STARTTIME2 = "select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.strainGauge9,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData2 a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId and a.flightMaster.flightId in (?1) and a.recordType=?2 ";
	
	@Query(GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_PE_STARTTIME2 + "  and  a.elapsedTime > ?3 ")
	List<Object[]> getFlDtlsPEStartTime2(List<Long> flightIdsList,String recordType, Double startTime);
	
	String GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_PE_WITHOUTTIME2 = "select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.strainGauge9,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData2 a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId and a.flightMaster.flightId in (?1) and a.recordType=?2 ";
	
	@Query(GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_PE_WITHOUTTIME2)
	List<Object[]> getFlDtlsPEWithoutTime2(List<Long> flightIdsList,String recordType);
	
	String GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_PE_WITHTIME2 = "select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.strainGauge9,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData2 a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId and a.flightMaster.flightId in (?1) and a.recordType=?2 ";
	
	@Query(GET_FLIGHT_DTLS_FLIGHTDT_TIME_RECORDTYPE_PE_WITHTIME2 + "  and  a.elapsedTime between ?3 and ?4 ")
	List<Object[]> getFlDtlsPEWithTime2(List<Long> flightIdsList,String recordType,Double startTime, Double endTime);
	
	String GET_FLIGHT_DTLS_FLIGHTDT_TIME_WITHOUT_RECORDTYPE_WITHTIME2 = "select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.strainGauge9,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData2 a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId and a.flightMaster.flightId in (?1) ";
	
	@Query(GET_FLIGHT_DTLS_FLIGHTDT_TIME_WITHOUT_RECORDTYPE_WITHTIME2 + "  and  a.elapsedTime between ?2 and ?3 ")
	List<Object[]> getFlDtlsWithBothTime2(List<Long> flightIdsList,Double startElapsedTm, Double endElapsedTm);	
	
	//rakesh : 24-Apr-17 : end
	
	//24-May-17 : Get all Flight's data from both DB tables : start
	String GET_ALL_FLIGHTS_DATA = "select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.strainGauge9,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId,b.start_timestamp from FleetData2 a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId";
	
	@Query(GET_ALL_FLIGHTS_DATA)
	List<Object[]> getAllFlightsData2();
	//24-May-17 : Get all Flight's data from both DB tables : end

}