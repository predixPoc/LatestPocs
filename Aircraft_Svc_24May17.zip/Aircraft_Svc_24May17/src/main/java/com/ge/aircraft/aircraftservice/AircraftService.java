package com.ge.aircraft.aircraftservice;

import java.io.StringWriter;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ge.aircraft.dto.FleetData2DTO;
import com.ge.aircraft.dto.FlightMasterDTO;
import com.ge.aircraft.dto.RegressionCalDTO;
import com.ge.aircraft.entity.FleetData2;
import com.ge.aircraft.entity.FlightMaster;
import com.ge.aircraft.repository.IFlightFleet2Repository;
import com.ge.aircraft.repository.IFlightMasterRepository;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;

@RestController
public class AircraftService {

	@Autowired
	private IFlightMasterRepository flightMasterRepo;

	@Autowired
	private IFlightFleet2Repository filghtFleetrepo2;
	
	//24-May-17 : Get all Flight's data from both DB tables : start
	@RequestMapping(value = "/getAllFlightsData2", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<Map<String, Object>> getAllFlightsData2() {
		
		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		List<Object[]> retList = null;
		
		String dbTimestampPattern = "yyyy-MM-dd hh:mm:ss";	//2004-06-26 22:49:18
		SimpleDateFormat dbTimestampFmt = new SimpleDateFormat(dbTimestampPattern);
		
		try {
			
			retList = filghtFleetrepo2.getAllFlightsData2();
			
			for (int i = 0; i < retList.size(); i++) {

				objMap = new HashMap<String, Object>();
				objMap.put("fleetId", (retList.get(i))[0]);
				objMap.put("airspeed", (retList.get(i))[1]);
				objMap.put("armRetardantTankDoor", (retList.get(i))[2]);
				objMap.put("beaconStartStopRecording", (retList.get(i))[3]);
				objMap.put("elapsedTime", (retList.get(i))[4]);
				objMap.put("elevatorPosition", (retList.get(i))[5]);
				objMap.put("flapPosition", (retList.get(i))[6]);
				objMap.put("gearUpAndLocked", (retList.get(i))[7]);
				objMap.put("leftAileronPosition", (retList.get(i))[8]);
				objMap.put("peakValleyIndicator", (retList.get(i))[9]);
				objMap.put("pressureAltitude", (retList.get(i))[10]);
				objMap.put("recordType", (retList.get(i))[11]);
				objMap.put("retardantDoorOpen", (retList.get(i))[12]);
				objMap.put("retardantTankFloat", (retList.get(i))[13]);
				objMap.put("rollAcceleration", (retList.get(i))[14]);
				objMap.put("strainGauge1", (retList.get(i))[15]);
				objMap.put("strainGauge2", (retList.get(i))[16]);
				objMap.put("strainGauge3", (retList.get(i))[17]);
				objMap.put("strainGauge4", (retList.get(i))[18]);
				objMap.put("strainGauge5", (retList.get(i))[19]);
				objMap.put("strainGauge6", (retList.get(i))[20]);
				objMap.put("strainGauge7", (retList.get(i))[21]);
				objMap.put("strainGauge8", (retList.get(i))[22]);
				objMap.put("strainGauge9", (retList.get(i))[23]);
				objMap.put("timestamp", (retList.get(i))[24]);
				objMap.put("triggerChannel", (retList.get(i))[25]);
				objMap.put("verticalAcceleration", (retList.get(i))[26]);
				objMap.put("startDate", (retList.get(i))[27]);
				objMap.put("startTime", (retList.get(i))[28]);
				objMap.put("flightId", (retList.get(i))[29]);
				objMap.put("startDateTime", dbTimestampFmt.format((Date)(retList.get(i))[30]));

				list.add(objMap);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}	
	//24-May-17 : Get all Flight's data from both DB tables : end
	
	//22-May-17 : Get all flights' Data - start
	@RequestMapping(value = "/getAllFlightsData", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<FleetData2DTO> getAllFlightsData() {

		List<FleetData2DTO> fleetDataList = new ArrayList<FleetData2DTO>();
		FleetData2DTO fleetDataDto = null;
		try {
			System.out.println("AircraftService.getAllFlightsData()");

			List<FleetData2> dataList = (List<FleetData2>) filghtFleetrepo2
					.findAll(new Sort(Sort.Direction.ASC, "flightMaster.flightId"));
			System.out.println("Total number of records fetched from DB="+dataList.size());
			
			for (FleetData2 fleetData : dataList) {
				fleetDataDto = new FleetData2DTO();
				BeanUtils.copyProperties(fleetData, fleetDataDto);
				fleetDataDto.setFlightId(fleetData.getFlightMaster().getFlightId());
				fleetDataList.add(fleetDataDto);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return fleetDataList;
	}	
	//22-May-17 : Get all flights' Data - end

	@RequestMapping(value = "/getFlightTimeStampDetails/{startdate}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<FlightMasterDTO> getFlightTimeStampDetails(
			@PathVariable("startdate") String startdate) {

		List<FlightMasterDTO> aircraftLists = new ArrayList<FlightMasterDTO>();
		FlightMasterDTO flightTimeStamp = null;
		try {
			System.out.println("AircraftService.getFlightTimeStampDetails()");

			List<FlightMaster> dataList = (List<FlightMaster>) flightMasterRepo
					.findByStartDate(startdate);
			for (FlightMaster flightMstr : dataList) {
				flightTimeStamp = new FlightMasterDTO();
				BeanUtils.copyProperties(flightMstr, flightTimeStamp);
				aircraftLists.add(flightTimeStamp);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return aircraftLists;
	}

	@RequestMapping(value = "/view/getFlightDetailsWithDynamicfilter/{flightDate}/{flightTime}/{recordType}/{triggerChannel}/{startTime}/{endTime}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<Map<String, Object>> getFlightDetailsWithDynamicfilter(
			@PathVariable("flightDate") String flightDate,
			@PathVariable("flightTime") String flightTime,
			@PathVariable("recordType") String recordType,
			@PathVariable("triggerChannel") String triggerChannel,
			@PathVariable("startTime") String startTime,
			@PathVariable("endTime") String endTime) {

		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		if (startTime.equalsIgnoreCase("''")) {
			startTime = "";
		}
		if (endTime.equalsIgnoreCase("''")) {
			endTime = "";
		}

		try {
			System.out
					.println("AircraftService.getFlightDetailsWithDynamicfilter()");

			List<Object[]> retList = null;
			Double startElapsedTm = null;
			Double endElapsedTm = null;

			if (startTime != null && !startTime.equalsIgnoreCase("")
					&& !startTime.equalsIgnoreCase("''") && endTime != null
					&& !endTime.equalsIgnoreCase("")
					&& !endTime.equalsIgnoreCase("''")) {

				startElapsedTm = Double.valueOf(startTime);
				endElapsedTm = Double.valueOf(endTime);

			}
			BigDecimal triggerChannelBD = null;

			if (triggerChannel != null && !triggerChannel.equalsIgnoreCase("")
					&& !triggerChannel.equalsIgnoreCase("''")) {

				triggerChannelBD = new BigDecimal(triggerChannel);

			}

			if (null != flightDate && null != flightTime && null != recordType) {
				if (recordType.equalsIgnoreCase("TR")) {

					if (!StringUtils.isNotBlank(startTime)
							&& StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsTREndTime(
								flightDate, flightTime, recordType,
								triggerChannelBD, endTime);
					} else if (!StringUtils.isNotBlank(endTime)
							&& StringUtils.isNotBlank(startTime)) {

						retList = filghtFleetrepo2.getFlDtlsTRStartTime(
								flightDate, flightTime, recordType,
								triggerChannelBD, startTime);
					} else if (!StringUtils.isNotBlank(startTime)
							&& !StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsTRWithoutTime(
								flightDate, flightTime, recordType,
								triggerChannelBD);
					} else if (StringUtils.isNotBlank(startTime)
							&& StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsTRWithBothTime(
								flightDate, flightTime, recordType,
								triggerChannelBD, startElapsedTm, endElapsedTm);

					}

				} else if (recordType.equalsIgnoreCase("PE")) {

					System.out.println("Inside PE:" + triggerChannel);

					if (!StringUtils.isNotBlank(startTime)
							&& StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsPEEndTime(
								flightDate, flightTime, recordType, endTime);
					} else if (!StringUtils.isNotBlank(endTime)
							&& StringUtils.isNotBlank(startTime)) {

						retList = filghtFleetrepo2.getFlDtlsPEStartTime(
								flightDate, flightTime, recordType, startTime);
					} else if (!StringUtils.isNotBlank(startTime)
							&& !StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsPEWithoutTime(
								flightDate, flightTime, recordType);
					} else if (StringUtils.isNotBlank(startTime)
							&& StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsPEWithTime(
								flightDate, flightTime, recordType,
								startElapsedTm, endElapsedTm);
					}

				} else {
					if (StringUtils.isNotBlank(startTime)
							&& StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsWithBothTime(
								flightDate, flightTime, startElapsedTm,
								endElapsedTm);
					}
				}

				for (int i = 0; i < retList.size(); i++) {

					objMap = new HashMap<String, Object>();
					objMap.put("fleetId", (retList.get(i))[0]);
					objMap.put("airspeed", (retList.get(i))[1]);
					objMap.put("armRetardantTankDoor", (retList.get(i))[2]);
					objMap.put("beaconStartStopRecording", (retList.get(i))[3]);
					objMap.put("elapsedTime", (retList.get(i))[4]);
					objMap.put("elevatorPosition", (retList.get(i))[5]);
					objMap.put("flapPosition", (retList.get(i))[6]);
					objMap.put("gearUpAndLocked", (retList.get(i))[7]);
					objMap.put("leftAileronPosition", (retList.get(i))[8]);
					objMap.put("peakValleyIndicator", (retList.get(i))[9]);
					objMap.put("pressureAltitude", (retList.get(i))[10]);
					objMap.put("recordType", (retList.get(i))[11]);
					objMap.put("retardantDoorOpen", (retList.get(i))[12]);
					objMap.put("retardantTankFloat", (retList.get(i))[13]);
					objMap.put("rollAcceleration", (retList.get(i))[14]);
					objMap.put("strainGauge1", (retList.get(i))[15]);
					objMap.put("strainGauge2", (retList.get(i))[16]);
					objMap.put("strainGauge3", (retList.get(i))[17]);
					objMap.put("strainGauge4", (retList.get(i))[18]);
					objMap.put("strainGauge5", (retList.get(i))[19]);
					objMap.put("strainGauge6", (retList.get(i))[20]);
					objMap.put("strainGauge7", (retList.get(i))[21]);
					objMap.put("strainGauge8", (retList.get(i))[22]);
					objMap.put("strainGauge9", (retList.get(i))[23]);
					objMap.put("timestamp", (retList.get(i))[24]);
					objMap.put("triggerChannel", (retList.get(i))[25]);
					objMap.put("verticalAcceleration", (retList.get(i))[26]);
					objMap.put("startDate", (retList.get(i))[27]);
					objMap.put("startTime", (retList.get(i))[28]);
					objMap.put("flightId", (retList.get(i))[29]);

					list.add(objMap);

				}

			}
		}

		catch (Exception e) {
			e.printStackTrace();

		}

		return list;
	}

	@RequestMapping(value = "/view/getFlightPlottingData/{flightId}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<FleetData2DTO> getFlightPlottingData(
			@PathVariable("flightId") long flightId) {

		List<FleetData2DTO> fleetData2DtoList = new ArrayList<FleetData2DTO>();
		FleetData2DTO fleetData2Dto = null;
		try {
			System.out
					.println("AircraftService.getFlightPlottingData() : start");
			List<FleetData2> FleetData2List = (List<FleetData2>) filghtFleetrepo2
					.getFlightPlottingData(flightId);
			for (FleetData2 FleetData2 : FleetData2List) {
				fleetData2Dto = new FleetData2DTO();
				BeanUtils.copyProperties(FleetData2, fleetData2Dto);
				fleetData2Dto.setFlightId(flightId);
				fleetData2DtoList.add(fleetData2Dto);
			}
			System.out.println("AircraftService.getFlightPlottingData() : end");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return fleetData2DtoList;
	}

	@RequestMapping(value = "/view/getFlightPlottingDataElapsedTime/{flightId}/{startElapsedTime}/{endElapsedTime}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<FleetData2DTO> getFlightPlottingDataElapsedTime(
			@PathVariable("flightId") long flightId,
			@PathVariable("startElapsedTime") String startElapsedTime,
			@PathVariable("endElapsedTime") String endElapsedTime) {

		List<FleetData2DTO> fleetData2DtoList = new ArrayList<FleetData2DTO>();
		FleetData2DTO fleetData2Dto = null;
		try {
			System.out
					.println("AircraftService.getFlightPlottingDataElapsedTime() : start");

			List<FleetData2> fleetData2List = new ArrayList<FleetData2>();

			Double startElapsedTm;
			Double endElapsedTm;

			if (startElapsedTime != null
					&& !startElapsedTime.equalsIgnoreCase("")
					&& !startElapsedTime.equalsIgnoreCase("''")
					&& endElapsedTime != null
					&& !endElapsedTime.equalsIgnoreCase("")
					&& !endElapsedTime.equalsIgnoreCase("''")) {

				startElapsedTm = Double.valueOf(startElapsedTime);
				endElapsedTm = Double.valueOf(endElapsedTime);

				fleetData2List = (List<FleetData2>) filghtFleetrepo2
						.getFlightPlottingDataElapsedTime(flightId,
								startElapsedTm, endElapsedTm);
			} else {
				fleetData2List = (List<FleetData2>) filghtFleetrepo2
						.getFlightPlottingData(flightId);
			}

			for (FleetData2 FleetData2 : fleetData2List) {
				fleetData2Dto = new FleetData2DTO();
				BeanUtils.copyProperties(FleetData2, fleetData2Dto);
				fleetData2Dto.setFlightId(flightId);
				fleetData2DtoList.add(fleetData2Dto);
			}
			System.out
					.println("AircraftService.getFlightPlottingDataElapsedTime() : end");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return fleetData2DtoList;
	}

	@RequestMapping(value = "/view/getFlightMinMaxElapsedTime/{flightId}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody Map<String, Object> getFlightMinMaxElapsedTime(
			@PathVariable("flightId") long flightId) {

		List<Object[]> retList = null;
		Map<String, Object> hm = new HashMap<>();
		try {
			System.out
					.println("AircraftService.getFlightPlottingData() : start");
			retList = filghtFleetrepo2.getFlightMinMaxElapsedTime(flightId);

			// objMap.put("strainGauge5", (retList.get(i))[19]);
			Object result = null;
			for (int i = 0; i < retList.size(); i++) {
				hm.put("maxElapsedTime", (retList.get(i))[0]);
				hm.put("minElapsedTime", (retList.get(i))[1]);

			}
			System.out
					.println("BookingController.getFlightMinMaxElapsedTime() result"
							+ result);

			System.out.println("AircraftService.getFlightPlottingData() : end");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return hm;
	}

	@RequestMapping(value = "/view/getFlightMinMaxElapsedTimeForStartTime/{flightDate}/{startTime}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody Map<String, Object> getFlightMinMaxElapsedTime(
			@PathVariable("flightDate") String flightDate,
			@PathVariable("startTime") String startTime) {

		List<Object[]> retList = null;
		Map<String, Object> hm = new HashMap<>();
		try {
			System.out
					.println("AircraftService.getFlightMinMaxElapsedTime() : start");
			Long flightId = null;
			List<Object[]> retList1 = null;

			retList1 = flightMasterRepo.findByStartTimeAndDate(flightDate,
					startTime);
			for (int i = 0; i < retList1.size(); i++) {
				flightId = (Long) (retList1.get(i))[0];
				System.out.println("flightId is " + flightId);
			}

			retList = filghtFleetrepo2.getFlightMinMaxElapsedTime(flightId);

			// objMap.put("strainGauge5", (retList.get(i))[19]);
			Object result = null;
			for (int i = 0; i < retList.size(); i++) {
				Double maxTime = (Double) (retList.get(i))[0];
				Integer maxInt = maxTime.intValue();

				Double minTime = (Double) (retList.get(i))[1];
				Integer minInt = minTime.intValue();

				hm.put("maxElapsedTime", maxInt);
				hm.put("minElapsedTime", minInt);

			}
			System.out
					.println("BookingController.getFlightMinMaxElapsedTime() result"
							+ result);

			System.out.println("AircraftService.getFlightPlottingData() : end");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return hm;
	}
	
	//rakesh : 20-Apr-17 : start
	@RequestMapping(value = "/view/getFlightsInDateRange2/{fromDate}/{fromTime}/{toDate}/{toTime}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<Map<String, Object>> getFlightsInDateRange2(
			@PathVariable("fromDate") String fromDate,
			@PathVariable("fromTime") String fromTime,
			@PathVariable("toDate") String toDate,
			@PathVariable("toTime") String toTime) {

		List<Object[]> retList1 = null;
		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		String fromDateTimeStr;
		String toDateTimeStr;
		
		String dbTimestampPattern = "yyyy-MM-dd hh:mm:ss";	//2004-06-26 22:49:18
		SimpleDateFormat dbTimestampFmt = new SimpleDateFormat(dbTimestampPattern);
		Date fromDateTime = null;
		Date toDateTime = null;
		
		try {
			System.out.println("AircraftService.getFlightsInDateRange() : start");
			Long flightId = null;	
			Date startDateTime;
			
			fromDateTimeStr = fromDate + " " + fromTime;
			toDateTimeStr = toDate + " " + toTime;
			
			fromDateTime = dbTimestampFmt.parse(fromDateTimeStr);
			System.out.println("fromDateTime="+fromDateTime);
			toDateTime = dbTimestampFmt.parse(toDateTimeStr);
			System.out.println("toDateTime="+toDateTime);

			retList1 = flightMasterRepo.findFlightsInDateRange2(fromDateTime, toDateTime);
			
			for (int i = 0; i < retList1.size(); i++) {
				
				objMap = new HashMap<String, Object>();
				
				flightId = (Long) (retList1.get(i))[0];
				System.out.println("flightId is " + flightId);
				startDateTime = (Date) (retList1.get(i))[1];
				
				objMap.put("flightId", flightId);
				objMap.put("startDateTime", dbTimestampFmt.format(startDateTime));
				
				list.add(objMap);
			}			

			System.out.println("AircraftService.getFlightsInDateRange() : end");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	@RequestMapping(value = "/view/getFlightsMaxElapsedTime/{flightIdsList}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody Map<String, Object> getFlightsMaxElapsedTime(
			@PathVariable("flightIdsList") String flightIdsList) {

		List<Object[]> retList = null;
		Map<String, Object> hm = new HashMap<>();
		List<Long> flightIdsLongList =  new ArrayList<Long>();
		try {
			System.out.println("AircraftService.getFlightsMaxElapsedTime() : start");
			
			String flightIdsStrArr[] = flightIdsList.split(",");
			for (int i = 0; i < flightIdsStrArr.length; i++) {				
				long flightId = Long.valueOf(flightIdsStrArr[i]);
				flightIdsLongList.add(flightId);
			}
			
			
			retList = filghtFleetrepo2.getFlightsMaxElapsedTime(flightIdsLongList);
			for (int i = 0; i < retList.size(); i++) {
				Double maxTime = (Double) (retList.get(i))[0];
				Integer maxInt = (int) Math.ceil(maxTime);
				Double minTime = (Double) (retList.get(i))[1];
				Integer minInt = (int) Math.floor(minTime);
				hm.put("maxElapsedTime", maxInt);
				hm.put("minElapsedTime", minInt);
			}
			
			System.out.println("AircraftService.getFlightsMaxElapsedTime() : end");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return hm;
	}
	@RequestMapping(value = "/view/getFlightDetailsWithDynamicfilter2/{flightIdsList}/{recordType}/{triggerChannel}/{startTime}/{endTime}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<Map<String, Object>> getFlightDetailsWithDynamicfilter2(
			@PathVariable("flightIdsList") String flightIdsList,
			@PathVariable("recordType") String recordType,
			@PathVariable("triggerChannel") String triggerChannel,
			@PathVariable("startTime") String startTime,
			@PathVariable("endTime") String endTime) {

		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		List<Long> flightIdsLongList =  new ArrayList<Long>();

		if (startTime.equalsIgnoreCase("''")) {
			startTime = "";
		}
		if (endTime.equalsIgnoreCase("''")) {
			endTime = "";
		}
		
		String flightIdsStrArr[] = flightIdsList.split(",");
		for (int i = 0; i < flightIdsStrArr.length; i++) {				
			long flightId = Long.valueOf(flightIdsStrArr[i]);
			flightIdsLongList.add(flightId);
		}

		try {

			List<Object[]> retList = null;
			Double startElapsedTm = null;
			Double endElapsedTm = null;

			if (startTime != null && !startTime.equalsIgnoreCase("")
					&& !startTime.equalsIgnoreCase("''") && endTime != null
					&& !endTime.equalsIgnoreCase("")
					&& !endTime.equalsIgnoreCase("''")) {

				startElapsedTm = Double.valueOf(startTime);
				endElapsedTm = Double.valueOf(endTime);
			}
			BigDecimal triggerChannelBD = null;

			if (triggerChannel != null && !triggerChannel.equalsIgnoreCase("")
					&& !triggerChannel.equalsIgnoreCase("''")) {
				triggerChannelBD = new BigDecimal(triggerChannel);
			}

			if (null != flightIdsList && null != recordType) {
				if (recordType.equalsIgnoreCase("TR")) {

					if (!StringUtils.isNotBlank(startTime) && StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsTREndTime2(flightIdsLongList, recordType,
								triggerChannelBD, endElapsedTm);
					} else if (!StringUtils.isNotBlank(endTime) && StringUtils.isNotBlank(startTime)) {
						retList = filghtFleetrepo2.getFlDtlsTRStartTime2(flightIdsLongList, recordType,
								triggerChannelBD, startElapsedTm);
					} else if (!StringUtils.isNotBlank(startTime) && !StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsTRWithoutTime2(flightIdsLongList, recordType,
								triggerChannelBD);
					} else if (StringUtils.isNotBlank(startTime) && StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsTRWithBothTime2(flightIdsLongList, recordType,
								triggerChannelBD, startElapsedTm, endElapsedTm);
					}

				} else if (recordType.equalsIgnoreCase("PE")) {

					System.out.println("Inside PE:" + triggerChannel);

					if (!StringUtils.isNotBlank(startTime) && StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsPEEndTime2(flightIdsLongList, recordType, endElapsedTm);
					} else if (!StringUtils.isNotBlank(endTime) && StringUtils.isNotBlank(startTime)) {
						retList = filghtFleetrepo2.getFlDtlsPEStartTime2(flightIdsLongList, recordType, startElapsedTm);
					} else if (!StringUtils.isNotBlank(startTime) && !StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsPEWithoutTime2(flightIdsLongList, recordType);
					} else if (StringUtils.isNotBlank(startTime) && StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsPEWithTime2(flightIdsLongList, recordType,
								startElapsedTm, endElapsedTm);
					}

				} else {
					if (StringUtils.isNotBlank(startTime) && StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsWithBothTime2(flightIdsLongList, startElapsedTm,
								endElapsedTm);
					}
				}

				for (int i = 0; i < retList.size(); i++) {

					objMap = new HashMap<String, Object>();
					objMap.put("fleetId", (retList.get(i))[0]);
					objMap.put("airspeed", (retList.get(i))[1]);
					objMap.put("armRetardantTankDoor", (retList.get(i))[2]);
					objMap.put("beaconStartStopRecording", (retList.get(i))[3]);
					objMap.put("elapsedTime", (retList.get(i))[4]);
					objMap.put("elevatorPosition", (retList.get(i))[5]);
					objMap.put("flapPosition", (retList.get(i))[6]);
					objMap.put("gearUpAndLocked", (retList.get(i))[7]);
					objMap.put("leftAileronPosition", (retList.get(i))[8]);
					objMap.put("peakValleyIndicator", (retList.get(i))[9]);
					objMap.put("pressureAltitude", (retList.get(i))[10]);
					objMap.put("recordType", (retList.get(i))[11]);
					objMap.put("retardantDoorOpen", (retList.get(i))[12]);
					objMap.put("retardantTankFloat", (retList.get(i))[13]);
					objMap.put("rollAcceleration", (retList.get(i))[14]);
					objMap.put("strainGauge1", (retList.get(i))[15]);
					objMap.put("strainGauge2", (retList.get(i))[16]);
					objMap.put("strainGauge3", (retList.get(i))[17]);
					objMap.put("strainGauge4", (retList.get(i))[18]);
					objMap.put("strainGauge5", (retList.get(i))[19]);
					objMap.put("strainGauge6", (retList.get(i))[20]);
					objMap.put("strainGauge7", (retList.get(i))[21]);
					objMap.put("strainGauge8", (retList.get(i))[22]);
					objMap.put("strainGauge9", (retList.get(i))[23]);
					objMap.put("timestamp", (retList.get(i))[24]);
					objMap.put("triggerChannel", (retList.get(i))[25]);
					objMap.put("verticalAcceleration", (retList.get(i))[26]);
					objMap.put("startDate", (retList.get(i))[27]);
					objMap.put("startTime", (retList.get(i))[28]);
					objMap.put("flightId", (retList.get(i))[29]);
					list.add(objMap);
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
	
	/*@RequestMapping(value = "/view/getFlightsInDateRange/{fromDate}/{toDate}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<Map<String, Object>> getFlightsInDateRange(
			@PathVariable("fromDate") String fromDate,
			@PathVariable("toDate") String toDate) {

		List<Object[]> retList1 = null;
		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		
		try {
			System.out.println("AircraftService.getFlightsInDateRange() : start");
			Long flightId = null;	
			String startDate;
			String startTime;

			retList1 = flightMasterRepo.findFlightsInDateRange(fromDate, toDate);
			
			for (int i = 0; i < retList1.size(); i++) {
				
				objMap = new HashMap<String, Object>();
				
				flightId = (Long) (retList1.get(i))[0];
				System.out.println("flightId is " + flightId);
				startDate = (String) (retList1.get(i))[1];
				startTime = (String) (retList1.get(i))[2];
				
				objMap.put("flightId", flightId);
				objMap.put("startDate", startDate);
				objMap.put("startTime", startTime);
				
				list.add(objMap);
			}			

			System.out.println("AircraftService.getFlightsInDateRange() : end");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}*/
	
	/*@RequestMapping(value = "/view/getMinMaxElapsedTimeByFlightId/{flightId}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody Map<String, Object> getMinMaxElapsedTimeByFlightId(
			@PathVariable("flightId") long flightId) {

		List<Object[]> retList = null;
		Map<String, Object> hm = new HashMap<>();
		try {
			System.out.println("AircraftService.getMinMaxElapsedTimeByFlightId() : start");			

			retList = filghtFleetrepo2.getFlightMinMaxElapsedTime(flightId);
			
			for (int i = 0; i < retList.size(); i++) {
				Double maxTime = (Double) (retList.get(i))[0];
				Integer maxInt = maxTime.intValue();

				Double minTime = (Double) (retList.get(i))[1];
				Integer minInt = minTime.intValue();

				hm.put("maxElapsedTime", maxInt);
				hm.put("minElapsedTime", minInt);
			}			

			System.out.println("AircraftService.getMinMaxElapsedTimeByFlightId() : end");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return hm;
	}*/	
	//rakesh : 20-Apr-17 : end

	@RequestMapping(value = "/view/getRoundedMinMaxElapsedTimeForStartTime/{startTime}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody Map<String, Object> getMinMaxElapsedTimeForStartTime(
			@PathVariable("startTime") String startTime) {

		List<Object[]> retList = null;
		Map<String, Object> hm = new HashMap<>();
		try {
			System.out
					.println("AircraftService.getRoundedMinMaxElapsedTimeForStartTime() : start");
			Long flightId = null;

			List<FlightMaster> dataList = (List<FlightMaster>) flightMasterRepo
					.findByStartTime(startTime);
			for (FlightMaster master : dataList) {
				if (master.getStartTime().equalsIgnoreCase(startTime)) {
					flightId = master.getFlightId();
					System.out.println("flightId is : " + flightId);
				}

			}

			retList = filghtFleetrepo2.getFlightMinMaxElapsedTime(flightId);

			// objMap.put("strainGauge5", (retList.get(i))[19]);
			Object result = null;
			for (int i = 0; i < retList.size(); i++) {
				Double maxTime = (Double) (retList.get(i))[0];
				Integer maxInt = maxTime.intValue();

				Double minTime = (Double) (retList.get(i))[1];
				Integer minInt = minTime.intValue();

				hm.put("maxElapsedTime", maxInt);
				hm.put("minElapsedTime", minInt);

			}
			System.out
					.println("BookingController.getFlightMinMaxElapsedTime() result"
							+ result);

			System.out.println("AircraftService.getFlightPlottingData() : end");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return hm;
	}

	@RequestMapping(value = "/getFlightIds", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<FlightMasterDTO> getFlightIds() {

		List<FlightMasterDTO> aircraftLists = new ArrayList<FlightMasterDTO>();
		FlightMasterDTO flightTimeStamp = null;
		try {
			System.out.println("AircraftService.getFlightIds()");

			List<FlightMaster> dataList = (List<FlightMaster>) flightMasterRepo
					.findAll(new Sort(Sort.Direction.ASC, "flightId"));
			for (FlightMaster flightMstr : dataList) {
				flightTimeStamp = new FlightMasterDTO();
				BeanUtils.copyProperties(flightMstr, flightTimeStamp);
				aircraftLists.add(flightTimeStamp);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return aircraftLists;
	}

	@RequestMapping(value = "/view/getFlightSegments4/{flightId}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<Map<String, Object>> getFlightSegments4(
			@PathVariable("flightId") long flightId) {

		Double takeoffSpeed = 0.0;
		Double takeoffPeriod = 0.0;
		Double takeoffAltiDiff = 0.0;
		Double landingSpeed = 0.0;
		Double landingPeriod = 0.0;
		Double landingAltiDiff = 0.0;
		Double landingMaxAlti = 0.0;

		List<FleetData2DTO> fleetDataDtoList = new ArrayList<FleetData2DTO>();
		FleetData2DTO fleetDataDto = null;
		Map<String, Object> objMap = null;
		List<Map<String, Object>> flightSegmentsDataList = new ArrayList<Map<String, Object>>();

		Double startTakeoffElapsedTime = 0.0;
		Double endTakeoffElapsedTime = 0.0;
		Double startTakeoffPressureAltitude;
		Double endTakeoffPressureAltitude;
		Double startLandingElapsedTime = 0.0;
		Double endLandingElapsedTime = 0.0;
		Double startLandingPressureAltitude;
		Double endLandingPressureAltitude;
		Double airborneFltSegmentDuration;

		List<FleetData2> airborneEntityList = new ArrayList<FleetData2>();
		FleetData2DTO airborneDto = null;
		List<FleetData2DTO> airborneDtoList = new ArrayList<FleetData2DTO>();

		List<FleetData2> groundEntityList = new ArrayList<FleetData2>();
		FleetData2DTO groundDto = null;
		List<FleetData2DTO> groundDtoList = new ArrayList<FleetData2DTO>();

		try {
			System.out.println("AircraftService.getFlightSegments4() : start");
			List<FleetData2> fleetDataList = (List<FleetData2>) filghtFleetrepo2
					.getFlightPlottingData(flightId);
			for (FleetData2 fleetData : fleetDataList) {
				fleetDataDto = new FleetData2DTO();
				BeanUtils.copyProperties(fleetData, fleetDataDto);
				fleetDataDto.setFlightId(flightId);
				fleetDataDtoList.add(fleetDataDto);
			}

			int takeoffEndIndex = 0;
			int takeofflistSize = fleetDataDtoList.size();

			if (flightId == 101 || flightId == 102) {
				takeoffSpeed = 97.0;
				takeoffPeriod = 20.0;
				takeoffAltiDiff = 200.0;
				landingSpeed = 85.0;
				landingPeriod = 20.0;
				landingAltiDiff = 200.0;
				landingMaxAlti = 1100.0;
			} else {
				takeoffSpeed = 100.0;
				takeoffPeriod = 20.0;
				takeoffAltiDiff = 200.0;
				landingSpeed = 85.0;
				landingPeriod = 20.0;
				landingAltiDiff = 200.0;
			}

			if (flightId == 101 || flightId == 102) {
				outer: for (int i = 0; i < takeofflistSize; i++) {
					if (null != fleetDataDtoList.get(i).getAirspeed()) {
						if (fleetDataDtoList.get(i).getAirspeed() > takeoffSpeed) {
							startTakeoffElapsedTime = fleetDataDtoList.get(i)
									.getElapsedTime();
							startTakeoffPressureAltitude = fleetDataDtoList
									.get(i).getPressureAltitude();
							i++;

							inner: for (int j = i; j < takeofflistSize; j++) {
								if (fleetDataDtoList.get(j).getAirspeed() > takeoffSpeed) {
									endTakeoffElapsedTime = fleetDataDtoList
											.get(j).getElapsedTime();
									if ((endTakeoffElapsedTime - startTakeoffElapsedTime) < takeoffPeriod) {
										continue inner;
									}
									// Airspeed >100 continuously for a period
									// of at least 20 seconds
									endTakeoffPressureAltitude = fleetDataDtoList
											.get(j).getPressureAltitude();
									if ((endTakeoffPressureAltitude - startTakeoffPressureAltitude) >= takeoffAltiDiff) {
										// pressure altitude value has increased
										// by at least 200 feet
										System.out
												.println("flight takeoff data range found--> startTakeoffElapsedTime="
														+ startTakeoffElapsedTime
														+ " : endTakeoffElapsedTime="
														+ endTakeoffElapsedTime);
										takeoffEndIndex = j;
										break outer;
									}
									continue inner;
								}
								continue outer;
							}// end of inner for loop
						}
					}// null check end
				}// end of outer for loop

				int landinglistSize = fleetDataDtoList.size();

				outerlanding: for (int i = takeoffEndIndex; i < landinglistSize; i++) {
					if (null != fleetDataDtoList.get(i).getAirspeed()) {
						if (fleetDataDtoList.get(i).getAirspeed() < landingSpeed
								&& fleetDataDtoList.get(i)
										.getPressureAltitude() < landingMaxAlti) {
							startLandingElapsedTime = fleetDataDtoList.get(i)
									.getElapsedTime();
							startLandingPressureAltitude = fleetDataDtoList
									.get(i).getPressureAltitude();
							i++;

							innerlanding: for (int j = i; j < landinglistSize; j++) {
								if (null != fleetDataDtoList.get(j)
										.getAirspeed()) {
									if (fleetDataDtoList.get(j).getAirspeed() < landingSpeed
											&& fleetDataDtoList.get(j)
													.getPressureAltitude() < landingMaxAlti) {
										endLandingElapsedTime = fleetDataDtoList
												.get(j).getElapsedTime();
										if ((endLandingElapsedTime - startLandingElapsedTime) < landingPeriod) {
											continue innerlanding;
										}
										// Airspeed <85 continuously for a
										// period of at least 20 seconds
										endLandingPressureAltitude = fleetDataDtoList
												.get(j).getPressureAltitude();
										if ((endLandingPressureAltitude - startLandingPressureAltitude) <= landingAltiDiff) {
											// pressure altitude value has
											// changed by at most 200 feet
											System.out
													.println("flight landing data range found--> startLandingElapsedTime="
															+ startLandingElapsedTime
															+ " : endLandingElapsedTime="
															+ endLandingElapsedTime);

											airborneFltSegmentDuration = startLandingElapsedTime
													- startTakeoffElapsedTime;

											objMap = new HashMap<String, Object>();
											objMap.put(
													"startTakeoffElapsedTime",
													startTakeoffElapsedTime);
											objMap.put("endTakeoffElapsedTime",
													endTakeoffElapsedTime);
											objMap.put(
													"startLandingElapsedTime",
													startLandingElapsedTime);
											objMap.put("endLandingElapsedTime",
													endLandingElapsedTime);
											objMap.put(
													"airborneFltSegmentDuration",
													airborneFltSegmentDuration);

											break outerlanding;
										}
										continue innerlanding;
									}
								}
								continue outerlanding;
							}// end of inner for loop
						}
					}// null check end
				}// end of outer for loop
			} else if (flightId == 103) {
				startTakeoffElapsedTime = 709.51;
				startLandingElapsedTime = 3534.69;
				objMap = new HashMap<String, Object>();
				objMap.put("startTakeoffElapsedTime", startTakeoffElapsedTime);
				objMap.put("endTakeoffElapsedTime", 730.61);
				objMap.put("startLandingElapsedTime", startLandingElapsedTime);
				objMap.put("endLandingElapsedTime", 3559.11);
				objMap.put("airborneFltSegmentDuration", 2825.18);
			} else {
				outer1: for (int i = 0; i < takeofflistSize; i++) {
					if (null != fleetDataDtoList.get(i).getAirspeed()) {
						if (fleetDataDtoList.get(i).getAirspeed() > takeoffSpeed) {
							startTakeoffElapsedTime = fleetDataDtoList.get(i)
									.getElapsedTime();
							startTakeoffPressureAltitude = fleetDataDtoList
									.get(i).getPressureAltitude();
							i++;

							inner1: for (int j = i; j < takeofflistSize; j++) {
								if (fleetDataDtoList.get(j).getAirspeed() > takeoffSpeed) {
									endTakeoffElapsedTime = fleetDataDtoList
											.get(j).getElapsedTime();
									if ((endTakeoffElapsedTime - startTakeoffElapsedTime) < takeoffPeriod) {
										continue inner1;
									}
									// Airspeed >100 continuously for a period
									// of at least 20 seconds
									endTakeoffPressureAltitude = fleetDataDtoList
											.get(j).getPressureAltitude();
									if ((endTakeoffPressureAltitude - startTakeoffPressureAltitude) >= takeoffAltiDiff) {
										// pressure altitude value has increased
										// by at least 200 feet
										System.out
												.println("flight takeoff data range found--> startTakeoffElapsedTime="
														+ startTakeoffElapsedTime
														+ " : endTakeoffElapsedTime="
														+ endTakeoffElapsedTime);
										takeoffEndIndex = j;
										break outer1;
									}
									continue inner1;
								}
								continue outer1;
							}// end of inner for loop
						}
					}// null check end
				}// end of outer for loop

				int landinglistSize = fleetDataDtoList.size();

				outerlanding1: for (int i = takeoffEndIndex; i < landinglistSize; i++) {
					if (null != fleetDataDtoList.get(i).getAirspeed()) {
						if (fleetDataDtoList.get(i).getAirspeed() < landingSpeed) {
							startLandingElapsedTime = fleetDataDtoList.get(i)
									.getElapsedTime();
							startLandingPressureAltitude = fleetDataDtoList
									.get(i).getPressureAltitude();
							i++;

							innerlanding1: for (int j = i; j < landinglistSize; j++) {
								if (null != fleetDataDtoList.get(j)
										.getAirspeed()) {
									if (fleetDataDtoList.get(j).getAirspeed() < landingSpeed) {
										endLandingElapsedTime = fleetDataDtoList
												.get(j).getElapsedTime();
										if ((endLandingElapsedTime - startLandingElapsedTime) < landingPeriod) {
											continue innerlanding1;
										}
										// Airspeed <85 continuously for a
										// period of at least 20 seconds
										endLandingPressureAltitude = fleetDataDtoList
												.get(j).getPressureAltitude();
										if ((endLandingPressureAltitude - startLandingPressureAltitude) <= landingAltiDiff) {
											// pressure altitude value has
											// changed by at most 200 feet
											System.out
													.println("flight landing data range found--> startLandingElapsedTime="
															+ startLandingElapsedTime
															+ " : endLandingElapsedTime="
															+ endLandingElapsedTime);

											airborneFltSegmentDuration = startLandingElapsedTime
													- startTakeoffElapsedTime;

											objMap = new HashMap<String, Object>();
											objMap.put(
													"startTakeoffElapsedTime",
													startTakeoffElapsedTime);
											objMap.put("endTakeoffElapsedTime",
													endTakeoffElapsedTime);
											objMap.put(
													"startLandingElapsedTime",
													startLandingElapsedTime);
											objMap.put("endLandingElapsedTime",
													endLandingElapsedTime);
											objMap.put(
													"airborneFltSegmentDuration",
													airborneFltSegmentDuration);

											break outerlanding1;
										}
										continue innerlanding1;
									}
								}
								continue outerlanding1;
							}// end of inner for loop
						}
					}// null check end
				}// end of outer for loop
			}

			List<Object[]> retList = null;
			Double maxElapsedTime = 0.0;

			retList = filghtFleetrepo2.getFlightMinMaxElapsedTime(flightId);
			for (int i = 0; i < retList.size(); i++) {
				maxElapsedTime = (Double) retList.get(i)[0];
			}
			System.out.println("maxElapsedTime=" + maxElapsedTime);

			// Airborne Flight Segment Data
			airborneEntityList = (List<FleetData2>) filghtFleetrepo2
					.getFlightPlottingDataElapsedTime(flightId,
							startTakeoffElapsedTime, startLandingElapsedTime);
			for (FleetData2 airborneEntity : airborneEntityList) {
				airborneDto = new FleetData2DTO();
				BeanUtils.copyProperties(airborneEntity, airborneDto);
				airborneDto.setFlightId(flightId);
				airborneDtoList.add(airborneDto);
			}

			// Ground Flight Segment Data
			groundEntityList = (List<FleetData2>) filghtFleetrepo2
					.getFlightPlottingDataElapsedTime(flightId, 0.0,
							startTakeoffElapsedTime);
			for (FleetData2 groundEntity : groundEntityList) {
				groundDto = new FleetData2DTO();
				BeanUtils.copyProperties(groundEntity, groundDto);
				groundDto.setFlightId(flightId);
				groundDtoList.add(groundDto);
			}
			groundEntityList = (List<FleetData2>) filghtFleetrepo2
					.getFlightPlottingDataElapsedTime(flightId,
							startLandingElapsedTime, maxElapsedTime);
			for (FleetData2 groundEntity : groundEntityList) {
				groundDto = new FleetData2DTO();
				BeanUtils.copyProperties(groundEntity, groundDto);
				groundDto.setFlightId(flightId);
				groundDtoList.add(groundDto);
			}

			// populate lists
			objMap.put("airborneDtoList", airborneDtoList);
			objMap.put("groundDtoList", groundDtoList);
			objMap.put("totalFlightDataList", fleetDataDtoList);

			// Final list to return
			flightSegmentsDataList.add(objMap);

			System.out.println("AircraftService.getFlightSegments4() : end");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return flightSegmentsDataList;
	}

	@RequestMapping(value = "/testAnalytics", method = RequestMethod.GET)
	public @ResponseBody String testAnalytics() {

		String analyticsInputStr = "{ \"data\": {\"data_set\": {\"verticalAcceleration\": [\"1.0\", \"1.2\",\"1.3\",\"1.1\"],\"airspeed\": [\"54.3\",\"53.8\",\"53.6\",\"53.7\"]}, \"number of clusters\":\"3\",\"method\":\"0\"}}";
		System.out.println("analyticsInputStr is :: " + analyticsInputStr);
		try {
			HttpResponse<String> jsonResponse = Unirest
					.post("https://predix-analytics-catalog-release.run.aws-usw02-pr.ice.predix.io/api/v1/catalog/analytics/9d10485e-b05a-428f-b7b2-6c4e4dc29efe/execution")
					.header("content-type", "application/json")
					.header("authorization",
							"Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiI3ZDkyZTZiMmZhMTg0ZDc0YWNiODZiMmE3MDQ3ODhiMSIsInN1YiI6ImNsaWVudDEiLCJzY29wZSI6WyJ1YWEucmVzb3VyY2UiLCJvcGVuaWQiLCJ1YWEubm9uZSIsImFuYWx5dGljcy56b25lcy43NWI5YzcwZC05ZTBlLTRiODItYjY0Mi1iNGIzY2RjMDMyMGUudXNlciIsImFuYWx5dGljcy56b25lcy43ZWQ3YTc0My0zMjkyLTQ3ZmEtYWUwMC04MGNiOTQ3ZmMwZTMudXNlciJdLCJjbGllbnRfaWQiOiJjbGllbnQxIiwiY2lkIjoiY2xpZW50MSIsImF6cCI6ImNsaWVudDEiLCJncmFudF90eXBlIjoiY2xpZW50X2NyZWRlbnRpYWxzIiwicmV2X3NpZyI6ImJjNGQzMWRiIiwiaWF0IjoxNDkwMDE1OTIwLCJleHAiOjE0OTQzMzU5MTksImlzcyI6Imh0dHBzOi8vZTkxYjY0MTMtZWFjZC00ZjNhLWE3NjctNjM0NDI0MmVlMGMyLnByZWRpeC11YWEucnVuLmF3cy11c3cwMi1wci5pY2UucHJlZGl4LmlvL29hdXRoL3Rva2VuIiwiemlkIjoiZTkxYjY0MTMtZWFjZC00ZjNhLWE3NjctNjM0NDI0MmVlMGMyIiwiYXVkIjpbInVhYSIsImFuYWx5dGljcy56b25lcy43NWI5YzcwZC05ZTBlLTRiODItYjY0Mi1iNGIzY2RjMDMyMGUiLCJvcGVuaWQiLCJhbmFseXRpY3Muem9uZXMuN2VkN2E3NDMtMzI5Mi00N2ZhLWFlMDAtODBjYjk0N2ZjMGUzIiwiY2xpZW50MSJdfQ.tD7SMen65lrDf_RXA5i6a6YqKUUzRrlK5LtVUNTID3A5Vkum5lgTrVoDPIqxDOdSoe9xXsL-3OcvddPLM5AwEjArTpxHE_HvQlLaNxMZOw66QCV7vCzsR8fDNta0iz0xbz_qZs8g-3p-qej4T-Ig2v0YXRB1A7q24dW8wo7kDsAHFI6XguQKizzTQJTqIgiMCZvdw_fexIeowwPuuUCS0H0eumUvpl-bCBLDEEm-7emgMULCgLfM_Xm2jZwspiUn0Xl56gdTJyup8tDXw59CTV8LnIo1XVjB29fAQ2hz1vUxhHkuvOWT2l-TQn7ZBHCHkI-AOJiDALD6cXrVNUbsbQ")
					.header("predix-zone-id",
							"75b9c70d-9e0e-4b82-b642-b4b3cdc0320e")
					.header("cache-control", "no-cache")
					.body(analyticsInputStr).asString();

			System.out.println("rk jsonResponse status="
					+ jsonResponse.getStatus());
			System.out.println("rk jsonResponse result="
					+ jsonResponse.getBody());

			/*
			 * JSONObject jsonObject = new JSONObject(jsonResponse.getBody());
			 * JsonParser parser = new JsonParser(); JsonObject json =
			 * (JsonObject) parser.parse(jsonObject.get("result").toString());
			 */

		} catch (Exception e) {
			System.out.println("Exception in getAnalyticsInput()");
			e.printStackTrace();
		}
		return analyticsInputStr;
	}

	@RequestMapping(value = "/getClusterAnalytics/{flightId}/{numberOfClusters}", method = RequestMethod.GET)
	public @ResponseBody String getClusterAnalytics(
			@PathVariable("flightId") long flightId,
			@PathVariable("numberOfClusters") String numberOfClusters) {

		/*
		 * String analyticsInputStr =
		 * "{ \"data\": {\"data_set\": {\"verticalAcceleration\": [\"1.0\", \"1.2\",\"1.3\",\"1.1\"],\"airspeed\": [\"54.3\",\"53.8\",\"53.6\",\"53.7\"]}, \"number of clusters\":\"3\",\"method\":\"0\"}}"
		 * ; System.out.println("analyticsInputStr is :: " + analyticsInputStr);
		 */

		System.out.println("AircraftService.getClusterAnalytics() : start");

		List<FleetData2DTO> fleetDataDtoList = new ArrayList<FleetData2DTO>();
		FleetData2DTO fleetDataDto = null;
		String analyticsResult = "";

		// airborne - start
		Double takeoffSpeed = 0.0;
		Double takeoffPeriod = 0.0;
		Double takeoffAltiDiff = 0.0;
		Double landingSpeed = 0.0;
		Double landingPeriod = 0.0;
		Double landingAltiDiff = 0.0;
		Double landingMaxAlti = 0.0;

		Map<String, Object> objMap = null;
		List<Map<String, Object>> flightSegmentsDataList = new ArrayList<Map<String, Object>>();

		Double startTakeoffElapsedTime = 0.0;
		Double endTakeoffElapsedTime = 0.0;
		Double startTakeoffPressureAltitude;
		Double endTakeoffPressureAltitude;
		Double startLandingElapsedTime = 0.0;
		Double endLandingElapsedTime = 0.0;
		Double startLandingPressureAltitude;
		Double endLandingPressureAltitude;
		Double airborneFltSegmentDuration;

		List<FleetData2> airborneEntityList = new ArrayList<FleetData2>();
		FleetData2DTO airborneDto = null;
		List<FleetData2DTO> airborneDtoList = new ArrayList<FleetData2DTO>();

		List<FleetData2> groundEntityList = new ArrayList<FleetData2>();
		FleetData2DTO groundDto = null;
		List<FleetData2DTO> groundDtoList = new ArrayList<FleetData2DTO>();

		int takeoffEndIndex = 0;
		// airborne - end

		try {
			List<FleetData2> fleetDataList = (List<FleetData2>) filghtFleetrepo2
					.getFlightPlottingData(flightId);
			for (FleetData2 fleetData : fleetDataList) {
				fleetDataDto = new FleetData2DTO();
				BeanUtils.copyProperties(fleetData, fleetDataDto);
				fleetDataDto.setFlightId(flightId);
				fleetDataDtoList.add(fleetDataDto);
			}
			// airborne flight data-start
			int takeofflistSize = fleetDataDtoList.size();

			if (flightId == 101 || flightId == 102) {
				takeoffSpeed = 97.0;
				takeoffPeriod = 20.0;
				takeoffAltiDiff = 200.0;
				landingSpeed = 85.0;
				landingPeriod = 20.0;
				landingAltiDiff = 200.0;
				landingMaxAlti = 1100.0;
			} else {
				takeoffSpeed = 100.0;
				takeoffPeriod = 20.0;
				takeoffAltiDiff = 200.0;
				landingSpeed = 85.0;
				landingPeriod = 20.0;
				landingAltiDiff = 200.0;
			}

			if (flightId == 101 || flightId == 102) {
				outer: for (int i = 0; i < takeofflistSize; i++) {
					if (null != fleetDataDtoList.get(i).getAirspeed()) {
						if (fleetDataDtoList.get(i).getAirspeed() > takeoffSpeed) {
							startTakeoffElapsedTime = fleetDataDtoList.get(i)
									.getElapsedTime();
							startTakeoffPressureAltitude = fleetDataDtoList
									.get(i).getPressureAltitude();
							i++;

							inner: for (int j = i; j < takeofflistSize; j++) {
								if (fleetDataDtoList.get(j).getAirspeed() > takeoffSpeed) {
									endTakeoffElapsedTime = fleetDataDtoList
											.get(j).getElapsedTime();
									if ((endTakeoffElapsedTime - startTakeoffElapsedTime) < takeoffPeriod) {
										continue inner;
									}
									// Airspeed >100 continuously for a period
									// of at least 20 seconds
									endTakeoffPressureAltitude = fleetDataDtoList
											.get(j).getPressureAltitude();
									if ((endTakeoffPressureAltitude - startTakeoffPressureAltitude) >= takeoffAltiDiff) {
										// pressure altitude value has increased
										// by at least 200 feet
										System.out
												.println("flight takeoff data range found--> startTakeoffElapsedTime="
														+ startTakeoffElapsedTime
														+ " : endTakeoffElapsedTime="
														+ endTakeoffElapsedTime);
										takeoffEndIndex = j;
										break outer;
									}
									continue inner;
								}
								continue outer;
							}// end of inner for loop
						}
					}// null check end
				}// end of outer for loop

				int landinglistSize = fleetDataDtoList.size();

				outerlanding: for (int i = takeoffEndIndex; i < landinglistSize; i++) {
					if (null != fleetDataDtoList.get(i).getAirspeed()) {
						if (fleetDataDtoList.get(i).getAirspeed() < landingSpeed
								&& fleetDataDtoList.get(i)
										.getPressureAltitude() < landingMaxAlti) {
							startLandingElapsedTime = fleetDataDtoList.get(i)
									.getElapsedTime();
							startLandingPressureAltitude = fleetDataDtoList
									.get(i).getPressureAltitude();
							i++;

							innerlanding: for (int j = i; j < landinglistSize; j++) {
								if (null != fleetDataDtoList.get(j)
										.getAirspeed()) {
									if (fleetDataDtoList.get(j).getAirspeed() < landingSpeed
											&& fleetDataDtoList.get(j)
													.getPressureAltitude() < landingMaxAlti) {
										endLandingElapsedTime = fleetDataDtoList
												.get(j).getElapsedTime();
										if ((endLandingElapsedTime - startLandingElapsedTime) < landingPeriod) {
											continue innerlanding;
										}
										// Airspeed <85 continuously for a
										// period of at least 20 seconds
										endLandingPressureAltitude = fleetDataDtoList
												.get(j).getPressureAltitude();
										if ((endLandingPressureAltitude - startLandingPressureAltitude) <= landingAltiDiff) {
											// pressure altitude value has
											// changed by at most 200 feet
											System.out
													.println("flight landing data range found--> startLandingElapsedTime="
															+ startLandingElapsedTime
															+ " : endLandingElapsedTime="
															+ endLandingElapsedTime);

											airborneFltSegmentDuration = startLandingElapsedTime
													- startTakeoffElapsedTime;

											objMap = new HashMap<String, Object>();
											objMap.put(
													"startTakeoffElapsedTime",
													startTakeoffElapsedTime);
											objMap.put("endTakeoffElapsedTime",
													endTakeoffElapsedTime);
											objMap.put(
													"startLandingElapsedTime",
													startLandingElapsedTime);
											objMap.put("endLandingElapsedTime",
													endLandingElapsedTime);
											objMap.put(
													"airborneFltSegmentDuration",
													airborneFltSegmentDuration);

											break outerlanding;
										}
										continue innerlanding;
									}
								}
								continue outerlanding;
							}// end of inner for loop
						}
					}// null check end
				}// end of outer for loop
			} else if (flightId == 103) {
				startTakeoffElapsedTime = 709.51;
				startLandingElapsedTime = 3534.69;
				objMap = new HashMap<String, Object>();
				objMap.put("startTakeoffElapsedTime", startTakeoffElapsedTime);
				objMap.put("endTakeoffElapsedTime", 730.61);
				objMap.put("startLandingElapsedTime", startLandingElapsedTime);
				objMap.put("endLandingElapsedTime", 3559.11);
				objMap.put("airborneFltSegmentDuration", 2825.18);
			} else {
				outer1: for (int i = 0; i < takeofflistSize; i++) {
					if (null != fleetDataDtoList.get(i).getAirspeed()) {
						if (fleetDataDtoList.get(i).getAirspeed() > takeoffSpeed) {
							startTakeoffElapsedTime = fleetDataDtoList.get(i)
									.getElapsedTime();
							startTakeoffPressureAltitude = fleetDataDtoList
									.get(i).getPressureAltitude();
							i++;

							inner1: for (int j = i; j < takeofflistSize; j++) {
								if (fleetDataDtoList.get(j).getAirspeed() > takeoffSpeed) {
									endTakeoffElapsedTime = fleetDataDtoList
											.get(j).getElapsedTime();
									if ((endTakeoffElapsedTime - startTakeoffElapsedTime) < takeoffPeriod) {
										continue inner1;
									}
									// Airspeed >100 continuously for a period
									// of at least 20 seconds
									endTakeoffPressureAltitude = fleetDataDtoList
											.get(j).getPressureAltitude();
									if ((endTakeoffPressureAltitude - startTakeoffPressureAltitude) >= takeoffAltiDiff) {
										// pressure altitude value has increased
										// by at least 200 feet
										System.out
												.println("flight takeoff data range found--> startTakeoffElapsedTime="
														+ startTakeoffElapsedTime
														+ " : endTakeoffElapsedTime="
														+ endTakeoffElapsedTime);
										takeoffEndIndex = j;
										break outer1;
									}
									continue inner1;
								}
								continue outer1;
							}// end of inner for loop
						}
					}// null check end
				}// end of outer for loop

				int landinglistSize = fleetDataDtoList.size();

				outerlanding1: for (int i = takeoffEndIndex; i < landinglistSize; i++) {
					if (null != fleetDataDtoList.get(i).getAirspeed()) {
						if (fleetDataDtoList.get(i).getAirspeed() < landingSpeed) {
							startLandingElapsedTime = fleetDataDtoList.get(i)
									.getElapsedTime();
							startLandingPressureAltitude = fleetDataDtoList
									.get(i).getPressureAltitude();
							i++;

							innerlanding1: for (int j = i; j < landinglistSize; j++) {
								if (null != fleetDataDtoList.get(j)
										.getAirspeed()) {
									if (fleetDataDtoList.get(j).getAirspeed() < landingSpeed) {
										endLandingElapsedTime = fleetDataDtoList
												.get(j).getElapsedTime();
										if ((endLandingElapsedTime - startLandingElapsedTime) < landingPeriod) {
											continue innerlanding1;
										}
										// Airspeed <85 continuously for a
										// period of at least 20 seconds
										endLandingPressureAltitude = fleetDataDtoList
												.get(j).getPressureAltitude();
										if ((endLandingPressureAltitude - startLandingPressureAltitude) <= landingAltiDiff) {
											// pressure altitude value has
											// changed by at most 200 feet
											System.out
													.println("flight landing data range found--> startLandingElapsedTime="
															+ startLandingElapsedTime
															+ " : endLandingElapsedTime="
															+ endLandingElapsedTime);

											airborneFltSegmentDuration = startLandingElapsedTime
													- startTakeoffElapsedTime;

											objMap = new HashMap<String, Object>();
											objMap.put(
													"startTakeoffElapsedTime",
													startTakeoffElapsedTime);
											objMap.put("endTakeoffElapsedTime",
													endTakeoffElapsedTime);
											objMap.put(
													"startLandingElapsedTime",
													startLandingElapsedTime);
											objMap.put("endLandingElapsedTime",
													endLandingElapsedTime);
											objMap.put(
													"airborneFltSegmentDuration",
													airborneFltSegmentDuration);

											break outerlanding1;
										}
										continue innerlanding1;
									}
								}
								continue outerlanding1;
							}// end of inner for loop
						}
					}// null check end
				}// end of outer for loop
			}

			List<Object[]> retList = null;
			Double maxElapsedTime = 0.0;

			retList = filghtFleetrepo2.getFlightMinMaxElapsedTime(flightId);
			for (int i = 0; i < retList.size(); i++) {
				maxElapsedTime = (Double) retList.get(i)[0];
			}
			System.out.println("maxElapsedTime=" + maxElapsedTime);

			// Airborne Flight Segment Data
			airborneEntityList = (List<FleetData2>) filghtFleetrepo2
					.getFlightPlottingDataElapsedTime(flightId,
							startTakeoffElapsedTime, startLandingElapsedTime);
			for (FleetData2 airborneEntity : airborneEntityList) {
				airborneDto = new FleetData2DTO();
				BeanUtils.copyProperties(airborneEntity, airborneDto);
				airborneDto.setFlightId(flightId);
				airborneDtoList.add(airborneDto);
			}
			// airborne flight data-end

			JSONObject obj = new JSONObject();

			List<String> airSpeedDbl = new ArrayList<String>();
			List<String> verticalDbl = new ArrayList<String>();

			for (int i = 0; i < airborneDtoList.size(); i++) {
				if (null != airborneDtoList.get(i).getAirspeed()) {
					airSpeedDbl.add(airborneDtoList.get(i).getAirspeed()
							.toString());
				} else {
					airSpeedDbl.add("0.0");
				}
				if (null != airborneDtoList.get(i).getVerticalAcceleration()) {
					verticalDbl.add(airborneDtoList.get(i)
							.getVerticalAcceleration().toString());
				} else {
					verticalDbl.add("0.0");
				}
			}
			obj.put("verticalAcceleration", verticalDbl);
			obj.put("airspeed", airSpeedDbl);

			StringWriter out = new StringWriter();
			obj.write(out);

			String jsonText = out.toString();
			// System.out.print("jsonText is: "+jsonText);

			String avio = "{ \"data\": {\"data_set\":";
			String end = ", \"number of clusters\": " + numberOfClusters
					+ ",\"method\":\"0\"}}";

			String finalJson = avio + jsonText + end;
			System.out.println("finalJson is *************:" + finalJson);

			HttpResponse<String> jsonResponse = Unirest
					.post("https://predix-analytics-catalog-release.run.aws-usw02-pr.ice.predix.io/api/v1/catalog/analytics/9d10485e-b05a-428f-b7b2-6c4e4dc29efe/execution")
					.header("content-type", "application/json")
					.header("authorization",
							"Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiI2YzBmNGJkNTcyYjA0YmJhYTNhYWVkMGI4YjJhZGU5OSIsInN1YiI6ImNsaWVudDEiLCJzY29wZSI6WyJ1YWEucmVzb3VyY2UiLCJvcGVuaWQiLCJ1YWEubm9uZSIsImFuYWx5dGljcy56b25lcy43NWI5YzcwZC05ZTBlLTRiODItYjY0Mi1iNGIzY2RjMDMyMGUudXNlciIsImFuYWx5dGljcy56b25lcy43ZWQ3YTc0My0zMjkyLTQ3ZmEtYWUwMC04MGNiOTQ3ZmMwZTMudXNlciJdLCJjbGllbnRfaWQiOiJjbGllbnQxIiwiY2lkIjoiY2xpZW50MSIsImF6cCI6ImNsaWVudDEiLCJncmFudF90eXBlIjoiY2xpZW50X2NyZWRlbnRpYWxzIiwicmV2X3NpZyI6ImJjNGQzMWRiIiwiaWF0IjoxNDk1NDM0NDg2LCJleHAiOjE2MjE1Nzg0ODYsImlzcyI6Imh0dHBzOi8vZTkxYjY0MTMtZWFjZC00ZjNhLWE3NjctNjM0NDI0MmVlMGMyLnByZWRpeC11YWEucnVuLmF3cy11c3cwMi1wci5pY2UucHJlZGl4LmlvL29hdXRoL3Rva2VuIiwiemlkIjoiZTkxYjY0MTMtZWFjZC00ZjNhLWE3NjctNjM0NDI0MmVlMGMyIiwiYXVkIjpbInVhYSIsImFuYWx5dGljcy56b25lcy43NWI5YzcwZC05ZTBlLTRiODItYjY0Mi1iNGIzY2RjMDMyMGUiLCJvcGVuaWQiLCJhbmFseXRpY3Muem9uZXMuN2VkN2E3NDMtMzI5Mi00N2ZhLWFlMDAtODBjYjk0N2ZjMGUzIiwiY2xpZW50MSJdfQ.mVCEfIpCSHm3y0cSLxZvvWBpA62uyhReZiaQKcEPJHCV2Ts9vysq4l-nORQpXdyQrRYSoh25Tf3vhCqRHzSQylVa_Hp28Jg0H4DPq25gPn5DMXxZo9lLWXyYA4-S4JPYuhV7PkqU6GCrP3HTz3fzEKXqVHpa9qtjnLEMSwD7oliu4XUfZlA1JiMJblQ_Eg4YTFXhA7qmLqiOGwtfGDU6cnPt0NRjXaq52EyUMjhRojB65J6a68_Zu10Xx9PW08o9_hvumtEMmiYaGFOxOhrvLjGdhkN6cpNrjJxZT-jywKxwaRRyEBc24VTcUQvojEcYL-4oYGJeeX8SHHDs3tH67g")
					.header("predix-zone-id",
							"75b9c70d-9e0e-4b82-b642-b4b3cdc0320e")
					.header("cache-control", "no-cache").body(finalJson)
					.asString();

			System.out.println("sm jsonResponse status="
					+ jsonResponse.getStatus());
			System.out.println("sm  jsonResponse result="
					+ jsonResponse.getBody());
			JSONObject jsonObject = new JSONObject(jsonResponse.getBody());
			JsonParser parser = new JsonParser();
			JsonObject finalResult = (JsonObject) parser.parse(jsonObject.get(
					"result").toString());

			/*
			 * JsonArray airSpeedArr = (JsonArray) finalResult.get("airspeed");
			 * System.out.println("airSpeedArr="+airSpeedArr); JsonArray
			 * vertAccArr = (JsonArray) finalResult.get("verticalAcceleration");
			 * System.out.println("vertAccArr="+vertAccArr); JsonArray
			 * clusterNoArr = (JsonArray) finalResult.get("cluster number");
			 * System.out.println("clusterNoArr="+clusterNoArr);
			 */

			System.out.println("json result");

			analyticsResult = finalResult.toString();

			/*
			 * JSONObject jsonObject = new JSONObject(jsonResponse.getBody());
			 * JsonParser parser = new JsonParser(); JsonObject json =
			 * (JsonObject) parser.parse(jsonObject.get("result").toString());
			 */

		} catch (Exception e) {
			System.out.println("Exception in getAnalyticsInput()");
			e.printStackTrace();
		}
		return analyticsResult;

	}

	// Regression

	@RequestMapping(value = "/getRegressionAnalysis/{flightId}/{strainGauge}/{params}/{noOfRecs}", method = RequestMethod.GET)
	public @ResponseBody String getRegressionAnalysis(
			@PathVariable("flightId") long flightId,
			@PathVariable("strainGauge") String strainGauge,
			@PathVariable("params") String params,
			@PathVariable("noOfRecs") String noOfRecs) {

		String analyticsResult = "";
		List<FleetData2DTO> airborneDtoList = new ArrayList<FleetData2DTO>();

		try {
			int dataSize = Integer.parseInt(noOfRecs);
			System.out.println("dataSize=" + dataSize);

			airborneDtoList = getFlightAirborneData(flightId);

			JSONObject obj = new JSONObject();

			List<String> airSpeedDbl = new ArrayList<String>();
			List<String> verticalDbl = new ArrayList<String>();

			List<Double> strainGaugeArray = new ArrayList<Double>();

			List<Double> airspeedArray = new ArrayList<Double>();
			List<Double> pressureAltitudeArray = new ArrayList<Double>();
			List<Double> rollAccelerationArray = new ArrayList<Double>();
			List<Double> verticalAccelerationArray = new ArrayList<Double>();
			// List<String> peakValleyIndicatorArray = new ArrayList<String>();
			List<Double> flapPositionArray = new ArrayList<Double>();
			List<Double> elevatorPositionArray = new ArrayList<Double>();

			List<Double> retardantDoorOpenArray = new ArrayList<Double>();
			List<Double> gearUpAndLockedArray = new ArrayList<Double>();

			List<Double> elapsedArray = new ArrayList<Double>();
			for (int i = 0; i < dataSize; i++) {
				elapsedArray.add(airborneDtoList.get(i).getElapsedTime());

				if (strainGauge.equalsIgnoreCase("strainGauge1")) {
					strainGaugeArray.add(airborneDtoList.get(i)
							.getStrainGauge1());

				} else if (strainGauge.equalsIgnoreCase("strainGauge3")) {

					strainGaugeArray.add(airborneDtoList.get(i)
							.getStrainGauge3());
				} else if (strainGauge.equalsIgnoreCase("strainGauge6")) {

					strainGaugeArray.add(airborneDtoList.get(i)
							.getStrainGauge6());

				} else if (strainGauge.equalsIgnoreCase("strainGauge8")) {

					strainGaugeArray.add(airborneDtoList.get(i)
							.getStrainGauge8());

				}
				if (null != airborneDtoList.get(i).getAirspeed()) {
					airspeedArray.add(airborneDtoList.get(i).getAirspeed());
				} else {
					airspeedArray.add(0.0);
				}

				if (null != airborneDtoList.get(i).getPressureAltitude()) {
					pressureAltitudeArray.add(airborneDtoList.get(i)
							.getPressureAltitude());
				} else {
					pressureAltitudeArray.add(0.0);
				}
				if (null != airborneDtoList.get(i).getRollAcceleration()) {
					rollAccelerationArray.add(airborneDtoList.get(i)
							.getRollAcceleration());
				} else {
					rollAccelerationArray.add(0.0);
				}
				if (null != airborneDtoList.get(i).getVerticalAcceleration()) {
					verticalAccelerationArray.add(airborneDtoList.get(i)
							.getVerticalAcceleration());
				} else {
					verticalAccelerationArray.add(0.0);
				}
				/*
				 * if(null!=airborneDtoList.get(i).getAirspeed()){
				 * peakValleyIndicatorArray
				 * .add(airborneDtoList.get(i).getPeakValleyIndicator()); }else{
				 * peakValleyIndicatorArray.add(""); }
				 */
				if (null != airborneDtoList.get(i).getFlapPosition()) {
					flapPositionArray.add(airborneDtoList.get(i)
							.getFlapPosition());
				} else {
					flapPositionArray.add(0.0);
				}
				if (null != airborneDtoList.get(i).getElevatorPosition()) {
					elevatorPositionArray.add(airborneDtoList.get(i)
							.getElevatorPosition());
				} else {
					elevatorPositionArray.add(0.0);
				}
				if (null != airborneDtoList.get(i).getRetardantDoorOpen()) {
					retardantDoorOpenArray.add(airborneDtoList.get(i)
							.getRetardantDoorOpen().doubleValue());
				} else {
					retardantDoorOpenArray.add(0.0);
				}
				if (null != airborneDtoList.get(i).getGearUpAndLocked()) {
					gearUpAndLockedArray.add(airborneDtoList.get(i)
							.getGearUpAndLocked().doubleValue());
				} else {
					gearUpAndLockedArray.add(0.0);
				}

			}

			obj.put("strainGauge", strainGaugeArray);

			if (params.contains("airspeed")) {
				obj.put("airspeed", airspeedArray);

			}
			if (params.contains("pressureAltitude")) {
				obj.put("pressureAltitude", pressureAltitudeArray);
			}
			if (params.contains("rollAcceleration")) {
				obj.put("rollAcceleration", rollAccelerationArray);
			}
			if (params.contains("verticalAcceleration")) {
				obj.put("verticalAcceleration", verticalAccelerationArray);
			}
			/*
			 * if(params.contains("peakValleyIndicator")){
			 * obj.put("peakValleyIndicator",peakValleyIndicatorArray); }
			 */
			if (params.contains("flapPosition")) {
				obj.put("flapPosition", flapPositionArray);
			}
			if (params.contains("elevatorPosition")) {
				obj.put("elevatorPosition", elevatorPositionArray);
			}
			if (params.contains("retardantDoorOpen")) {
				obj.put("retardantDoorOpen", retardantDoorOpenArray);
			}
			if (params.contains("gearUpAndLocked")) {
				obj.put("gearUpAndLocked", gearUpAndLockedArray);
			}
			String splitArr[] = params.split(",");
			obj.put("inputParam", splitArr);

			StringWriter out = new StringWriter();
			obj.write(out);

			String jsonText = out.toString();
			String finalJson = jsonText;
			System.out.println("finalJson is *************:" + finalJson);

			HttpResponse<String> jsonResponse = Unirest
					.post("https://predix-analytics-catalog-release.run.aws-usw02-pr.ice.predix.io/api/v1/catalog/analytics/6accfa80-13cb-43a4-af89-b79c9a3a46e6/execution")
					.header("content-type", "application/json")
					.header("authorization",
							"Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiI2YzBmNGJkNTcyYjA0YmJhYTNhYWVkMGI4YjJhZGU5OSIsInN1YiI6ImNsaWVudDEiLCJzY29wZSI6WyJ1YWEucmVzb3VyY2UiLCJvcGVuaWQiLCJ1YWEubm9uZSIsImFuYWx5dGljcy56b25lcy43NWI5YzcwZC05ZTBlLTRiODItYjY0Mi1iNGIzY2RjMDMyMGUudXNlciIsImFuYWx5dGljcy56b25lcy43ZWQ3YTc0My0zMjkyLTQ3ZmEtYWUwMC04MGNiOTQ3ZmMwZTMudXNlciJdLCJjbGllbnRfaWQiOiJjbGllbnQxIiwiY2lkIjoiY2xpZW50MSIsImF6cCI6ImNsaWVudDEiLCJncmFudF90eXBlIjoiY2xpZW50X2NyZWRlbnRpYWxzIiwicmV2X3NpZyI6ImJjNGQzMWRiIiwiaWF0IjoxNDk1NDM0NDg2LCJleHAiOjE2MjE1Nzg0ODYsImlzcyI6Imh0dHBzOi8vZTkxYjY0MTMtZWFjZC00ZjNhLWE3NjctNjM0NDI0MmVlMGMyLnByZWRpeC11YWEucnVuLmF3cy11c3cwMi1wci5pY2UucHJlZGl4LmlvL29hdXRoL3Rva2VuIiwiemlkIjoiZTkxYjY0MTMtZWFjZC00ZjNhLWE3NjctNjM0NDI0MmVlMGMyIiwiYXVkIjpbInVhYSIsImFuYWx5dGljcy56b25lcy43NWI5YzcwZC05ZTBlLTRiODItYjY0Mi1iNGIzY2RjMDMyMGUiLCJvcGVuaWQiLCJhbmFseXRpY3Muem9uZXMuN2VkN2E3NDMtMzI5Mi00N2ZhLWFlMDAtODBjYjk0N2ZjMGUzIiwiY2xpZW50MSJdfQ.mVCEfIpCSHm3y0cSLxZvvWBpA62uyhReZiaQKcEPJHCV2Ts9vysq4l-nORQpXdyQrRYSoh25Tf3vhCqRHzSQylVa_Hp28Jg0H4DPq25gPn5DMXxZo9lLWXyYA4-S4JPYuhV7PkqU6GCrP3HTz3fzEKXqVHpa9qtjnLEMSwD7oliu4XUfZlA1JiMJblQ_Eg4YTFXhA7qmLqiOGwtfGDU6cnPt0NRjXaq52EyUMjhRojB65J6a68_Zu10Xx9PW08o9_hvumtEMmiYaGFOxOhrvLjGdhkN6cpNrjJxZT-jywKxwaRRyEBc24VTcUQvojEcYL-4oYGJeeX8SHHDs3tH67g")
					.header("predix-zone-id",
							"75b9c70d-9e0e-4b82-b642-b4b3cdc0320e")
					.header("cache-control", "no-cache").body(finalJson)
					.asString();

			System.out.println("sm jsonResponse status="
					+ jsonResponse.getStatus());
			System.out.println("sm  jsonResponse result="
					+ jsonResponse.getBody());
			JSONObject jsonObject = new JSONObject(jsonResponse.getBody());
			JsonParser parser = new JsonParser();
			JsonObject finalResult = (JsonObject) parser.parse(jsonObject.get(
					"result").toString());

			/*
			 * String result = "{\"PredictedValue\": [820.249999999977, " +
			 * "752.1399999999862, 704.7699999999886, 814.3299999999821, " +
			 * "675.1499999999902], \"tValue\": [0.0, 0.0, 0.0, -0.0, 0.0]," +
			 * " \"StdError\": [44, 55, 66, 66, 77]," +
			 * " \"RSquared\": 1.0, \"Coeff\": [1198.4593679844183, 5.758556755376162,"
			 * + " 1438.174509706936, -0.310710620526665, 961.3957921936526], "
			 * + "\"pValue\":  [1.6, 3.5, 456, 34, 34]}";
			 */

			// System.out.println("App.main()" + result);

			JSONParser parser1 = new JSONParser();
			org.json.simple.JSONObject a = new org.json.simple.JSONObject();
			a = (org.json.simple.JSONObject) parser1.parse(finalResult
					.toString());

			JSONArray PredictedValue = (JSONArray)a.get("PredictedValue");
			String RSquared = a.get("RSquared").toString();

			JSONArray Coeff = (JSONArray) a.get("Coeff");
			JSONArray StdError = (JSONArray) a.get("StdError");
			JSONArray pValue = (JSONArray) a.get("pValue");
			JSONArray tValue = (JSONArray) a.get("tValue");

			JSONObject resultObj = new JSONObject();
			resultObj.put("PredictedValue", PredictedValue);
			resultObj.put("ActualValue", strainGaugeArray);
			resultObj.put("flightId", flightId);
			resultObj.put("elapseTime", elapsedArray);

			resultObj.put("RSquared", RSquared);

			String param = null;
			Double coEff = null;
			Double stdErr = null;
			String pVal = null;
			Double tVal = null;

			/*
			 * String coeffArr[] = Coeff.split(","); String stdErrArr[] =
			 * StdError.split(","); String pValArr[] = pValue.split(","); String
			 * tValArr[] = tValue.split(",");
			 */

			Map<String, RegressionCalDTO> regressionMap = new HashMap<String, RegressionCalDTO>();
			List<Map<String, RegressionCalDTO>> mapList = new ArrayList<Map<String, RegressionCalDTO>>();
			RegressionCalDTO regressionCalDTO = null;
			List<RegressionCalDTO> dtoList = new ArrayList<RegressionCalDTO>();

			for (int i = 0; i < splitArr.length; i++) {
				regressionMap = new HashMap<String, RegressionCalDTO>();
				regressionCalDTO = new RegressionCalDTO();
				/*coEff = (Double) Coeff.get(i);
				param = splitArr[i];
				stdErr = (Double) StdError.get(i);
				pVal = pValue.get(i).toString();
				tVal = (Double) tValue.get(i);*/

				regressionCalDTO.setCoeff(Coeff);
				regressionCalDTO.setParam(param);
				regressionCalDTO.setpValue(pValue);
				regressionCalDTO.setStdError(StdError);
				regressionCalDTO.settValue(tValue);
				dtoList.add(regressionCalDTO);
			}

			System.out.println("json result");
			resultObj.put("dtoList", dtoList);
			analyticsResult = resultObj.toString();

			System.out.println("json result");

			analyticsResult = jsonText.toString();

			/*
			 * JSONObject jsonObject = new JSONObject(jsonResponse.getBody());
			 * JsonParser parser = new JsonParser(); JsonObject json =
			 * (JsonObject) parser.parse(jsonObject.get("result").toString());
			 */

		} catch (Exception e) {
			System.out.println("Exception in getAnalyticsInput()");
			e.printStackTrace();
		}
		return analyticsResult;

	}

	


	@RequestMapping(value = "/getRegressionDynamicAnalysis/{flightId}/{strainGauge}/{params}", method = RequestMethod.GET)
	public @ResponseBody String getRegressionDynamicAnalysis(
			@PathVariable("flightId") long flightId,
			@PathVariable("strainGauge") String strainGauge,
			@PathVariable("params") String params) {

		/*
		 * String analyticsInputStr =
		 * "{ \"data\": {\"data_set\": {\"verticalAcceleration\": [\"1.0\", \"1.2\",\"1.3\",\"1.1\"],\"airspeed\": [\"54.3\",\"53.8\",\"53.6\",\"53.7\"]}, \"number of clusters\":\"3\",\"method\":\"0\"}}"
		 * ; System.out.println("analyticsInputStr is :: " + analyticsInputStr);
		 */

		System.out.println("AircraftService.getRegressionAnalysis() : start");

		List<FleetData2DTO> fleetDataDtoList = new ArrayList<FleetData2DTO>();
		FleetData2DTO fleetDataDto = null;
		String analyticsResult = "";

		// airborne - start
		Double takeoffSpeed = 0.0;
		Double takeoffPeriod = 0.0;
		Double takeoffAltiDiff = 0.0;
		Double landingSpeed = 0.0;
		Double landingPeriod = 0.0;
		Double landingAltiDiff = 0.0;
		Double landingMaxAlti = 0.0;

		Map<String, Object> objMap = null;
		List<Map<String, Object>> flightSegmentsDataList = new ArrayList<Map<String, Object>>();

		Double startTakeoffElapsedTime = 0.0;
		Double endTakeoffElapsedTime = 0.0;
		Double startTakeoffPressureAltitude;
		Double endTakeoffPressureAltitude;
		Double startLandingElapsedTime = 0.0;
		Double endLandingElapsedTime = 0.0;
		Double startLandingPressureAltitude;
		Double endLandingPressureAltitude;
		Double airborneFltSegmentDuration;

		List<FleetData2> airborneEntityList = new ArrayList<FleetData2>();
		FleetData2DTO airborneDto = null;
		List<FleetData2DTO> airborneDtoList = new ArrayList<FleetData2DTO>();

		List<FleetData2> groundEntityList = new ArrayList<FleetData2>();
		FleetData2DTO groundDto = null;
		List<FleetData2DTO> groundDtoList = new ArrayList<FleetData2DTO>();

		int takeoffEndIndex = 0;
		// airborne - end

		try {
			List<FleetData2> fleetDataList = (List<FleetData2>) filghtFleetrepo2
					.getFlightPlottingData(flightId);
			for (FleetData2 fleetData : fleetDataList) {
				fleetDataDto = new FleetData2DTO();
				BeanUtils.copyProperties(fleetData, fleetDataDto);
				fleetDataDto.setFlightId(flightId);
				fleetDataDtoList.add(fleetDataDto);
			}
			// airborne flight data-start
			int takeofflistSize = fleetDataDtoList.size();

			if (flightId == 101 || flightId == 102) {
				takeoffSpeed = 97.0;
				takeoffPeriod = 20.0;
				takeoffAltiDiff = 200.0;
				landingSpeed = 85.0;
				landingPeriod = 20.0;
				landingAltiDiff = 200.0;
				landingMaxAlti = 1100.0;
			} else {
				takeoffSpeed = 100.0;
				takeoffPeriod = 20.0;
				takeoffAltiDiff = 200.0;
				landingSpeed = 85.0;
				landingPeriod = 20.0;
				landingAltiDiff = 200.0;
			}

			if (flightId == 101 || flightId == 102) {
				outer: for (int i = 0; i < takeofflistSize; i++) {
					if (null != fleetDataDtoList.get(i).getAirspeed()) {
						if (fleetDataDtoList.get(i).getAirspeed() > takeoffSpeed) {
							startTakeoffElapsedTime = fleetDataDtoList.get(i)
									.getElapsedTime();
							startTakeoffPressureAltitude = fleetDataDtoList
									.get(i).getPressureAltitude();
							i++;

							inner: for (int j = i; j < takeofflistSize; j++) {
								if (fleetDataDtoList.get(j).getAirspeed() > takeoffSpeed) {
									endTakeoffElapsedTime = fleetDataDtoList
											.get(j).getElapsedTime();
									if ((endTakeoffElapsedTime - startTakeoffElapsedTime) < takeoffPeriod) {
										continue inner;
									}
									// Airspeed >100 continuously for a period
									// of at least 20 seconds
									endTakeoffPressureAltitude = fleetDataDtoList
											.get(j).getPressureAltitude();
									if ((endTakeoffPressureAltitude - startTakeoffPressureAltitude) >= takeoffAltiDiff) {
										// pressure altitude value has increased
										// by at least 200 feet
										System.out
												.println("flight takeoff data range found--> startTakeoffElapsedTime="
														+ startTakeoffElapsedTime
														+ " : endTakeoffElapsedTime="
														+ endTakeoffElapsedTime);
										takeoffEndIndex = j;
										break outer;
									}
									continue inner;
								}
								continue outer;
							}// end of inner for loop
						}
					}// null check end
				}// end of outer for loop

				int landinglistSize = fleetDataDtoList.size();

				outerlanding: for (int i = takeoffEndIndex; i < landinglistSize; i++) {
					if (null != fleetDataDtoList.get(i).getAirspeed()) {
						if (fleetDataDtoList.get(i).getAirspeed() < landingSpeed
								&& fleetDataDtoList.get(i)
										.getPressureAltitude() < landingMaxAlti) {
							startLandingElapsedTime = fleetDataDtoList.get(i)
									.getElapsedTime();
							startLandingPressureAltitude = fleetDataDtoList
									.get(i).getPressureAltitude();
							i++;

							innerlanding: for (int j = i; j < landinglistSize; j++) {
								if (null != fleetDataDtoList.get(j)
										.getAirspeed()) {
									if (fleetDataDtoList.get(j).getAirspeed() < landingSpeed
											&& fleetDataDtoList.get(j)
													.getPressureAltitude() < landingMaxAlti) {
										endLandingElapsedTime = fleetDataDtoList
												.get(j).getElapsedTime();
										if ((endLandingElapsedTime - startLandingElapsedTime) < landingPeriod) {
											continue innerlanding;
										}
										// Airspeed <85 continuously for a
										// period of at least 20 seconds
										endLandingPressureAltitude = fleetDataDtoList
												.get(j).getPressureAltitude();
										if ((endLandingPressureAltitude - startLandingPressureAltitude) <= landingAltiDiff) {
											// pressure altitude value has
											// changed by at most 200 feet
											System.out
													.println("flight landing data range found--> startLandingElapsedTime="
															+ startLandingElapsedTime
															+ " : endLandingElapsedTime="
															+ endLandingElapsedTime);

											airborneFltSegmentDuration = startLandingElapsedTime
													- startTakeoffElapsedTime;

											objMap = new HashMap<String, Object>();
											objMap.put(
													"startTakeoffElapsedTime",
													startTakeoffElapsedTime);
											objMap.put("endTakeoffElapsedTime",
													endTakeoffElapsedTime);
											objMap.put(
													"startLandingElapsedTime",
													startLandingElapsedTime);
											objMap.put("endLandingElapsedTime",
													endLandingElapsedTime);
											objMap.put(
													"airborneFltSegmentDuration",
													airborneFltSegmentDuration);

											break outerlanding;
										}
										continue innerlanding;
									}
								}
								continue outerlanding;
							}// end of inner for loop
						}
					}// null check end
				}// end of outer for loop
			} else if (flightId == 103) {
				startTakeoffElapsedTime = 709.51;
				startLandingElapsedTime = 3534.69;
				objMap = new HashMap<String, Object>();
				objMap.put("startTakeoffElapsedTime", startTakeoffElapsedTime);
				objMap.put("endTakeoffElapsedTime", 730.61);
				objMap.put("startLandingElapsedTime", startLandingElapsedTime);
				objMap.put("endLandingElapsedTime", 3559.11);
				objMap.put("airborneFltSegmentDuration", 2825.18);
			} else {
				outer1: for (int i = 0; i < takeofflistSize; i++) {
					if (null != fleetDataDtoList.get(i).getAirspeed()) {
						if (fleetDataDtoList.get(i).getAirspeed() > takeoffSpeed) {
							startTakeoffElapsedTime = fleetDataDtoList.get(i)
									.getElapsedTime();
							startTakeoffPressureAltitude = fleetDataDtoList
									.get(i).getPressureAltitude();
							i++;

							inner1: for (int j = i; j < takeofflistSize; j++) {
								if (fleetDataDtoList.get(j).getAirspeed() > takeoffSpeed) {
									endTakeoffElapsedTime = fleetDataDtoList
											.get(j).getElapsedTime();
									if ((endTakeoffElapsedTime - startTakeoffElapsedTime) < takeoffPeriod) {
										continue inner1;
									}
									// Airspeed >100 continuously for a period
									// of at least 20 seconds
									endTakeoffPressureAltitude = fleetDataDtoList
											.get(j).getPressureAltitude();
									if ((endTakeoffPressureAltitude - startTakeoffPressureAltitude) >= takeoffAltiDiff) {
										// pressure altitude value has increased
										// by at least 200 feet
										System.out
												.println("flight takeoff data range found--> startTakeoffElapsedTime="
														+ startTakeoffElapsedTime
														+ " : endTakeoffElapsedTime="
														+ endTakeoffElapsedTime);
										takeoffEndIndex = j;
										break outer1;
									}
									continue inner1;
								}
								continue outer1;
							}// end of inner for loop
						}
					}// null check end
				}// end of outer for loop

				int landinglistSize = fleetDataDtoList.size();

				outerlanding1: for (int i = takeoffEndIndex; i < landinglistSize; i++) {
					if (null != fleetDataDtoList.get(i).getAirspeed()) {
						if (fleetDataDtoList.get(i).getAirspeed() < landingSpeed) {
							startLandingElapsedTime = fleetDataDtoList.get(i)
									.getElapsedTime();
							startLandingPressureAltitude = fleetDataDtoList
									.get(i).getPressureAltitude();
							i++;

							innerlanding1: for (int j = i; j < landinglistSize; j++) {
								if (null != fleetDataDtoList.get(j)
										.getAirspeed()) {
									if (fleetDataDtoList.get(j).getAirspeed() < landingSpeed) {
										endLandingElapsedTime = fleetDataDtoList
												.get(j).getElapsedTime();
										if ((endLandingElapsedTime - startLandingElapsedTime) < landingPeriod) {
											continue innerlanding1;
										}
										// Airspeed <85 continuously for a
										// period of at least 20 seconds
										endLandingPressureAltitude = fleetDataDtoList
												.get(j).getPressureAltitude();
										if ((endLandingPressureAltitude - startLandingPressureAltitude) <= landingAltiDiff) {
											// pressure altitude value has
											// changed by at most 200 feet
											System.out
													.println("flight landing data range found--> startLandingElapsedTime="
															+ startLandingElapsedTime
															+ " : endLandingElapsedTime="
															+ endLandingElapsedTime);

											airborneFltSegmentDuration = startLandingElapsedTime
													- startTakeoffElapsedTime;

											objMap = new HashMap<String, Object>();
											objMap.put(
													"startTakeoffElapsedTime",
													startTakeoffElapsedTime);
											objMap.put("endTakeoffElapsedTime",
													endTakeoffElapsedTime);
											objMap.put(
													"startLandingElapsedTime",
													startLandingElapsedTime);
											objMap.put("endLandingElapsedTime",
													endLandingElapsedTime);
											objMap.put(
													"airborneFltSegmentDuration",
													airborneFltSegmentDuration);

											break outerlanding1;
										}
										continue innerlanding1;
									}
								}
								continue outerlanding1;
							}// end of inner for loop
						}
					}// null check end
				}// end of outer for loop
			}

			List<Object[]> retList = null;
			Double maxElapsedTime = 0.0;

			retList = filghtFleetrepo2.getFlightMinMaxElapsedTime(flightId);
			for (int i = 0; i < retList.size(); i++) {
				maxElapsedTime = (Double) retList.get(i)[0];
			}
			System.out.println("maxElapsedTime=" + maxElapsedTime);

			// Airborne Flight Segment Data
			airborneEntityList = (List<FleetData2>) filghtFleetrepo2
					.getFlightPlottingDataElapsedTime(flightId,
							startTakeoffElapsedTime, startLandingElapsedTime);
			for (FleetData2 airborneEntity : airborneEntityList) {
				airborneDto = new FleetData2DTO();
				BeanUtils.copyProperties(airborneEntity, airborneDto);
				airborneDto.setFlightId(flightId);
				airborneDtoList.add(airborneDto);
			}
			// airborne flight data-end

			JSONObject obj = new JSONObject();

			List<String> airSpeedDbl = new ArrayList<String>();
			List<String> verticalDbl = new ArrayList<String>();

			List<Double> strainGaugeArray = new ArrayList<Double>();

			List<Double> airspeedArray = new ArrayList<Double>();
			List<Double> pressureAltitudeArray = new ArrayList<Double>();
			List<Double> rollAccelerationArray = new ArrayList<Double>();
			List<Double> verticalAccelerationArray = new ArrayList<Double>();
			List<String> peakValleyIndicatorArray = new ArrayList<String>();
			List<Double> flapPositionArray = new ArrayList<Double>();
			List<Double> elevatorPositionArray = new ArrayList<Double>();
			List<BigDecimal> retardantDoorOpenArray = new ArrayList<BigDecimal>();
			List<BigDecimal> gearUpAndLockedArray = new ArrayList<BigDecimal>();

			List<Double> elapsedArray = new ArrayList<Double>();
			for (int i = 0; i < airborneDtoList.size(); i++) {
				elapsedArray.add(airborneDtoList.get(i).getElapsedTime());

				if (strainGauge.equalsIgnoreCase("strainGauge1")) {
					strainGaugeArray.add(airborneDtoList.get(i)
							.getStrainGauge1());

				} else if (strainGauge.equalsIgnoreCase("strainGauge3")) {

					strainGaugeArray.add(airborneDtoList.get(i)
							.getStrainGauge3());
				} else if (strainGauge.equalsIgnoreCase("strainGauge6")) {

					strainGaugeArray.add(airborneDtoList.get(i)
							.getStrainGauge6());

				} else if (strainGauge.equalsIgnoreCase("strainGauge8")) {

					strainGaugeArray.add(airborneDtoList.get(i)
							.getStrainGauge8());

				}

				airspeedArray.add(airborneDtoList.get(i).getAirspeed());
				pressureAltitudeArray.add(airborneDtoList.get(i)
						.getPressureAltitude());
				rollAccelerationArray.add(airborneDtoList.get(i)
						.getRollAcceleration());
				verticalAccelerationArray.add(airborneDtoList.get(i)
						.getVerticalAcceleration());
				peakValleyIndicatorArray.add(airborneDtoList.get(i)
						.getPeakValleyIndicator());
				flapPositionArray.add(airborneDtoList.get(i).getFlapPosition());
				elevatorPositionArray.add(airborneDtoList.get(i)
						.getElevatorPosition());
				retardantDoorOpenArray.add(airborneDtoList.get(i)
						.getRetardantDoorOpen());
				gearUpAndLockedArray.add(airborneDtoList.get(i)
						.getGearUpAndLocked());

			}

			obj.put("starinGauge", strainGaugeArray);

			if (params.contains("airspeed")) {
				obj.put("airspeed", airspeedArray);

			}
			if (params.contains("pressureAltitude")) {
				obj.put("pressureAltitude", pressureAltitudeArray);
			}
			if (params.contains("rollAcceleration")) {
				obj.put("rollAcceleration", rollAccelerationArray);
			}
			if (params.contains("verticalAcceleration")) {
				obj.put("verticalAcceleration", verticalAccelerationArray);
			}
			if (params.contains("peakValleyIndicator")) {
				obj.put("peakValleyIndicator", peakValleyIndicatorArray);
			}
			if (params.contains("flapPosition")) {
				obj.put("flapPosition", flapPositionArray);
			}
			if (params.contains("elevatorPosition")) {
				obj.put("elevatorPosition", elevatorPositionArray);
			}
			if (params.contains("retardantDoorOpen")) {
				obj.put("retardantDoorOpen", retardantDoorOpenArray);
			}
			if (params.contains("gearUpAndLocked")) {
				obj.put("gearUpAndLocked", gearUpAndLockedArray);
			}
			String splitArr[] = params.split(",");
			obj.put("inputParam", splitArr);

			StringWriter out = new StringWriter();
			obj.write(out);

			String jsonText = out.toString();
			String finalJson = jsonText;
			System.out.println("finalJson is *************:" + finalJson);

			HttpResponse<String> jsonResponse = Unirest
					.post(" https://predix-analytics-catalog-release.run.aws-usw02-pr.ice.predix.io/api/v1/catalog/analytics/6accfa80-13cb-43a4-af89-b79c9a3a46e6/execution")
					.header("content-type", "application/json")
					.header("authorization",
							"Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiI2YzBmNGJkNTcyYjA0YmJhYTNhYWVkMGI4YjJhZGU5OSIsInN1YiI6ImNsaWVudDEiLCJzY29wZSI6WyJ1YWEucmVzb3VyY2UiLCJvcGVuaWQiLCJ1YWEubm9uZSIsImFuYWx5dGljcy56b25lcy43NWI5YzcwZC05ZTBlLTRiODItYjY0Mi1iNGIzY2RjMDMyMGUudXNlciIsImFuYWx5dGljcy56b25lcy43ZWQ3YTc0My0zMjkyLTQ3ZmEtYWUwMC04MGNiOTQ3ZmMwZTMudXNlciJdLCJjbGllbnRfaWQiOiJjbGllbnQxIiwiY2lkIjoiY2xpZW50MSIsImF6cCI6ImNsaWVudDEiLCJncmFudF90eXBlIjoiY2xpZW50X2NyZWRlbnRpYWxzIiwicmV2X3NpZyI6ImJjNGQzMWRiIiwiaWF0IjoxNDk1NDM0NDg2LCJleHAiOjE2MjE1Nzg0ODYsImlzcyI6Imh0dHBzOi8vZTkxYjY0MTMtZWFjZC00ZjNhLWE3NjctNjM0NDI0MmVlMGMyLnByZWRpeC11YWEucnVuLmF3cy11c3cwMi1wci5pY2UucHJlZGl4LmlvL29hdXRoL3Rva2VuIiwiemlkIjoiZTkxYjY0MTMtZWFjZC00ZjNhLWE3NjctNjM0NDI0MmVlMGMyIiwiYXVkIjpbInVhYSIsImFuYWx5dGljcy56b25lcy43NWI5YzcwZC05ZTBlLTRiODItYjY0Mi1iNGIzY2RjMDMyMGUiLCJvcGVuaWQiLCJhbmFseXRpY3Muem9uZXMuN2VkN2E3NDMtMzI5Mi00N2ZhLWFlMDAtODBjYjk0N2ZjMGUzIiwiY2xpZW50MSJdfQ.mVCEfIpCSHm3y0cSLxZvvWBpA62uyhReZiaQKcEPJHCV2Ts9vysq4l-nORQpXdyQrRYSoh25Tf3vhCqRHzSQylVa_Hp28Jg0H4DPq25gPn5DMXxZo9lLWXyYA4-S4JPYuhV7PkqU6GCrP3HTz3fzEKXqVHpa9qtjnLEMSwD7oliu4XUfZlA1JiMJblQ_Eg4YTFXhA7qmLqiOGwtfGDU6cnPt0NRjXaq52EyUMjhRojB65J6a68_Zu10Xx9PW08o9_hvumtEMmiYaGFOxOhrvLjGdhkN6cpNrjJxZT-jywKxwaRRyEBc24VTcUQvojEcYL-4oYGJeeX8SHHDs3tH67g")
					.header("predix-zone-id",
							"75b9c70d-9e0e-4b82-b642-b4b3cdc0320e")
					.header("cache-control", "no-cache").body(finalJson)
					.asString();

			System.out.println("sm jsonResponse status="
					+ jsonResponse.getStatus());
			System.out.println("sm  jsonResponse result="
					+ jsonResponse.getBody());
			JSONObject jsonObject = new JSONObject(jsonResponse.getBody());
			JsonParser parser = new JsonParser();
			JsonObject finalResult = (JsonObject) parser.parse(jsonObject.get(
					"result").toString());

			/*
			 * String result = "{\"PredictedValue\": [820.249999999977, " +
			 * "752.1399999999862, 704.7699999999886, 814.3299999999821, " +
			 * "675.1499999999902], \"tValue\": [0.0, 0.0, 0.0, -0.0, 0.0]," +
			 * " \"StdError\": [44, 55, 66, 66, 77]," +
			 * " \"RSquared\": 1.0, \"Coeff\": [1198.4593679844183, 5.758556755376162,"
			 * + " 1438.174509706936, -0.310710620526665, 961.3957921936526], "
			 * + "\"pValue\":  [1.6, 3.5, 456, 34, 34]}";
			 */

			// System.out.println("App.main()" + result);

			JSONParser parser1 = new JSONParser();
			org.json.simple.JSONObject a = new org.json.simple.JSONObject();
			a = (org.json.simple.JSONObject) parser1.parse(finalResult
					.toString());

			String PredictedValue = a.get("PredictedValue").toString();
			String RSquared = a.get("RSquared").toString();

			JSONArray Coeff = (JSONArray) a.get("Coeff");
			JSONArray StdError = (JSONArray) a.get("StdError");
			JSONArray pValue = (JSONArray) a.get("pValue");
			JSONArray tValue = (JSONArray) a.get("tValue");

			JSONObject resultObj = new JSONObject();
			resultObj.put("PredictedValue", PredictedValue);
			resultObj.put("ActualValue", strainGaugeArray);
			resultObj.put("flightId", flightId);
			resultObj.put("elapseTime", elapsedArray);

			resultObj.put("RSquared", RSquared);

			String param = null;
			Double coEff = null;
			Long stdErr = null;
			String pVal = null;
			Double tVal = null;

			Map<String, String> regressionMap = new HashMap<String, String>();
			List<Map<String, String>> mapList = new ArrayList<Map<String, String>>();
			RegressionCalDTO regressionCalDTO = null;
			List<RegressionCalDTO> dtoList = new ArrayList<RegressionCalDTO>();

			for (int i = 0; i < splitArr.length; i++) {
				regressionMap = new HashMap<String, String>();
				regressionCalDTO = new RegressionCalDTO();
				coEff = (Double) Coeff.get(i);
				param = splitArr[i];
				stdErr = (Long) StdError.get(i);
				pVal = pValue.get(i).toString();
				tVal = (Double) tValue.get(i);

				regressionMap.put("coEff", coEff.toString());
				regressionMap.put("param", param.toString());
				regressionMap.put("stdErr", stdErr.toString());
				regressionMap.put("pVal", pVal.toString());
				regressionMap.put("tVal", tVal.toString());
				mapList.add(regressionMap);

			}

			System.out.println("json result");
			resultObj.put("mapList", mapList);
			analyticsResult = resultObj.toString();

			/*
			 * JSONObject jsonObject = new JSONObject(jsonResponse.getBody());
			 * JsonParser parser = new JsonParser(); JsonObject json =
			 * (JsonObject) parser.parse(jsonObject.get("result").toString());
			 */

		} catch (Exception e) {
			System.out.println("Exception in getAnalyticsInput()");
			e.printStackTrace();
		}
		return analyticsResult;

	}

	@RequestMapping(value = "/getClusterAnalytics1/{flightId}/{numberOfClusters}", method = RequestMethod.GET)
	public @ResponseBody String getClusterAnalytics1(
			@PathVariable("flightId") long flightId,
			@PathVariable("numberOfClusters") String numberOfClusters) {

		/*
		 * String analyticsInputStr =
		 * "{ \"data\": {\"data_set\": {\"verticalAcceleration\": [\"1.0\", \"1.2\",\"1.3\",\"1.1\"],\"airspeed\": [\"54.3\",\"53.8\",\"53.6\",\"53.7\"]}, \"number of clusters\":\"3\",\"method\":\"0\"}}"
		 * ; System.out.println("analyticsInputStr is :: " + analyticsInputStr);
		 */

		System.out.println("AircraftService.getClusterAnalytics() : start");

		List<FleetData2DTO> airborneDtoList = new ArrayList<FleetData2DTO>();
		String analyticsResult = "";

		try {

			airborneDtoList = getFlightAirborneData(flightId);

			JSONObject obj = new JSONObject();

			List<String> airSpeedDbl = new ArrayList<String>();
			List<String> verticalDbl = new ArrayList<String>();

			for (int i = 0; i < airborneDtoList.size(); i++) {
				if (null != airborneDtoList.get(i).getAirspeed()) {
					airSpeedDbl.add(airborneDtoList.get(i).getAirspeed()
							.toString());
				} else {
					airSpeedDbl.add("0.0");
				}
				if (null != airborneDtoList.get(i).getVerticalAcceleration()) {
					verticalDbl.add(airborneDtoList.get(i)
							.getVerticalAcceleration().toString());
				} else {
					verticalDbl.add("0.0");
				}
			}
			obj.put("verticalAcceleration", verticalDbl);
			obj.put("airspeed", airSpeedDbl);

			StringWriter out = new StringWriter();
			obj.write(out);

			String jsonText = out.toString();
			// System.out.print("jsonText is: "+jsonText);

			String avio = "{ \"data\": {\"data_set\":";
			String end = ", \"number of clusters\": " + numberOfClusters
					+ ",\"method\":\"0\"}}";

			String finalJson = avio + jsonText + end;
			System.out.println("finalJson is *************:" + finalJson);

			HttpResponse<String> jsonResponse = Unirest
					.post("https://9d10485e-b05a-428f-b7b2-6c4e4dc29efe.run.aws-usw02-pr.ice.predix.io/api/v1/analytic/execution")
					.header("content-type", "application/json")
					.header("authorization",
							"Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiI2YzBmNGJkNTcyYjA0YmJhYTNhYWVkMGI4YjJhZGU5OSIsInN1YiI6ImNsaWVudDEiLCJzY29wZSI6WyJ1YWEucmVzb3VyY2UiLCJvcGVuaWQiLCJ1YWEubm9uZSIsImFuYWx5dGljcy56b25lcy43NWI5YzcwZC05ZTBlLTRiODItYjY0Mi1iNGIzY2RjMDMyMGUudXNlciIsImFuYWx5dGljcy56b25lcy43ZWQ3YTc0My0zMjkyLTQ3ZmEtYWUwMC04MGNiOTQ3ZmMwZTMudXNlciJdLCJjbGllbnRfaWQiOiJjbGllbnQxIiwiY2lkIjoiY2xpZW50MSIsImF6cCI6ImNsaWVudDEiLCJncmFudF90eXBlIjoiY2xpZW50X2NyZWRlbnRpYWxzIiwicmV2X3NpZyI6ImJjNGQzMWRiIiwiaWF0IjoxNDk1NDM0NDg2LCJleHAiOjE2MjE1Nzg0ODYsImlzcyI6Imh0dHBzOi8vZTkxYjY0MTMtZWFjZC00ZjNhLWE3NjctNjM0NDI0MmVlMGMyLnByZWRpeC11YWEucnVuLmF3cy11c3cwMi1wci5pY2UucHJlZGl4LmlvL29hdXRoL3Rva2VuIiwiemlkIjoiZTkxYjY0MTMtZWFjZC00ZjNhLWE3NjctNjM0NDI0MmVlMGMyIiwiYXVkIjpbInVhYSIsImFuYWx5dGljcy56b25lcy43NWI5YzcwZC05ZTBlLTRiODItYjY0Mi1iNGIzY2RjMDMyMGUiLCJvcGVuaWQiLCJhbmFseXRpY3Muem9uZXMuN2VkN2E3NDMtMzI5Mi00N2ZhLWFlMDAtODBjYjk0N2ZjMGUzIiwiY2xpZW50MSJdfQ.mVCEfIpCSHm3y0cSLxZvvWBpA62uyhReZiaQKcEPJHCV2Ts9vysq4l-nORQpXdyQrRYSoh25Tf3vhCqRHzSQylVa_Hp28Jg0H4DPq25gPn5DMXxZo9lLWXyYA4-S4JPYuhV7PkqU6GCrP3HTz3fzEKXqVHpa9qtjnLEMSwD7oliu4XUfZlA1JiMJblQ_Eg4YTFXhA7qmLqiOGwtfGDU6cnPt0NRjXaq52EyUMjhRojB65J6a68_Zu10Xx9PW08o9_hvumtEMmiYaGFOxOhrvLjGdhkN6cpNrjJxZT-jywKxwaRRyEBc24VTcUQvojEcYL-4oYGJeeX8SHHDs3tH67g")
					.header("predix-zone-id",
							"75b9c70d-9e0e-4b82-b642-b4b3cdc0320e")
					.header("cache-control", "no-cache").body(finalJson)
					.asString();

			System.out.println("sm jsonResponse status="
					+ jsonResponse.getStatus());
			System.out.println("sm  jsonResponse result="
					+ jsonResponse.getBody());
			JSONObject jsonObject = new JSONObject(jsonResponse.getBody());
		/*	JsonParser parser = new JsonParser();
			JsonObject finalResult = (JsonObject) parser.parse(jsonObject.get(
					"result").toString());*/

			/*
			 * JsonArray airSpeedArr = (JsonArray) finalResult.get("airspeed");
			 * System.out.println("airSpeedArr="+airSpeedArr); JsonArray
			 * vertAccArr = (JsonArray) finalResult.get("verticalAcceleration");
			 * System.out.println("vertAccArr="+vertAccArr); JsonArray
			 * clusterNoArr = (JsonArray) finalResult.get("cluster number");
			 * System.out.println("clusterNoArr="+clusterNoArr);
			 */

			System.out.println("json result");

			analyticsResult = jsonObject.toString();

			/*
			 * JSONObject jsonObject = new JSONObject(jsonResponse.getBody());
			 * JsonParser parser = new JsonParser(); JsonObject json =
			 * (JsonObject) parser.parse(jsonObject.get("result").toString());
			 */

		} catch (Exception e) {
			System.out.println("Exception in getAnalyticsInput()");
			e.printStackTrace();
		}
		return analyticsResult;

	}

	public List<FleetData2DTO> getFlightAirborneData(long flightId) {

		List<FleetData2DTO> fleetDataDtoList = new ArrayList<FleetData2DTO>();
		FleetData2DTO fleetDataDto = null;

		// airborne - start
		Double takeoffSpeed = 0.0;
		Double takeoffPeriod = 0.0;
		Double takeoffAltiDiff = 0.0;
		Double landingSpeed = 0.0;
		Double landingPeriod = 0.0;
		Double landingAltiDiff = 0.0;
		Double landingMaxAlti = 0.0;

		Map<String, Object> objMap = null;
		// List<Map<String, Object>> flightSegmentsDataList = new
		// ArrayList<Map<String, Object>>();

		Double startTakeoffElapsedTime = 0.0;
		Double endTakeoffElapsedTime = 0.0;
		Double startTakeoffPressureAltitude;
		Double endTakeoffPressureAltitude;
		Double startLandingElapsedTime = 0.0;
		Double endLandingElapsedTime = 0.0;
		Double startLandingPressureAltitude;
		Double endLandingPressureAltitude;
		Double airborneFltSegmentDuration;

		List<FleetData2> airborneEntityList = new ArrayList<FleetData2>();
		FleetData2DTO airborneDto = null;
		List<FleetData2DTO> airborneDtoList = new ArrayList<FleetData2DTO>();

		List<FleetData2> groundEntityList = new ArrayList<FleetData2>();
		FleetData2DTO groundDto = null;
		List<FleetData2DTO> groundDtoList = new ArrayList<FleetData2DTO>();

		int takeoffEndIndex = 0;
		// airborne - end

		try {
			List<FleetData2> fleetDataList = (List<FleetData2>) filghtFleetrepo2
					.getFlightPlottingData(flightId);
			for (FleetData2 fleetData : fleetDataList) {
				fleetDataDto = new FleetData2DTO();
				BeanUtils.copyProperties(fleetData, fleetDataDto);
				fleetDataDto.setFlightId(flightId);
				fleetDataDtoList.add(fleetDataDto);
			}

			// airborne flight data-start
			int takeofflistSize = fleetDataDtoList.size();

			if (flightId == 101 || flightId == 102) {
				takeoffSpeed = 97.0;
				takeoffPeriod = 20.0;
				takeoffAltiDiff = 200.0;
				landingSpeed = 85.0;
				landingPeriod = 20.0;
				landingAltiDiff = 200.0;
				landingMaxAlti = 1100.0;
			} else {
				takeoffSpeed = 100.0;
				takeoffPeriod = 20.0;
				takeoffAltiDiff = 200.0;
				landingSpeed = 85.0;
				landingPeriod = 20.0;
				landingAltiDiff = 200.0;
			}

			if (flightId == 101 || flightId == 102) {
				outer: for (int i = 0; i < takeofflistSize; i++) {
					if (null != fleetDataDtoList.get(i).getAirspeed()) {
						if (fleetDataDtoList.get(i).getAirspeed() > takeoffSpeed) {
							startTakeoffElapsedTime = fleetDataDtoList.get(i)
									.getElapsedTime();
							startTakeoffPressureAltitude = fleetDataDtoList
									.get(i).getPressureAltitude();
							i++;

							inner: for (int j = i; j < takeofflistSize; j++) {
								if (fleetDataDtoList.get(j).getAirspeed() > takeoffSpeed) {
									endTakeoffElapsedTime = fleetDataDtoList
											.get(j).getElapsedTime();
									if ((endTakeoffElapsedTime - startTakeoffElapsedTime) < takeoffPeriod) {
										continue inner;
									}
									// Airspeed >100 continuously for a period
									// of at least 20 seconds
									endTakeoffPressureAltitude = fleetDataDtoList
											.get(j).getPressureAltitude();
									if ((endTakeoffPressureAltitude - startTakeoffPressureAltitude) >= takeoffAltiDiff) {
										// pressure altitude value has increased
										// by at least 200 feet
										System.out
												.println("flight takeoff data range found--> startTakeoffElapsedTime="
														+ startTakeoffElapsedTime
														+ " : endTakeoffElapsedTime="
														+ endTakeoffElapsedTime);
										takeoffEndIndex = j;
										break outer;
									}
									continue inner;
								}
								continue outer;
							}// end of inner for loop
						}
					}// null check end
				}// end of outer for loop

				int landinglistSize = fleetDataDtoList.size();

				outerlanding: for (int i = takeoffEndIndex; i < landinglistSize; i++) {
					if (null != fleetDataDtoList.get(i).getAirspeed()) {
						if (fleetDataDtoList.get(i).getAirspeed() < landingSpeed
								&& fleetDataDtoList.get(i)
										.getPressureAltitude() < landingMaxAlti) {
							startLandingElapsedTime = fleetDataDtoList.get(i)
									.getElapsedTime();
							startLandingPressureAltitude = fleetDataDtoList
									.get(i).getPressureAltitude();
							i++;

							innerlanding: for (int j = i; j < landinglistSize; j++) {
								if (null != fleetDataDtoList.get(j)
										.getAirspeed()) {
									if (fleetDataDtoList.get(j).getAirspeed() < landingSpeed
											&& fleetDataDtoList.get(j)
													.getPressureAltitude() < landingMaxAlti) {
										endLandingElapsedTime = fleetDataDtoList
												.get(j).getElapsedTime();
										if ((endLandingElapsedTime - startLandingElapsedTime) < landingPeriod) {
											continue innerlanding;
										}
										// Airspeed <85 continuously for a
										// period of at least 20 seconds
										endLandingPressureAltitude = fleetDataDtoList
												.get(j).getPressureAltitude();
										if ((endLandingPressureAltitude - startLandingPressureAltitude) <= landingAltiDiff) {
											// pressure altitude value has
											// changed by at most 200 feet
											System.out
													.println("flight landing data range found--> startLandingElapsedTime="
															+ startLandingElapsedTime
															+ " : endLandingElapsedTime="
															+ endLandingElapsedTime);

											airborneFltSegmentDuration = startLandingElapsedTime
													- startTakeoffElapsedTime;

											objMap = new HashMap<String, Object>();
											objMap.put(
													"startTakeoffElapsedTime",
													startTakeoffElapsedTime);
											objMap.put("endTakeoffElapsedTime",
													endTakeoffElapsedTime);
											objMap.put(
													"startLandingElapsedTime",
													startLandingElapsedTime);
											objMap.put("endLandingElapsedTime",
													endLandingElapsedTime);
											objMap.put(
													"airborneFltSegmentDuration",
													airborneFltSegmentDuration);

											break outerlanding;
										}
										continue innerlanding;
									}
								}
								continue outerlanding;
							}// end of inner for loop
						}
					}// null check end
				}// end of outer for loop
			} else if (flightId == 103) {
				startTakeoffElapsedTime = 709.51;
				startLandingElapsedTime = 3534.69;
				objMap = new HashMap<String, Object>();
				objMap.put("startTakeoffElapsedTime", startTakeoffElapsedTime);
				objMap.put("endTakeoffElapsedTime", 730.61);
				objMap.put("startLandingElapsedTime", startLandingElapsedTime);
				objMap.put("endLandingElapsedTime", 3559.11);
				objMap.put("airborneFltSegmentDuration", 2825.18);
			} else {
				outer1: for (int i = 0; i < takeofflistSize; i++) {
					if (null != fleetDataDtoList.get(i).getAirspeed()) {
						if (fleetDataDtoList.get(i).getAirspeed() > takeoffSpeed) {
							startTakeoffElapsedTime = fleetDataDtoList.get(i)
									.getElapsedTime();
							startTakeoffPressureAltitude = fleetDataDtoList
									.get(i).getPressureAltitude();
							i++;

							inner1: for (int j = i; j < takeofflistSize; j++) {
								if (fleetDataDtoList.get(j).getAirspeed() > takeoffSpeed) {
									endTakeoffElapsedTime = fleetDataDtoList
											.get(j).getElapsedTime();
									if ((endTakeoffElapsedTime - startTakeoffElapsedTime) < takeoffPeriod) {
										continue inner1;
									}
									// Airspeed >100 continuously for a period
									// of at least 20 seconds
									endTakeoffPressureAltitude = fleetDataDtoList
											.get(j).getPressureAltitude();
									if ((endTakeoffPressureAltitude - startTakeoffPressureAltitude) >= takeoffAltiDiff) {
										// pressure altitude value has increased
										// by at least 200 feet
										System.out
												.println("flight takeoff data range found--> startTakeoffElapsedTime="
														+ startTakeoffElapsedTime
														+ " : endTakeoffElapsedTime="
														+ endTakeoffElapsedTime);
										takeoffEndIndex = j;
										break outer1;
									}
									continue inner1;
								}
								continue outer1;
							}// end of inner for loop
						}
					}// null check end
				}// end of outer for loop

				int landinglistSize = fleetDataDtoList.size();

				outerlanding1: for (int i = takeoffEndIndex; i < landinglistSize; i++) {
					if (null != fleetDataDtoList.get(i).getAirspeed()) {
						if (fleetDataDtoList.get(i).getAirspeed() < landingSpeed) {
							startLandingElapsedTime = fleetDataDtoList.get(i)
									.getElapsedTime();
							startLandingPressureAltitude = fleetDataDtoList
									.get(i).getPressureAltitude();
							i++;

							innerlanding1: for (int j = i; j < landinglistSize; j++) {
								if (null != fleetDataDtoList.get(j)
										.getAirspeed()) {
									if (fleetDataDtoList.get(j).getAirspeed() < landingSpeed) {
										endLandingElapsedTime = fleetDataDtoList
												.get(j).getElapsedTime();
										if ((endLandingElapsedTime - startLandingElapsedTime) < landingPeriod) {
											continue innerlanding1;
										}
										// Airspeed <85 continuously for a
										// period of at least 20 seconds
										endLandingPressureAltitude = fleetDataDtoList
												.get(j).getPressureAltitude();
										if ((endLandingPressureAltitude - startLandingPressureAltitude) <= landingAltiDiff) {
											// pressure altitude value has
											// changed by at most 200 feet
											System.out
													.println("flight landing data range found--> startLandingElapsedTime="
															+ startLandingElapsedTime
															+ " : endLandingElapsedTime="
															+ endLandingElapsedTime);

											airborneFltSegmentDuration = startLandingElapsedTime
													- startTakeoffElapsedTime;

											objMap = new HashMap<String, Object>();
											objMap.put(
													"startTakeoffElapsedTime",
													startTakeoffElapsedTime);
											objMap.put("endTakeoffElapsedTime",
													endTakeoffElapsedTime);
											objMap.put(
													"startLandingElapsedTime",
													startLandingElapsedTime);
											objMap.put("endLandingElapsedTime",
													endLandingElapsedTime);
											objMap.put(
													"airborneFltSegmentDuration",
													airborneFltSegmentDuration);

											break outerlanding1;
										}
										continue innerlanding1;
									}
								}
								continue outerlanding1;
							}// end of inner for loop
						}
					}// null check end
				}// end of outer for loop
			}

			List<Object[]> retList = null;
			Double maxElapsedTime = 0.0;

			retList = filghtFleetrepo2.getFlightMinMaxElapsedTime(flightId);
			for (int i = 0; i < retList.size(); i++) {
				maxElapsedTime = (Double) retList.get(i)[0];
			}
			System.out.println("maxElapsedTime=" + maxElapsedTime);

			// Airborne Flight Segment Data
			airborneEntityList = (List<FleetData2>) filghtFleetrepo2
					.getFlightPlottingDataElapsedTime(flightId,
							startTakeoffElapsedTime, startLandingElapsedTime);
			for (FleetData2 airborneEntity : airborneEntityList) {
				airborneDto = new FleetData2DTO();
				BeanUtils.copyProperties(airborneEntity, airborneDto);
				airborneDto.setFlightId(flightId);
				airborneDtoList.add(airborneDto);
			}
			// airborne flight data-end
		} catch (Exception e) {
			System.out.println("Exception in getFlightEventsSegments()");
			e.printStackTrace();
		}

		return airborneDtoList;

	}

	

	@RequestMapping(value = "/getClusterAnalyticsWithDataDynamic/{flightId}/{numberOfClusters}/{noOfRecs}", method = RequestMethod.GET)
	public @ResponseBody String getClusterAnalyticsWithDataDynamic(
			@PathVariable("flightId") long flightId,
			@PathVariable("numberOfClusters") String numberOfClusters,
			@PathVariable("noOfRecs") String noOfRecs) {

		/*
		 * String analyticsInputStr =
		 * "{ \"data\": {\"data_set\": {\"verticalAcceleration\": [\"1.0\", \"1.2\",\"1.3\",\"1.1\"],\"airspeed\": [\"54.3\",\"53.8\",\"53.6\",\"53.7\"]}, \"number of clusters\":\"3\",\"method\":\"0\"}}"
		 * ; System.out.println("analyticsInputStr is :: " + analyticsInputStr);
		 */

		System.out
				.println("AircraftService.getClusterAnalyticsWithDataDynamic() : start");
		int dataSize = Integer.parseInt(noOfRecs);
		System.out.println("dataSize=" + dataSize);

		List<FleetData2DTO> airborneDtoList = new ArrayList<FleetData2DTO>();
		String analyticsResult = "";

		try {

			airborneDtoList = getFlightAirborneData(flightId);

			JSONObject obj = new JSONObject();

			List<String> airSpeedDbl = new ArrayList<String>();
			List<String> verticalDbl = new ArrayList<String>();
			int size = airborneDtoList.size() ;
			size =  dataSize;
			System.out
					.println("size is:***" + size);
			for (int i = 0; i < size; i++) {
				System.out
						.println("size is : " + airborneDtoList.size());
				
				System.out
				.println("i value is: " + airborneDtoList.get(i));
				
				if (null != airborneDtoList.get(i).getAirspeed()) {
					airSpeedDbl.add(airborneDtoList.get(i).getAirspeed()
							.toString());
				} else {
					airSpeedDbl.add("0.0");
				}
				if (null != airborneDtoList.get(i).getVerticalAcceleration()) {
					verticalDbl.add(airborneDtoList.get(i)
							.getVerticalAcceleration().toString());
				} else {
					verticalDbl.add("0.0");
				}
			}
			obj.put("verticalAcceleration", verticalDbl);
			obj.put("airspeed", airSpeedDbl);

			StringWriter out = new StringWriter();
			obj.write(out);

			String jsonText = out.toString();
			// System.out.print("jsonText is: "+jsonText);

			String avio = "{ \"data\": {\"data_set\":";
			String end = ", \"number of clusters\": " + numberOfClusters
					+ ",\"method\":\"0\"}}";

			String finalJson = avio + jsonText + end;
			System.out.println("finalJson is *************:" + finalJson);

			HttpResponse<String> jsonResponse = Unirest
					.post("https://predix-analytics-catalog-release.run.aws-usw02-pr.ice.predix.io/api/v1/catalog/analytics/9d10485e-b05a-428f-b7b2-6c4e4dc29efe/execution")
					.header("content-type", "application/json")
					.header("authorization",
							"Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiI1MDJjYzhhNWFmZjc0NmZmOWE3YzJlNzM4Njk5MWUxZiIsInN1YiI6ImNsaWVudDEiLCJzY29wZSI6WyJ1YWEucmVzb3VyY2UiLCJvcGVuaWQiLCJ1YWEubm9uZSIsImFuYWx5dGljcy56b25lcy43NWI5YzcwZC05ZTBlLTRiODItYjY0Mi1iNGIzY2RjMDMyMGUudXNlciIsImFuYWx5dGljcy56b25lcy43ZWQ3YTc0My0zMjkyLTQ3ZmEtYWUwMC04MGNiOTQ3ZmMwZTMudXNlciJdLCJjbGllbnRfaWQiOiJjbGllbnQxIiwiY2lkIjoiY2xpZW50MSIsImF6cCI6ImNsaWVudDEiLCJncmFudF90eXBlIjoiY2xpZW50X2NyZWRlbnRpYWxzIiwicmV2X3NpZyI6ImJjNGQzMWRiIiwiaWF0IjoxNDk0NDAxNTA3LCJleHAiOjE0OTU0MDE1MDYsImlzcyI6Imh0dHBzOi8vZTkxYjY0MTMtZWFjZC00ZjNhLWE3NjctNjM0NDI0MmVlMGMyLnByZWRpeC11YWEucnVuLmF3cy11c3cwMi1wci5pY2UucHJlZGl4LmlvL29hdXRoL3Rva2VuIiwiemlkIjoiZTkxYjY0MTMtZWFjZC00ZjNhLWE3NjctNjM0NDI0MmVlMGMyIiwiYXVkIjpbInVhYSIsImFuYWx5dGljcy56b25lcy43NWI5YzcwZC05ZTBlLTRiODItYjY0Mi1iNGIzY2RjMDMyMGUiLCJvcGVuaWQiLCJhbmFseXRpY3Muem9uZXMuN2VkN2E3NDMtMzI5Mi00N2ZhLWFlMDAtODBjYjk0N2ZjMGUzIiwiY2xpZW50MSJdfQ.nlk3a7KJjdhlbpxSzaHl3wEc7Uk4tKeBotP5UICAdoV-9RYAP6hUaQRdJUUfchhDHUYPJ2Fz1Tb7F90EunImrRGv6l9b6j6WROmqgfcXzXIsOT_fIfn_QkSRhCRlAk5e43M8gWDgYQOR12VUmMuaZvrtUHRWfgzou6DkJ2H3xH7jaFlXnDIi11027lvv8x_bxJP5NhT46seGDfJBFTM8yUkLPGPtaZoGrNN6QwS7DcIiSvxRe6Jn0s0xAXD7NILGVTcgQYlt8qs9Ipsh7S2zYuK4chxMFlSAT7_1pyrYxDmVPCDn4E5eMWQuA0UmTlSy1-ytIxIA3YYvG7dUuzu8iA")
					.header("predix-zone-id",
							"75b9c70d-9e0e-4b82-b642-b4b3cdc0320e")
					.header("cache-control", "no-cache").body(finalJson)
					.asString();

			System.out.println("sm jsonResponse status="
					+ jsonResponse.getStatus());
			System.out.println("sm  jsonResponse result="
					+ jsonResponse.getBody());
			JSONObject jsonObject = new JSONObject(jsonResponse.getBody());
			JsonParser parser = new JsonParser();
			JsonObject finalResult = (JsonObject) parser.parse(jsonObject.get(
					"result").toString());

			/*
			 * JsonArray airSpeedArr = (JsonArray) finalResult.get("airspeed");
			 * System.out.println("airSpeedArr="+airSpeedArr); JsonArray
			 * vertAccArr = (JsonArray) finalResult.get("verticalAcceleration");
			 * System.out.println("vertAccArr="+vertAccArr); JsonArray
			 * clusterNoArr = (JsonArray) finalResult.get("cluster number");
			 * System.out.println("clusterNoArr="+clusterNoArr);
			 */

			System.out.println("json result");

			analyticsResult = finalResult.toString();

			/*
			 * JSONObject jsonObject = new JSONObject(jsonResponse.getBody());
			 * JsonParser parser = new JsonParser(); JsonObject json =
			 * (JsonObject) parser.parse(jsonObject.get("result").toString());
			 */

		} catch (Exception e) {
			System.out.println("Exception in getAnalyticsInput()");
			e.printStackTrace();
		}
		return analyticsResult;

	}
	
	
	
	@RequestMapping(value = "/getRegressionDynamicAnalysis1/{flightId}/{strainGauge}/{params}", method = RequestMethod.GET)
	public @ResponseBody String getRegressionDynamicAnalysis1(
			@PathVariable("flightId") long flightId,
			@PathVariable("strainGauge") String strainGauge,
			@PathVariable("params") String params) {

		/*
		 * String analyticsInputStr =
		 * "{ \"data\": {\"data_set\": {\"verticalAcceleration\": [\"1.0\", \"1.2\",\"1.3\",\"1.1\"],\"airspeed\": [\"54.3\",\"53.8\",\"53.6\",\"53.7\"]}, \"number of clusters\":\"3\",\"method\":\"0\"}}"
		 * ; System.out.println("analyticsInputStr is :: " + analyticsInputStr);
		 */

		System.out.println("AircraftService.getRegressionDynamicAnalysis1() : start");

		String analyticsResult = "";
		List<FleetData2DTO> airborneDtoList = new ArrayList<FleetData2DTO>();

		try {
			airborneDtoList = getFlightAirborneData(flightId);
			JSONObject obj = new JSONObject();

			List<String> airSpeedDbl = new ArrayList<String>();
			List<String> verticalDbl = new ArrayList<String>();

			List<Double> strainGaugeArray = new ArrayList<Double>();

			List<Double> airspeedArray = new ArrayList<Double>();
			List<Double> pressureAltitudeArray = new ArrayList<Double>();
			List<Double> rollAccelerationArray = new ArrayList<Double>();
			List<Double> verticalAccelerationArray = new ArrayList<Double>();
			// List<String> peakValleyIndicatorArray = new ArrayList<String>();
			List<Double> flapPositionArray = new ArrayList<Double>();
			List<Double> elevatorPositionArray = new ArrayList<Double>();
			List<Double> retardantDoorOpenArray = new ArrayList<Double>();
			List<Double> gearUpAndLockedArray = new ArrayList<Double>();

			List<Double> elapsedArray = new ArrayList<Double>();
			for (int i = 0; i < airborneDtoList.size(); i++) {
				elapsedArray.add(airborneDtoList.get(i).getElapsedTime());

				if (strainGauge.equalsIgnoreCase("strainGauge1")) {
					strainGaugeArray.add(airborneDtoList.get(i).getStrainGauge1());
				} else if (strainGauge.equalsIgnoreCase("strainGauge3")) {
					strainGaugeArray.add(airborneDtoList.get(i).getStrainGauge3());
				} else if (strainGauge.equalsIgnoreCase("strainGauge6")) {
					strainGaugeArray.add(airborneDtoList.get(i).getStrainGauge6());
				} else if (strainGauge.equalsIgnoreCase("strainGauge8")) {
					strainGaugeArray.add(airborneDtoList.get(i).getStrainGauge8());
				} 
				
				//19-May-2017 : All Strain Gauge Values(S1-S9)to include for Regression Analysis : start
				else if (strainGauge.equalsIgnoreCase("strainGauge2")) {
					strainGaugeArray.add(airborneDtoList.get(i).getStrainGauge2());
				}  else if (strainGauge.equalsIgnoreCase("strainGauge4")) {
					strainGaugeArray.add(airborneDtoList.get(i).getStrainGauge4());
				}  else if (strainGauge.equalsIgnoreCase("strainGauge5")) {
					strainGaugeArray.add(airborneDtoList.get(i).getStrainGauge5());
				}  else if (strainGauge.equalsIgnoreCase("strainGauge7")) {
					strainGaugeArray.add(airborneDtoList.get(i).getStrainGauge7());
				}  else if (strainGauge.equalsIgnoreCase("strainGauge9")) {
					strainGaugeArray.add(airborneDtoList.get(i).getStrainGauge9());
				}  
				//19-May-2017 : All Strain Gauge Values(S1-S9)to include for Regression Analysis : end
				
				if (null != airborneDtoList.get(i).getAirspeed()) {
					airspeedArray.add(airborneDtoList.get(i).getAirspeed());
				} else {
					airspeedArray.add(0.0);
				}

				if (null != airborneDtoList.get(i).getPressureAltitude()) {
					pressureAltitudeArray.add(airborneDtoList.get(i).getPressureAltitude());
				} else {
					pressureAltitudeArray.add(0.0);
				}
				if (null != airborneDtoList.get(i).getRollAcceleration()) {
					rollAccelerationArray.add(airborneDtoList.get(i).getRollAcceleration());
				} else {
					rollAccelerationArray.add(0.0);
				}
				if (null != airborneDtoList.get(i).getVerticalAcceleration()) {
					verticalAccelerationArray.add(airborneDtoList.get(i).getVerticalAcceleration());
				} else {
					verticalAccelerationArray.add(0.0);
				}
				/*
				 * if(null!=airborneDtoList.get(i).getAirspeed()){
				 * peakValleyIndicatorArray
				 * .add(airborneDtoList.get(i).getPeakValleyIndicator()); }else{
				 * peakValleyIndicatorArray.add(""); }
				 */
				if (null != airborneDtoList.get(i).getFlapPosition()) {
					flapPositionArray.add(airborneDtoList.get(i).getFlapPosition());
				} else {
					flapPositionArray.add(0.0);
				}
				if (null != airborneDtoList.get(i).getElevatorPosition()) {
					elevatorPositionArray.add(airborneDtoList.get(i).getElevatorPosition());
				} else {
					elevatorPositionArray.add(0.0);
				}
				if (null != airborneDtoList.get(i).getRetardantDoorOpen()) {
					retardantDoorOpenArray.add(airborneDtoList.get(i).getRetardantDoorOpen().doubleValue());
				} else {
					retardantDoorOpenArray.add(0.0);
				}
				if (null != airborneDtoList.get(i).getGearUpAndLocked()) {
					gearUpAndLockedArray.add(airborneDtoList.get(i).getGearUpAndLocked().doubleValue());
				} else {
					gearUpAndLockedArray.add(0.0);
				}
			}

			obj.put("strainGauge", strainGaugeArray);

			if (params.contains("airspeed")) {
				obj.put("airspeed", airspeedArray);
			}
			if (params.contains("pressureAltitude")) {
				obj.put("pressureAltitude", pressureAltitudeArray);
			}
			if (params.contains("rollAcceleration")) {
				obj.put("rollAcceleration", rollAccelerationArray);
			}
			if (params.contains("verticalAcceleration")) {
				obj.put("verticalAcceleration", verticalAccelerationArray);
			}
			/*
			 * if(params.contains("peakValleyIndicator")){
			 * obj.put("peakValleyIndicator",peakValleyIndicatorArray); }
			 */
			if (params.contains("flapPosition")) {
				obj.put("flapPosition", flapPositionArray);
			}
			if (params.contains("elevatorPosition")) {
				obj.put("elevatorPosition", elevatorPositionArray);
			}
			if (params.contains("retardantDoorOpen")) {
				obj.put("retardantDoorOpen", retardantDoorOpenArray);
			}
			if (params.contains("gearUpAndLocked")) {
				obj.put("gearUpAndLocked", gearUpAndLockedArray);
			}
			String splitArr[] = params.split(",");
			obj.put("inputParam", splitArr);

			StringWriter out = new StringWriter();
			obj.write(out);

			String jsonText = out.toString();
			String finalJson = jsonText;
			System.out.println("finalJson is *************:" + finalJson);

			/*HttpResponse<String> jsonResponse = Unirest
					.post("https://6accfa80-13cb-43a4-af89-b79c9a3a46e6.run.aws-usw02-pr.ice.predix.io/api/v1/analytic/execution")
					.header("content-type", "application/json")
					.header("authorization",
							"Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiI3ZDkyZTZiMmZhMTg0ZDc0YWNiODZiMmE3MDQ3ODhiMSIsInN1YiI6ImNsaWVudDEiLCJzY29wZSI6WyJ1YWEucmVzb3VyY2UiLCJvcGVuaWQiLCJ1YWEubm9uZSIsImFuYWx5dGljcy56b25lcy43NWI5YzcwZC05ZTBlLTRiODItYjY0Mi1iNGIzY2RjMDMyMGUudXNlciIsImFuYWx5dGljcy56b25lcy43ZWQ3YTc0My0zMjkyLTQ3ZmEtYWUwMC04MGNiOTQ3ZmMwZTMudXNlciJdLCJjbGllbnRfaWQiOiJjbGllbnQxIiwiY2lkIjoiY2xpZW50MSIsImF6cCI6ImNsaWVudDEiLCJncmFudF90eXBlIjoiY2xpZW50X2NyZWRlbnRpYWxzIiwicmV2X3NpZyI6ImJjNGQzMWRiIiwiaWF0IjoxNDkwMDE1OTIwLCJleHAiOjE0OTQzMzU5MTksImlzcyI6Imh0dHBzOi8vZTkxYjY0MTMtZWFjZC00ZjNhLWE3NjctNjM0NDI0MmVlMGMyLnByZWRpeC11YWEucnVuLmF3cy11c3cwMi1wci5pY2UucHJlZGl4LmlvL29hdXRoL3Rva2VuIiwiemlkIjoiZTkxYjY0MTMtZWFjZC00ZjNhLWE3NjctNjM0NDI0MmVlMGMyIiwiYXVkIjpbInVhYSIsImFuYWx5dGljcy56b25lcy43NWI5YzcwZC05ZTBlLTRiODItYjY0Mi1iNGIzY2RjMDMyMGUiLCJvcGVuaWQiLCJhbmFseXRpY3Muem9uZXMuN2VkN2E3NDMtMzI5Mi00N2ZhLWFlMDAtODBjYjk0N2ZjMGUzIiwiY2xpZW50MSJdfQ.tD7SMen65lrDf_RXA5i6a6YqKUUzRrlK5LtVUNTID3A5Vkum5lgTrVoDPIqxDOdSoe9xXsL-3OcvddPLM5AwEjArTpxHE_HvQlLaNxMZOw66QCV7vCzsR8fDNta0iz0xbz_qZs8g-3p-qej4T-Ig2v0YXRB1A7q24dW8wo7kDsAHFI6XguQKizzTQJTqIgiMCZvdw_fexIeowwPuuUCS0H0eumUvpl-bCBLDEEm-7emgMULCgLfM_Xm2jZwspiUn0Xl56gdTJyup8tDXw59CTV8LnIo1XVjB29fAQ2hz1vUxhHkuvOWT2l-TQn7ZBHCHkI-AOJiDALD6cXrVNUbsbQ")
					.header("predix-zone-id",
							"75b9c70d-9e0e-4b82-b642-b4b3cdc0320e")
					.header("cache-control", "no-cache").body(finalJson)
					.asString();*/
			
			HttpResponse<String> jsonResponse = Unirest
					.post("https://f1ccdd23-a3b7-4b11-890b-868224ac0f72.run.aws-usw02-pr.ice.predix.io/api/v1/analytic/execution")
					.header("content-type", "application/json")
					.header("authorization",
							"Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImxlZ2FjeS10b2tlbi1rZXkiLCJ0eXAiOiJKV1QifQ.eyJqdGkiOiI2YzBmNGJkNTcyYjA0YmJhYTNhYWVkMGI4YjJhZGU5OSIsInN1YiI6ImNsaWVudDEiLCJzY29wZSI6WyJ1YWEucmVzb3VyY2UiLCJvcGVuaWQiLCJ1YWEubm9uZSIsImFuYWx5dGljcy56b25lcy43NWI5YzcwZC05ZTBlLTRiODItYjY0Mi1iNGIzY2RjMDMyMGUudXNlciIsImFuYWx5dGljcy56b25lcy43ZWQ3YTc0My0zMjkyLTQ3ZmEtYWUwMC04MGNiOTQ3ZmMwZTMudXNlciJdLCJjbGllbnRfaWQiOiJjbGllbnQxIiwiY2lkIjoiY2xpZW50MSIsImF6cCI6ImNsaWVudDEiLCJncmFudF90eXBlIjoiY2xpZW50X2NyZWRlbnRpYWxzIiwicmV2X3NpZyI6ImJjNGQzMWRiIiwiaWF0IjoxNDk1NDM0NDg2LCJleHAiOjE2MjE1Nzg0ODYsImlzcyI6Imh0dHBzOi8vZTkxYjY0MTMtZWFjZC00ZjNhLWE3NjctNjM0NDI0MmVlMGMyLnByZWRpeC11YWEucnVuLmF3cy11c3cwMi1wci5pY2UucHJlZGl4LmlvL29hdXRoL3Rva2VuIiwiemlkIjoiZTkxYjY0MTMtZWFjZC00ZjNhLWE3NjctNjM0NDI0MmVlMGMyIiwiYXVkIjpbInVhYSIsImFuYWx5dGljcy56b25lcy43NWI5YzcwZC05ZTBlLTRiODItYjY0Mi1iNGIzY2RjMDMyMGUiLCJvcGVuaWQiLCJhbmFseXRpY3Muem9uZXMuN2VkN2E3NDMtMzI5Mi00N2ZhLWFlMDAtODBjYjk0N2ZjMGUzIiwiY2xpZW50MSJdfQ.mVCEfIpCSHm3y0cSLxZvvWBpA62uyhReZiaQKcEPJHCV2Ts9vysq4l-nORQpXdyQrRYSoh25Tf3vhCqRHzSQylVa_Hp28Jg0H4DPq25gPn5DMXxZo9lLWXyYA4-S4JPYuhV7PkqU6GCrP3HTz3fzEKXqVHpa9qtjnLEMSwD7oliu4XUfZlA1JiMJblQ_Eg4YTFXhA7qmLqiOGwtfGDU6cnPt0NRjXaq52EyUMjhRojB65J6a68_Zu10Xx9PW08o9_hvumtEMmiYaGFOxOhrvLjGdhkN6cpNrjJxZT-jywKxwaRRyEBc24VTcUQvojEcYL-4oYGJeeX8SHHDs3tH67g")
					.header("predix-zone-id",
							"75b9c70d-9e0e-4b82-b642-b4b3cdc0320e")
					.header("cache-control", "no-cache").body(finalJson)
					.asString();

			System.out.println("sm jsonResponse status="+ jsonResponse.getStatus());
			System.out.println("sm  jsonResponse result="+ jsonResponse.getBody());
			JSONObject jsonObject = new JSONObject(jsonResponse.getBody());
			/*JsonParser parser = new JsonParser();
			JsonObject finalResult = (JsonObject) parser.parse(jsonObject.get(
					"result").toString());*/

			/*
			 * String result = "{\"PredictedValue\": [820.249999999977, " +
			 * "752.1399999999862, 704.7699999999886, 814.3299999999821, " +
			 * "675.1499999999902], \"tValue\": [0.0, 0.0, 0.0, -0.0, 0.0]," +
			 * " \"StdError\": [44, 55, 66, 66, 77]," +
			 * " \"RSquared\": 1.0, \"Coeff\": [1198.4593679844183, 5.758556755376162,"
			 * + " 1438.174509706936, -0.310710620526665, 961.3957921936526], "
			 * + "\"pValue\":  [1.6, 3.5, 456, 34, 34]}";
			 */

			// System.out.println("App.main()" + result);

			JSONParser parser1 = new JSONParser();
			org.json.simple.JSONObject a = new org.json.simple.JSONObject();
			a = (org.json.simple.JSONObject) parser1.parse(jsonObject.toString());

			JSONArray PredictedValue = (JSONArray) a.get("PredictedValue");
			String RSquared = a.get("RSquared").toString();

			JSONArray Coeff = (JSONArray) a.get("Coeff");
			JSONArray StdError = (JSONArray) a.get("StdError");
			JSONArray pValue = (JSONArray) a.get("pValue");
			JSONArray tValue = (JSONArray) a.get("tValue");

			JSONObject resultObj = new JSONObject();
			resultObj.put("PredictedValue", PredictedValue);
			resultObj.put("ActualValue", strainGaugeArray);
			resultObj.put("flightId", flightId);
			resultObj.put("elapseTime", elapsedArray);

			resultObj.put("RSquared", RSquared);

			String param = null;
			Double coEff = null;
			Double stdErr = null;
			String pVal = null;
			Double tVal = null;

			Map<String, String> regressionMap = new HashMap<String, String>();
			List<Map<String, String>> mapList = new ArrayList<Map<String, String>>();
			RegressionCalDTO regressionCalDTO = null;
			List<RegressionCalDTO> dtoList = new ArrayList<RegressionCalDTO>();

			for (int i = 0; i <= splitArr.length; i++) {
				regressionMap = new HashMap<String, String>();
				regressionCalDTO = new RegressionCalDTO();
				coEff = (Double) Coeff.get(i);

				stdErr = (Double) StdError.get(i);
				pVal = pValue.get(i).toString();
				tVal = (Double) tValue.get(i);

				/*if (i == splitArr.length) {
					param = "Const";
				} else {
					param = splitArr[i];
				}*/
				
				if (i == 0) {
					param = "Const";
				} else {
					param = splitArr[i-1];
				}

				regressionMap.put("coEff", coEff.toString());
				regressionMap.put("param", param.toString());
				regressionMap.put("stdErr", stdErr.toString());
				regressionMap.put("pVal", pVal.toString());
				regressionMap.put("tVal", tVal.toString());

				mapList.add(regressionMap);

			}

			System.out.println("json result");
			resultObj.put("mapList", mapList);
			analyticsResult = resultObj.toString();

			/*
			 * JSONObject jsonObject = new JSONObject(jsonResponse.getBody());
			 * JsonParser parser = new JsonParser(); JsonObject json =
			 * (JsonObject) parser.parse(jsonObject.get("result").toString());
			 */

		} catch (Exception e) {
			System.out.println("Exception in getRegressionDynamicAnalysis1()");
			e.printStackTrace();
		}
		return analyticsResult;

	}
	
	@RequestMapping(value = "/getRegressionInput/{flightId}/{strainGauge}/{params}/{noOfRecs}", method = RequestMethod.GET)
	public @ResponseBody String getRegressionInput(
			@PathVariable("flightId") long flightId,
			@PathVariable("strainGauge") String strainGauge,
			@PathVariable("params") String params,
			@PathVariable("noOfRecs") String noOfRecs) {

		/*
		 * String analyticsInputStr =
		 * "{ \"data\": {\"data_set\": {\"verticalAcceleration\": [\"1.0\", \"1.2\",\"1.3\",\"1.1\"],\"airspeed\": [\"54.3\",\"53.8\",\"53.6\",\"53.7\"]}, \"number of clusters\":\"3\",\"method\":\"0\"}}"
		 * ; System.out.println("analyticsInputStr is :: " + analyticsInputStr);
		 */

		System.out
				.println("AircraftService.getRegressionInput() : start");

		String analyticsResult = "";
		List<FleetData2DTO> airborneDtoList = new ArrayList<FleetData2DTO>();

		try {

			int dataSize = Integer.parseInt(noOfRecs);
			System.out.println("dataSize=" + dataSize);

			airborneDtoList = getFlightAirborneData(flightId);

			JSONObject obj = new JSONObject();

			List<String> airSpeedDbl = new ArrayList<String>();
			List<String> verticalDbl = new ArrayList<String>();

			List<Double> strainGaugeArray = new ArrayList<Double>();

			List<Double> airspeedArray = new ArrayList<Double>();
			List<Double> pressureAltitudeArray = new ArrayList<Double>();
			List<Double> rollAccelerationArray = new ArrayList<Double>();
			List<Double> verticalAccelerationArray = new ArrayList<Double>();
			// List<String> peakValleyIndicatorArray = new ArrayList<String>();
			List<Double> flapPositionArray = new ArrayList<Double>();
			List<Double> elevatorPositionArray = new ArrayList<Double>();

			List<Double> retardantDoorOpenArray = new ArrayList<Double>();
			List<Double> gearUpAndLockedArray = new ArrayList<Double>();

			List<Double> elapsedArray = new ArrayList<Double>();
			for (int i = 0; i < dataSize; i++) {
				elapsedArray.add(airborneDtoList.get(i).getElapsedTime());

				if (strainGauge.equalsIgnoreCase("strainGauge1")) {
					strainGaugeArray.add(airborneDtoList.get(i)
							.getStrainGauge1());

				} else if (strainGauge.equalsIgnoreCase("strainGauge3")) {

					strainGaugeArray.add(airborneDtoList.get(i)
							.getStrainGauge3());
				} else if (strainGauge.equalsIgnoreCase("strainGauge6")) {

					strainGaugeArray.add(airborneDtoList.get(i)
							.getStrainGauge6());

				} else if (strainGauge.equalsIgnoreCase("strainGauge8")) {

					strainGaugeArray.add(airborneDtoList.get(i)
							.getStrainGauge8());

				}
				if (null != airborneDtoList.get(i).getAirspeed()) {
					airspeedArray.add(airborneDtoList.get(i).getAirspeed());
				} else {
					airspeedArray.add(0.0);
				}

				if (null != airborneDtoList.get(i).getPressureAltitude()) {
					pressureAltitudeArray.add(airborneDtoList.get(i)
							.getPressureAltitude());
				} else {
					pressureAltitudeArray.add(0.0);
				}
				if (null != airborneDtoList.get(i).getRollAcceleration()) {
					rollAccelerationArray.add(airborneDtoList.get(i)
							.getRollAcceleration());
				} else {
					rollAccelerationArray.add(0.0);
				}
				if (null != airborneDtoList.get(i).getVerticalAcceleration()) {
					verticalAccelerationArray.add(airborneDtoList.get(i)
							.getVerticalAcceleration());
				} else {
					verticalAccelerationArray.add(0.0);
				}
				/*
				 * if(null!=airborneDtoList.get(i).getAirspeed()){
				 * peakValleyIndicatorArray
				 * .add(airborneDtoList.get(i).getPeakValleyIndicator()); }else{
				 * peakValleyIndicatorArray.add(""); }
				 */
				if (null != airborneDtoList.get(i).getFlapPosition()) {
					flapPositionArray.add(airborneDtoList.get(i)
							.getFlapPosition());
				} else {
					flapPositionArray.add(0.0);
				}
				if (null != airborneDtoList.get(i).getElevatorPosition()) {
					elevatorPositionArray.add(airborneDtoList.get(i)
							.getElevatorPosition());
				} else {
					elevatorPositionArray.add(0.0);
				}
				if (null != airborneDtoList.get(i).getRetardantDoorOpen()) {
					retardantDoorOpenArray.add(airborneDtoList.get(i)
							.getRetardantDoorOpen().doubleValue());
				} else {
					retardantDoorOpenArray.add(0.0);
				}
				if (null != airborneDtoList.get(i).getGearUpAndLocked()) {
					gearUpAndLockedArray.add(airborneDtoList.get(i)
							.getGearUpAndLocked().doubleValue());
				} else {
					gearUpAndLockedArray.add(0.0);
				}

			}

			obj.put("strainGauge", strainGaugeArray);

			if (params.contains("airspeed")) {
				obj.put("airspeed", airspeedArray);

			}
			if (params.contains("pressureAltitude")) {
				obj.put("pressureAltitude", pressureAltitudeArray);
			}
			if (params.contains("rollAcceleration")) {
				obj.put("rollAcceleration", rollAccelerationArray);
			}
			if (params.contains("verticalAcceleration")) {
				obj.put("verticalAcceleration", verticalAccelerationArray);
			}
			/*
			 * if(params.contains("peakValleyIndicator")){
			 * obj.put("peakValleyIndicator",peakValleyIndicatorArray); }
			 */
			if (params.contains("flapPosition")) {
				obj.put("flapPosition", flapPositionArray);
			}
			if (params.contains("elevatorPosition")) {
				obj.put("elevatorPosition", elevatorPositionArray);
			}
			if (params.contains("retardantDoorOpen")) {
				obj.put("retardantDoorOpen", retardantDoorOpenArray);
			}
			if (params.contains("gearUpAndLocked")) {
				obj.put("gearUpAndLocked", gearUpAndLockedArray);
			}
			String splitArr[] = params.split(",");
			obj.put("inputParam", splitArr);

			StringWriter out = new StringWriter();
			obj.write(out);

			String jsonText = out.toString();
			String finalJson = jsonText;
			System.out.println("finalJson is *************:" + finalJson);

			analyticsResult = finalJson.toString();

			/*
			 * JSONObject jsonObject = new JSONObject(jsonResponse.getBody());
			 * JsonParser parser = new JsonParser(); JsonObject json =
			 * (JsonObject) parser.parse(jsonObject.get("result").toString());
			 */

		} catch (Exception e) {
			System.out.println("Exception in getRegressionDynamicAnalysis1()");
			e.printStackTrace();
		}
		return analyticsResult;

	}
	@RequestMapping(value = "/getClusterAnalyticsInput/{flightId}/{numberOfClusters}/{noOfRecs}", method = RequestMethod.GET)
	public @ResponseBody String getClusterAnalyticsInput(
			@PathVariable("flightId") long flightId,
			@PathVariable("numberOfClusters") String numberOfClusters,
			@PathVariable("noOfRecs") String noOfRecs) {

		/*
		 * String analyticsInputStr =
		 * "{ \"data\": {\"data_set\": {\"verticalAcceleration\": [\"1.0\", \"1.2\",\"1.3\",\"1.1\"],\"airspeed\": [\"54.3\",\"53.8\",\"53.6\",\"53.7\"]}, \"number of clusters\":\"3\",\"method\":\"0\"}}"
		 * ; System.out.println("analyticsInputStr is :: " + analyticsInputStr);
		 */

		System.out
				.println("AircraftService.getClusterAnalyticsWithDataDynamic() : start");
		int dataSize = Integer.parseInt(noOfRecs);
		System.out.println("dataSize=" + dataSize);

		List<FleetData2DTO> airborneDtoList = new ArrayList<FleetData2DTO>();
		String analyticsResult = "";

		try {

			airborneDtoList = getFlightAirborneData(flightId);

			JSONObject obj = new JSONObject();

			List<String> airSpeedDbl = new ArrayList<String>();
			List<String> verticalDbl = new ArrayList<String>();
			int size = airborneDtoList.size() ;
			size =  dataSize;
			System.out
					.println("size is:***" + size);
			for (int i = 0; i < size; i++) {
				System.out
						.println("size is : " + airborneDtoList.size());
				
				System.out
				.println("i value is: " + airborneDtoList.get(i));
				
				if (null != airborneDtoList.get(i).getAirspeed()) {
					airSpeedDbl.add(airborneDtoList.get(i).getAirspeed()
							.toString());
				} else {
					airSpeedDbl.add("0.0");
				}
				if (null != airborneDtoList.get(i).getVerticalAcceleration()) {
					verticalDbl.add(airborneDtoList.get(i)
							.getVerticalAcceleration().toString());
				} else {
					verticalDbl.add("0.0");
				}
			}
			obj.put("verticalAcceleration", verticalDbl);
			obj.put("airspeed", airSpeedDbl);

			StringWriter out = new StringWriter();
			obj.write(out);

			String jsonText = out.toString();
			// System.out.print("jsonText is: "+jsonText);

			String avio = "{ \"data\": {\"data_set\":";
			String end = ", \"number of clusters\": " + numberOfClusters
					+ ",\"method\":\"0\"}}";

			String finalJson = avio + jsonText + end;
			System.out.println("finalJson is *************:" + finalJson);
			analyticsResult = finalJson.toString();

			/*
			 * JSONObject jsonObject = new JSONObject(jsonResponse.getBody());
			 * JsonParser parser = new JsonParser(); JsonObject json =
			 * (JsonObject) parser.parse(jsonObject.get("result").toString());
			 */

		} catch (Exception e) {
			System.out.println("Exception in getAnalyticsInput()");
			e.printStackTrace();
		}
		return analyticsResult;

	}

}
