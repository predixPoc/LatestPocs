package com.ge.data.analytic.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ge.data.analytic.entity.AutomationTrackerData;

public interface AutomationTrackerRepo extends JpaRepository<AutomationTrackerData, Long>{
	
	String GET_DOWNLOAD_COUNT_BY_PROJECTNAME_AUTOMATION_NAME = "from AutomationTrackerData t where t.projectName =?1 and t.automationName=?2";
	//String GET_DOWNLOAD_COUNT_BY_PROJECTNAME_AUTOMATION_NAME = "from AutomationTrackerData t where t.projectName=:projectName and t.automationName=:automationName";
	
	String GET_DISTINCT_ContributorName="select DISTINCT at.contributorName from AutomationTrackerData at";
	
	String Get_Reward_Details_Contributorwise="select DISTINCT a.businessName,a.projectName,b.contributorName,b.rewardName,b.starRating from AutomationTrackerData a,Reward b "
			+ "where a.contributorName=b.contributorName and b.projectName=a.projectName and b.contributorName=?1";

	@Override
	List<AutomationTrackerData> findAll();
	List<AutomationTrackerData> findByAutomationId(long automationId);
	
	
	
	
	@Query(GET_DOWNLOAD_COUNT_BY_PROJECTNAME_AUTOMATION_NAME)
	List<AutomationTrackerData> getDownloadCount(String projectName, String automationName);
	
	@Query(GET_DISTINCT_ContributorName)
	List<AutomationTrackerData> findAllContributorList();
	
	
	@Query(GET_DISTINCT_ContributorName)
	List<Object[]> findAllContributorList1();
	
	
	
	@Query(Get_Reward_Details_Contributorwise)
	List<Object[]> rewardDetailsOfData(String contributorName);

}
