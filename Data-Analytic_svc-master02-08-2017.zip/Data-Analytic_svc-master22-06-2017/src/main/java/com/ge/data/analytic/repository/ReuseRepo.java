package com.ge.data.analytic.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ge.data.analytic.entity.AutomationTrackerData;
import com.ge.data.analytic.entity.ReuseData;

public interface ReuseRepo extends JpaRepository<ReuseData, Long>{
	
	@Override
	List<ReuseData> findAll();
	
	
	List<ReuseData> findByReuseId(long reuseId);

}
