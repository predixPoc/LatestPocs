package com.ge.data.analytic.service;

import java.util.List;

import com.ge.data.analytic.entity.AutomationTrackerData;
import com.ge.data.analytic.entity.ReuseData;
import com.ge.data.analytic.entity.Reward;
import com.ge.data.analytic.entity.TeamInfo;
import com.ge.data.analytic.entity.UserData;
import com.ge.data.analytic.exception.DataAnalyticException;


public interface IDataAnalyticService {

	UserData createNewUser(UserData user) throws DataAnalyticException;
	UserData findExistingUser(String userName) throws DataAnalyticException;
	
	List<AutomationTrackerData> getAllTrackerData() throws DataAnalyticException;
	List<AutomationTrackerData> saveAutomationDataList(List<AutomationTrackerData> automationDataList) throws DataAnalyticException;
	AutomationTrackerData saveAutomationData(AutomationTrackerData automationData) throws DataAnalyticException;
	List<AutomationTrackerData> getDownloadCount(Long automationId) throws DataAnalyticException;
	AutomationTrackerData updateDownloadCount(Long automationId) throws DataAnalyticException;
	
	List<ReuseData> getAllReuseData() throws DataAnalyticException;
	List<ReuseData> saveReuseDataList(List<ReuseData> automationDataList) throws DataAnalyticException;
	
	List<Reward> getRewardList(String contributorName) throws DataAnalyticException;
	UserData getUserIdFromUserName(String userName) throws DataAnalyticException;
	Reward findExistingReward(String automationName, String projectName, String contributorName, long userId) throws DataAnalyticException;
	Reward saveRewardData(Reward rewardData)throws DataAnalyticException;
	List<AutomationTrackerData> getAllContributorListData()throws DataAnalyticException;
	List<Object[]> getAllContributorListData1()throws DataAnalyticException;
	List<Object[]> rewardDetailsAsPerContributor(String contributorName)throws DataAnalyticException;
	
	
	//List<DownloadCounter> getAllDownloadData() throws DataAnalyticException;	
	//DownloadCounter updateDownloadConter() throws DataAnalyticException;
	
	
	//TEAM tab : Team information details - start
	TeamInfo getTeamMemberDetails(long teamMemberId)throws DataAnalyticException;
	//TEAM tab : Team information details - end
	ReuseData updateReuseDowloadData(long reuseId)throws DataAnalyticException;
	
	
}
