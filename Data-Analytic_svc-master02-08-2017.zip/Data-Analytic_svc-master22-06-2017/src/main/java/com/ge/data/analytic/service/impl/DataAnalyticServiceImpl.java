package com.ge.data.analytic.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.data.analytic.entity.AutomationTrackerData;
import com.ge.data.analytic.entity.ReuseData;
import com.ge.data.analytic.entity.Reward;
import com.ge.data.analytic.entity.TeamInfo;
import com.ge.data.analytic.entity.UserData;
import com.ge.data.analytic.exception.DataAnalyticException;
import com.ge.data.analytic.repository.AutomationTrackerRepo;
import com.ge.data.analytic.repository.DownloadRepository;
import com.ge.data.analytic.repository.ReuseRepo;
import com.ge.data.analytic.repository.RewardRepo;
import com.ge.data.analytic.repository.TeamInfoRepository;
import com.ge.data.analytic.repository.UserDataRepository;
import com.ge.data.analytic.service.IDataAnalyticService;

@Component
public class DataAnalyticServiceImpl implements IDataAnalyticService {
	private static final Logger LOGGER = LoggerFactory
			.getLogger(DataAnalyticServiceImpl.class);
	
	
	@Autowired
	private UserDataRepository userRepo;
	
	@Autowired
	private AutomationTrackerRepo trackerRepo;
	
	@Autowired
	private ReuseRepo reuseRepo;
	
	@Autowired
	private RewardRepo rewardRepo;
	
	@Autowired
	private DownloadRepository downloadRepo;
	
	//TEAM tab : Team information details - start
	@Autowired
	private TeamInfoRepository teamInfoRep;
	//TEAM tab : Team information details - end


	@Override
	public UserData createNewUser(UserData user)
			throws DataAnalyticException {
		UserData current;
		try {
			current = userRepo.save(user);
			LOGGER.debug("User created: " + current.getUserId());
		} catch (Exception e) {
			throw new DataAnalyticException("Error while creating User", e);
		}
		return current;
	}
	@Override
	public UserData findExistingUser(String userName) throws DataAnalyticException{
		UserData existUser;
		try {
			existUser = userRepo.findUser(userName);
		} catch (Exception e) {
			throw new DataAnalyticException("Error while creating User", e);
		}
		return existUser;
	}
	@Override
	public List<AutomationTrackerData> getAllTrackerData() throws DataAnalyticException{
		List<AutomationTrackerData> dataList= null;
		try {
			dataList = trackerRepo.findAll();
		} catch (Exception e) {
			throw new DataAnalyticException("Error while fetching Tracker Data", e);
		}
		return dataList;
	}
	
	@Override
	public List<ReuseData> getAllReuseData() throws DataAnalyticException{
		List<ReuseData> dataList= null;
		try {
			dataList = reuseRepo.findAll();
		} catch (Exception e) {
			throw new DataAnalyticException("Error while fetching Reuse Data", e);
		}
		return dataList;
	}
	
	@Override
    public List<AutomationTrackerData> saveAutomationDataList(List<AutomationTrackerData> dataList) throws DataAnalyticException {
	    List<AutomationTrackerData> currentSet;
	    try {
	      currentSet = trackerRepo.save(dataList);
	    } catch (Exception e) {
	      throw new DataAnalyticException("Error while saving Automation tracker Data", e);
	    }
	    return currentSet;
	}
	
	@Override
    public AutomationTrackerData saveAutomationData(AutomationTrackerData data) throws DataAnalyticException {
	    AutomationTrackerData currentSet;
	    try {
	      currentSet = trackerRepo.save(data);
	    } catch (Exception e) {
	      throw new DataAnalyticException("Error while saving Automation tracker Data", e);
	    }
	    return currentSet;
	}
	
	@Override
    public List<ReuseData> saveReuseDataList(List<ReuseData> dataList) throws DataAnalyticException {
	    List<ReuseData> currentSet;
	    try {
	      currentSet = reuseRepo.save(dataList);
	    } catch (Exception e) {
	      throw new DataAnalyticException("Error while saving Reuse Data", e);
	    }
	    return currentSet;
	}
	
	@Override
	public List<Reward> getRewardList(String contributorName) throws DataAnalyticException{
		List<Reward> dataList= null;
		try {
			dataList = rewardRepo.findRewardName(contributorName);
		} catch (Exception e) {
			throw new DataAnalyticException("Error while fetching Reward Data", e);
		}
		return dataList;
	}
	
	/*@Override
	public List<DownloadCounter> getAllDownloadData() throws DataAnalyticException{
		List<DownloadCounter> dataList= null;
		try {
			dataList = downloadRepo.findAll();
		} catch (Exception e) {
			throw new DataAnalyticException("Error while fetching DownloadCounter Data", e);
		}
		return dataList;
	}
	
	@Override
	public DownloadCounter updateDownloadConter() throws DataAnalyticException{
		DownloadCounter data= null;
		try {
			List<DownloadCounter> dataList = getAllDownloadData();
			int totalDownloadNum = dataList.get(0).getTotalNoOfDownload();
			dataList.get(0).setTotalNoOfDownload(totalDownloadNum+1);
			data = downloadRepo.save(dataList.get(0));
		} catch (Exception e) {
			throw new DataAnalyticException("Error while updating DownloadCounter Data", e);
		}
		return data;
	}*/
	
	@Override
	public List<AutomationTrackerData> getDownloadCount(Long automationId) throws DataAnalyticException{
		List<AutomationTrackerData> data= null;
		try {
			data = trackerRepo.findByAutomationId(automationId);
			System.out.println(data.size()+"+++size data++++");
		} catch (Exception e) {
			e.printStackTrace();
			throw new DataAnalyticException("Error while fetching download count from Automation_Tracker table", e);
		}
		return data;
	}
	
	@Override
	public AutomationTrackerData updateDownloadCount(Long automationId) throws DataAnalyticException{
		AutomationTrackerData data= null;
		try {
			List<AutomationTrackerData> trackerData = getDownloadCount(automationId);
			Integer totalCount = trackerData.get(0).getTotalDownloadCount();
			if(totalCount == null){
				totalCount=0;
			}
			trackerData.get(0).setTotalDownloadCount(totalCount.intValue()+1);
			data = trackerRepo.save(trackerData.get(0));
		} catch (Exception e) {
			throw new DataAnalyticException("Error while updating Download Count data in Automation Tracker table.", e);
		}
		return data;
	}
	
	
	
	
	@Override
	public ReuseData updateReuseDowloadData(long reuseId) throws DataAnalyticException{
		ReuseData data= null;
		try {
			List<ReuseData> trackerData = getDownloadReuseCount(reuseId);
			Integer totalCount = trackerData.get(0).getDownloadCounter();
			if(totalCount == null){
				totalCount=0;
			}
			trackerData.get(0).setDownloadCounter(totalCount.intValue()+1);
			data = reuseRepo.save(trackerData.get(0));
		} catch (Exception e) {
			throw new DataAnalyticException("Error while updating Download Count data in ReuseTracker table.", e);
		}
		return data;
	}
	

	
	private List<ReuseData> getDownloadReuseCount(Long reuseId)throws DataAnalyticException {
		List<ReuseData> data= null;
		try {
			data = reuseRepo.findByReuseId(reuseId);
			System.out.println(data.size()+"+++size data++++");
		} catch (Exception e) {
			e.printStackTrace();
			throw new DataAnalyticException("Error while fetching download count from Automation_Tracker table", e);
		}
		return data;
	}
	@Override
	public UserData getUserIdFromUserName(String userName) throws DataAnalyticException{
		UserData data= null;
		try {
			data = userRepo.findUser(userName);
			//data = trackerRepo.findByAutomationId(automationId)
			System.out.println(data+"+++size data++++");
		} catch (Exception e) {
			e.printStackTrace();
			throw new DataAnalyticException("Error while fetching download count from Automation_Tracker table", e);
		}
		return data;
	}
	
	@Override
	public Reward findExistingReward(String automationName,String projectName,String contributorName,long userId) throws DataAnalyticException{
		Reward reward;
		try {
			reward = rewardRepo.findExistingReward(automationName,projectName,contributorName,userId);
		} catch (Exception e) {
			
			throw new DataAnalyticException("Error while creating User", e);
		}
		return reward;
	}
	
	@Override
	public Reward saveRewardData(Reward reward)
			throws DataAnalyticException {
		Reward rewardVal;
		try {
			rewardVal = rewardRepo.save(reward);
			
			LOGGER.debug("Reward Services Created Successfully: " + reward.getUserId());
		} catch (Exception e) {
			throw new DataAnalyticException("Error while Reward Services Created Successfully:", e);
		}
		return rewardVal;
	}
	
	@Override
	public List<AutomationTrackerData> getAllContributorListData()throws DataAnalyticException {
		List<AutomationTrackerData> dataList= null;
		try {
			dataList = trackerRepo.findAllContributorList();
		} catch (Exception e) {
			throw new DataAnalyticException("Error while fetching Tracker Data", e);
		}
		return dataList;
	}
	
	@Override
	public List<Object[]> getAllContributorListData1() throws DataAnalyticException {
		List<Object[]> dataList= null;
		try {
			dataList = trackerRepo.findAllContributorList1();
		} catch (Exception e) {
			throw new DataAnalyticException("Error while fetching Tracker Data", e);
		}
		return dataList;
	}
	

	@Override
	public List<Object[]> rewardDetailsAsPerContributor(String contributorName)throws DataAnalyticException{
		List<Object[]> dataList= null;
		try {
			dataList = trackerRepo.rewardDetailsOfData(contributorName);
		} catch (Exception e) {
			throw new DataAnalyticException("Error while fetching Tracker Data", e);
		}
		return dataList;
	}
	
	//TEAM tab : Team information details - start
	@Override
	public TeamInfo getTeamMemberDetails(long teamMemberId)
			throws DataAnalyticException {
		TeamInfo teamInfo= null;
		try {
			teamInfo = teamInfoRep.getTeamMemberDetails(teamMemberId);
		} catch (Exception e) {
			throw new DataAnalyticException("Error while fetching Team member details", e);
		}
		return teamInfo;
	}
	//TEAM tab : Team information details - end
	
}
