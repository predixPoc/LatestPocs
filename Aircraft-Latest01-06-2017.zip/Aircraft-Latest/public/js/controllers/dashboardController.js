app.controller('dashboardController', function($scope, googleChartApiPromise, $filter, $http,$q, $rootScope,constants, $state, Auth, $timeout, toaster, $cookies, $cookieStore, WorkFlow, supplier, dashboardReporting){
	$scope.loader = true;
	getChartsData();
	function getChartsData(){
		dashboardReporting.getOverAllStatus().then(function(data){
			$scope.requestChartData = processRequestChart(data.data);
		}, function(data){
			toaster.pop('error', "REQUESTS CHART", "server not responding");
		});

		dashboardReporting.getApprovingStatus().then(function(data){
			$scope.totalApproversChartData = processTotalApproversChart(data.data);
		}, function(data){
			toaster.pop('error', "TOTAL APPROVERS CHART", "server not responding");
		});

		dashboardReporting.getInvitationStatus().then(function(data){
			$scope.invitationChartData = processInvitationChart(data.data);
		}, function(data){
			toaster.pop('error', "INVITATIONS CHART", "server not responding");
		});

		dashboardReporting.getTasksCompletion().then(function(data){
			$scope.approvalByPercentChartData = processApprovalStatusChart(data.data);
		}, function(data){
			toaster.pop('error', "APPROVAL BY % CHART", "server not responding");
		});

		dashboardReporting.getSelfServeCycleTime().then(function(data){
			$scope.approvalByPercentChartData = processAverageCycleTimeChart(data.data.pages);
			$scope.loader = false;
		}, function(data){
			toaster.pop('error', "AVG CYCLE TIME (DAYS) CHART", "server not responding");
			$scope.loader = false;
		});

		dashboardReporting.getComplianceAndPayments().then(function(data){
			$scope.compliancePaymentChartData = processCompliancePaymentChart(data.data);
			$scope.loader = false;
		}, function(data){
			toaster.pop('error', "COMPLIANCE AND PAYMENT", "server not responding");
			$scope.loader = false;
		});
	}
	
	 // request chart
	function processRequestChart(data){
	  	var chartData = [['','']];

	  	for (var i = 0, l = data.length; i < l; i++) {
	    	chartData.push([data[i].name, data[i].counts]);
	  	}

		var requestChart = {};
	    requestChart.type = "PieChart";
	    requestChart.data = chartData;
	    requestChart.options = {
	        displayExactValues: true,
	        pieSliceText: 'value',
	        pieSliceTextStyle: {
	            color: 'white',
	            fontSize: 9,
	        },
	        slices: {0:{color: '#19a4de'}, 1:{color: '#8cc63f'}, 2:{color: '#f8981d'},},
	        pieHole: 0.4,
	        width: 365,
	        height: 245,
	        is3D: false,
	        chartArea: {left:13,top:10,bottom:0,width:"85%",height:"90%"}
	    };
	    $scope.requestChart = requestChart;
	};

	// total approvers chart
	function processTotalApproversChart(data){
	  	var chartData = [['','']];
	  	for (var i = 0, l = data.length; i < l; i++) {
	    	chartData.push([data[i].name, data[i].counts]);
	  	}

		var totalApproversChart = {};
	    totalApproversChart.type = "PieChart";
	    totalApproversChart.data = chartData;
	    totalApproversChart.options = {
	        displayExactValues: true,
	        pieSliceText: 'value',
	        pieSliceTextStyle: {
	            color: 'white',
	            fontSize: 9,
	        },
	        slices: {0:{color: '#19a4de'}, 1:{color: '#8cc63f'}, 2:{color: '#f8981d'},},
	        pieHole: 0.4,
	        width: 365,
	        height: 245,
	        is3D: false,
	        chartArea: {left:13,top:10,bottom:0,width:"85%",height:"90%"}
	    };
	    $scope.totalApproversChart = totalApproversChart;

	};

    // invitation chart
    function processInvitationChart(data){
  
	  	var chartData = [['','']];
	  	for (var i = 0, l = data.length; i < l; i++) {
	    	chartData.push([data[i].name, data[i].counts]);
	  	}
	    var invitationChart = {};
	    invitationChart.type = "PieChart";
	    invitationChart.data = chartData;
	    invitationChart.options = {
	        displayExactValues: true,
	        pieSliceText: 'value',
	        pieSliceTextStyle: {
	            color: 'white',
	            fontSize: 9,
	        },
	        slices: {0:{color: '#19a4de'}, 1:{color: '#8cc63f'}, 2:{color: '#f8981d'},},
	        pieHole: 0.4,
	        width: 365,
	        height: 245,
	        is3D: false,
	        chartArea: {left:13,top:10,bottom:0,width:"85%",height:"90%"}
	    };
	    $scope.invitationChart = invitationChart;
	    // $scope.loader = false;
	}

    // compliancePayment chart
    // processCompliancePaymentChart();
    function processCompliancePaymentChart(data) {
  
	  	var chartData = [['','']];
	  	angular.forEach(data, function(value, key){
	  		chartData.push([key, value]);
	  	})
	  	// for (var i = 0, l = data.length; i < l; i++) {
	   //  	chartData.push([data[i].name, data[i].counts]);
	  	// }
	    var compliancePaymentChart = {};
	    compliancePaymentChart.type = "BarChart";
	    compliancePaymentChart.data = chartData;
	    compliancePaymentChart.options = {
	        displayExactValues: true,
	        isStacked: true,
	        width: '50%',
	        height: '60%',
	        legend:{position: "none"},
	        axisTitlesPosition: 'top',
	        bar: { groupWidth: '55%' },
	        chartArea: {
	            left: "5%",
	            top: "10%",
	            height: "60%",
	            width: "50%",
	        },
	        vAxis: {
	            title: ""
	        },
	        hAxis: {
	            title: "Number of Suppliers",
	            // ticks: [0, 50,100]
	        }
	    };
	    $scope.compliancePaymentChart = compliancePaymentChart;
	    $scope.cpLegend=true;
	};

	// Approval by percent chart
    function processApprovalStatusChart(data) {
  
    	$scope.tempArray = [];
		angular.forEach(data, function(value, key){
			$scope.approvalPercentage = (value.completed/value.total)*100;
			$scope.tempArray.push({"name": key, "approvalPercentage": $scope.approvalPercentage, "completed": value.completed, "total": value.total});
		});

	  	var chartData = [['','']];
	  	for (var i = 0, l = $scope.tempArray.length; i < l; i++) {
	    	chartData.push([$scope.tempArray[i].name, $scope.tempArray[i].approvalPercentage]);
	  	}

		var approvalStatusChart = {}
		approvalStatusChart.type = "BarChart";
	    approvalStatusChart.data = chartData;
	    approvalStatusChart.options = {
	        displayExactValues: true,
	        width: '50%',
	        height: '60%',
	        legend:{position: "none"},
	        bar: { groupWidth: '70%' },
	        pieSliceText: 'percentage',
	        colors: ['rgb(51, 102, 204)', '#4285f4'],
	        chartArea: {
	            left: "25%",
	            top: "10%",
	            height: "70%",
	            width: "70%"
	        },
	        vAxis: {
	            title: ""
	        },
	        hAxis: {
	            title: "",
	            ticks: [0, 50,100]
	        }
	    };
	    $scope.approvalStatusChart = approvalStatusChart;
	}

		// Average cycle time (dayss) chart
    function processAverageCycleTimeChart(data) {
  
	  	var chartData = [['','']];
	  	for (var i = 0, l = data.length; i < l; i++) {
	  		var averageCycleTime = (data[i].avgElapsedTimeSeconds / 60);
	    	chartData.push([data[i].pageName, averageCycleTime]);
	  	}
	    var processStepChart = {}
		processStepChart.type = "BarChart";
	    processStepChart.data = chartData;
	    processStepChart.options = {
	        displayExactValues: true,
	        width: '50%',
	        height: '60%',
	        legend:{position: "none"},
	        bar: { groupWidth: '60%' },
	        pieSliceText: 'value',
	        colors: [ '#8cc63f'],
	        chartArea: {
	            left: "25%",
	            top: "10%",
	            height: "70%",
	            width: "70%"
	        },
	        vAxis: {
	            title: ""
	        },
	        hAxis: {
	            title: "",
	            // ticks: [0, 10,20]
	        }
	    };
	    $scope.processStepChart = processStepChart;
	    
	}
});