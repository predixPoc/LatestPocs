app.controller('onboardingSupplierProfileContactsController', function($scope, $filter, $http, $rootScope,
    $state, Auth, $timeout, toaster, $cookies, $cookieStore, WorkFlow, supplier, constants) {

    var cookie = $cookieStore.get("sc_token");

    $scope.supplierInfo = {};
	if(!WorkFlow.getRequestId()){
		toaster.pop('error', "No Open Task found !", "Request Id is retrieving as null");
		$state.go('supplierHome');
		return;
	}
    // Back Button Click
    $scope.prevForBusinessInfo = function() {
        $state.go('supplierProfileBank');
    }

    // Get Phone Codes
    supplier.getPhoneCodes().then(function(data) {
        $scope.phoneCodes = data;
    }, function() {
        toaster.pop('error', "Phone list", "server not responding");
    });

    // Save Button
    $scope.saveAndNext = function(supplierInfo, next) {
        $scope.submitted = true;
        var isValid = true;
        angular.forEach(supplierInfo.contactList, function(contact, key){
            if(isValid){
                console.log(contact)
                if(!contact.firstName || !contact.lastName || contact.firstName === '' || contact.lastName === '' || contact.businessPhoneNumber=='' || !contact.businessPhoneNumber
				|| !contact.businessPhoneCountryId || contact.businessPhoneCountryId==''
				){
                    isValid = false;
                    toaster.pop('error', "Please enter required fields");
                } else {
                    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                    if(!contact.email || !re.test(contact.email)){
                        isValid = false;
                        toaster.pop('error', "Please enter valid email");
                    }
                }
            }
        });
        if(isValid){
            $rootScope.supplierProfileContactsDone = true;
            $scope.loader = true;
            WfModel.supplier.contacts = supplierInfo.contactList;
            WorkFlow.setVariablesV2(WfModel).then(function(data) {
                $scope.loader = false;
                toaster.pop('success', "Saved successfully");
                if (next) {
                    $state.go('supplierProfileDiversity');
                }
            }, function(data) {
                $scope.loader = false;
                toaster.pop('error', "Workflow Api failed");
            });
        }

    }

    $scope.addContact = function() {
        if(!$scope.supplierInfo.contactList){
            $scope.supplierInfo.contactList = []
        }
        $scope.supplierInfo.contactList.push({
            "isAdditionalContact": true
        });
    }

    $scope.deleteContact = function(contact) {
        var index = $scope.supplierInfo.contactList.indexOf(contact);
        $scope.supplierInfo.contactList.splice(index, 1);
    }

    var getDefaultPhoneCode=function(id){
        // $scope.supplierInfo.countryCodeForProfile = code;
        supplier.getCountryById(id).then(function(data){
            $scope.isoA3 = data.isoA3;
            supplier.getPhoneCodes().then(function(data){
                $scope.phoneCodes = data;
                angular.forEach($scope.phoneCodes, function(value, key){
                    if(value.isoA3 === $scope.isoA3){
                        var bussinessPhoneCode=value.phoneCode;
                        var businessPhoneCountryId=value.code
                    }
                })
            }, function() {
                toaster.pop('error', "Phone list", "server not responding");
            });
        }, function() {
            toaster.pop('error', "Country list", "server not responding");
        });
    }

    // Initialize
    var WfModel = {};
    WorkFlow.getVariablesV2().then(function(workflowData) {
        // var mobilePhoneNumber = businessPhoneCountryId
        WfModel = workflowData.data;
        // getDefaultPhoneCode(WfModel.supplier.countryId);
        if (workflowData.data) {
            if(workflowData.data.supplier.contacts && workflowData.data.supplier.contacts && workflowData.data.supplier.contacts.length > 0){
                $scope.supplierInfo.contactList = workflowData.data.supplier.contacts;
            } else {
                $scope.supplierInfo.contactList = [{
                    "contactType": "SALES",
					firstName: WfModel.onboardingContact.firstName,
					lastName: WfModel.onboardingContact.lastName,
					email: WfModel.onboardingContact.email,
					businessPhoneNumber: WfModel.onboardingContact.businessPhoneNumber,
                    businessPhoneShortCode: WfModel.onboardingContact.businessPhoneCountryId
                }, {
                    "contactType": "ACCOUNTS_RECEIVABLE",
					firstName: WfModel.onboardingContact.firstName,
					lastName: WfModel.onboardingContact.lastName,
					email: WfModel.onboardingContact.email,
					businessPhoneNumber: WfModel.onboardingContact.businessPhoneNumber,
                    businessPhoneShortCode: WfModel.onboardingContact.businessPhoneCountryId
                }, {
                    "contactType": "PURCHASE_ORDER",
					firstName: WfModel.onboardingContact.firstName,
					lastName: WfModel.onboardingContact.lastName,
					email: WfModel.onboardingContact.email,
					businessPhoneNumber: WfModel.onboardingContact.businessPhoneNumber,
                    businessPhoneShortCode: WfModel.onboardingContact.businessPhoneCountryId
                }];
            }
        }
    }, function(error){

    });
});
