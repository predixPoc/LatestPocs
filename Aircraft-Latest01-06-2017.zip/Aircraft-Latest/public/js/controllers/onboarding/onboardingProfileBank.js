app.controller('onboardingProfileBank', function ($scope, $filter, $http, $rootScope,
        $state, Auth, $timeout, toaster, $cookies, $cookieStore, WorkFlow, supplier, constants) {
    $scope.loader = true;
			
    var cookie = $cookieStore.get("sc_token");
    $scope.countCall = -1;
    $scope.nullDataFlag = [];
    var WfModel = {};
    $scope.supplierInfo = {};
    if (!WorkFlow.getRequestId()) {
        toaster.pop('error', "No Open Task found !", "Request Id is retrieving as null");
        //$state.go('supplierHome');
        $scope.loader = false;
        return;
    }


    supplier.getCurrencyList().then(function (data) {
        $scope.currencyList = data;
    }, function () {
        toaster.pop('error', "Currency list", "server not responding");
    });

    $scope.routingLabel = 'Bank Code';
    $scope.routingTooltip = 'Bank Code';
    $scope.accountTooltip = 'Please enter Account Number';
    $scope.setRoutingLabel = function (item) {
        $scope.loader = true;
        supplier.getCountryById(item.bankCountryCode).then(function (data) {
            $scope.loader = false;
            $scope.CountryCode = data.code;
            $scope.loader = true;
            supplier.getRoutingLabel($scope.CountryCode).then(function (data) {
                $scope.loader = false;
                if (data[0]) {
                    item.routingLabel = data[0].routingCode;
                    item.routingTooltip = data[0].definitionTxt;
                    $scope.accountTooltip = data[0].accountFormatTooltip;
                    if ($scope.accountTooltip === null) {
                        item.accountTooltip = 'Please enter Account Number';
                    }
                } else {
                    item.routingLabel = 'Bank Code';
                    item.routingTooltip = 'Bank Code';
                    item.accountTooltip = 'Please enter Account Number';
                }
            }, function () {
                $scope.loader = false;
                toaster.pop('error', "Routing Label", "server not responding");
            });
        }, function () {
            $scope.loader = false;
        });
    }

    $scope.prepareSwifts = function (item) {
        item.swift = '';
        item.iban = '';
    }




    $scope.setCurrency = function (item) {
        //console.log(code);
        $scope.loader = true;
		item.bankCurrency = '';
        supplier.getCountryById(item.bankCountryCode).then(function (data) {
            $scope.loader = false;
            $scope.CountryCode = data.code
            $scope.loader = true;

            supplier.getCountryList($scope.CountryCode).then(function (data) {
                $scope.loader = false;
                //debugger;
                angular.forEach(data, function (value, key) {
                    if (value.code === $scope.CountryCode && !item.bankCurrency) {
                        var idArray = $filter('filter')($scope.currencyList, {'currencyCode': value.currencyCode});
                        if (idArray[0].id) {
                            item.bankCurrency = idArray[0].id;
                        }
                    }
                })
            }, function () {
                $scope.loader = false;
                //toaster.pop('error', "Country list", "server not responding");
            });
        }, function () {
            $scope.loader = false;
            //toaster.pop('error', "Country list", "server not responding");
        });
    }

    $scope.bankAddresses = [];
    $scope.addBankAddress = function () {
        var obj = {};
        obj.associateWithAddress = angular.copy($scope.associateWithAddress);
        $scope.bankAddresses.push(obj);
    }

    $scope.bankExtras = [{}];
    $scope.addBankExtra = function () {
        //$scope.submitted = false;
        var obj = {};
        obj.routingLabel = 'Bank Code';
        obj.routingTooltip = 'Bank Code';
        obj.accountTooltip = 'Please enter Account Number';
        obj.associateWithAddress = angular.copy($scope.associateWithAddress);
		obj.bankCreditDetails = false;
		obj.failCounter = 0;
        $scope.bankExtras.push(obj);
    }

    $scope.deleteAddress = function (item) {
        var index = $scope.bankAddresses.indexOf(item);
        $scope.bankAddresses.splice(index, 1);
        angular.forEach(WfModel.supplier.addresses, function (address, key) {
            if (address.internalId == item.id) {
                index = key;
            }
        });
        WfModel.supplier.addresses.splice(index, 1);
    }

    $scope.deleteBank = function (item) {
        var index = $scope.bankExtras.indexOf(item);
        $scope.bankExtras.splice(index, 1);
    }

    $scope.copy = function (item) {
        return angular.copy(item);
    }

    $scope.makePrimary = function (item) {
		/*
        if (!item.primary)
            return;
        angular.forEach($scope.bankExtras, function (value, key) {
            value.primary = false;
        });
        item.primary = true;
		*/
    }

    $scope.stateChange = function (item, states) {
        angular.forEach(states, function (value, index) {
            if (value.id == item.stateId) {
                
                item.stateName = value.code;
            }
        });
    }

    $scope.chooseFromAddress = function (item) {
        console.log(item);
        console.log(item.selectedAddress);
        if (item.selectedAddress == null) {
            item.changedDrop = true;
        }
    }


    $scope.save = function (supplierInfo, redirect, addressForm) {
        $scope.submitted = true;
        WfModel.supplier.canReceiveFundsElectronically = !$scope.notElectronic;

        //WfModel.supplier.addresses = [];
        if ($scope.notElectronic) {

            WfModel.supplier.banks = [];
            if (addressForm.$invalid) {
                toaster.pop('error', "", "Please fill all mandatory fields");
                return;
            }


            var alertFlag = false;
            angular.forEach($scope.bankAddresses, function (value, key) {
                if (!alertFlag) {
                    angular.forEach(WfModel.supplier.addresses, function (address, key) {
                        var assocFlag = false;
                        angular.forEach(value.associateWithAddress, function (address, key) {
                            if (address.selected) {
                                assocFlag = true;
                            }
                        });
                        if (assocFlag == false) {
                            alertFlag = true;
                        }
                    });
                }
            });
            if (alertFlag) {
                toaster.pop('error', "", "Please choose atleast one associate address");
                return;
            }

            // Delete remittance if there is any 
            var indexes = [];
            angular.forEach(WfModel.supplier.addresses, function (address, key) {
                var typeKey = address.addressTypes.indexOf('REMITTANCE');
                if (typeKey != -1) {

                    if (address.addressTypes.length == 1) {
                        indexes.push(key);
                    }

                    if (address.addressTypes.length > 1) {
                        address.addressTypes.splice(typeKey, 1);
                    }
                }
            });
            angular.forEach(indexes, function (value, key) {
                WfModel.supplier.addresses.splice(value, 1);
            });
            
            angular.forEach($scope.bankAddresses, function (value, key) {
                // If choosen from dropdown
                if (value.selectedAddress) {

                    angular.forEach(WfModel.supplier.addresses, function (address, key) {
                        if (address.internalId == value.selectedAddress) {
                            if (address.addressTypes.indexOf('REMITTANCE') == -1) {
                                address.addressTypes.push('REMITTANCE');
                            }
                            address.boundAddresses = [];
                            angular.forEach(value.associateWithAddress, function (asscoAddress, key) {
                                if (asscoAddress.selected) {
                                    address.boundAddresses.push(asscoAddress.internalId);
                                }
                            });
                        }
                    });

                    // If new address			
                } else {
                    var obj = {
                        "addressTypes": [
                            "REMITTANCE"
                        ],
                        "location": {
                            "addressLine1": value.address1,
                            "addressLine2": value.address2,
                            "addressLine3": value.address3,
                            "addressLine4": value.address4,
                            "cityName": value.city,
                            "countryId": value.addressCountryCode,
                            "poBoxNumber": "string",
                            "postalCode": value.postalCode,
                            "provinceName": "string",
                            "stateId": value.stateId,
                            "stateName": value.stateName
                        }, "boundAddresses": []
                    };
                    angular.forEach(value.associateWithAddress, function (asscoAddress, key) {
                        if (asscoAddress.selected) {
                            obj.boundAddresses.push(asscoAddress.internalId);
                        }
                    });
                    WfModel.supplier.addresses.push(obj);
                }
            });

            saveWorkflow(redirect);
        } else {

            if (supplierInfo.$invalid) {
                toaster.pop('error', "Invalid Fields", "Please fill all mandatory fields");
                return;
            }

            /*
             if(!$scope.acFormatValidation) {
             toaster.pop('error', "", "Please check account number");	
             return;
             }*/

            var alertPrimary = false;
			angular.forEach($scope.bankExtras, function (val, index) {
				if (val.primary) {
					alertPrimary = true;
				}
			});
			if (!alertPrimary) {
				toaster.pop('error', "", "Please select Bank as primary");
				return;
			}
			
			var alertCurrencyPrimary = false;
			angular.forEach($scope.bankExtras, function (val1, index1) {
				if(alertCurrencyPrimary == false){
					angular.forEach($scope.bankExtras, function (val2, index2) {
						if(!angular.equals(val1, val2)) {
							if (val1.primary==true && val2.primary==true) {
								if(val1.bankCurrency == val2.bankCurrency ) {
									debugger;
									alertCurrencyPrimary = true;								
								}							
							}
						}
					});
				}
				
			});
			
			if (alertCurrencyPrimary) {
				toaster.pop('error', "", "Please select one primary bank per currency");
				return;
			}
            /*if ($scope.bankExtras.length == 1) {
                angular.forEach($scope.bankExtras, function (val, index) {
                    if (val.primary) {
                        alertPrimary = true;
                    } else {
                        alertPrimary = false;
                    }
                });
                if (!alertPrimary) {
                    toaster.pop('error', "", "Please select Bank as primary");
                    return;
                }
            } else {
                angular.forEach($scope.bankExtras, function (val, index) {
                    if (val.primary) {
                        alertPrimary = true;
                    }
                });
                if (!alertPrimary) {
                    toaster.pop('error', "", "Please select Bank as primary");
                    return;
                }
            }*/
            
            var regEx = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            var alertFlag = false;
            angular.forEach($scope.bankExtras, function (value, key) {
                if (!alertFlag) {
                    var assocFlag = false;
                    angular.forEach(value.associateWithAddress, function (address, key) {
                        if (address.selected) {
                            assocFlag = true;
                        }
                    });
                    if (assocFlag == false) {
                        alertFlag = true;
                        toaster.pop('error', "", "Please choose atleast one associate address for each bank");
                    }

                    if (value.remittance && !regEx.test(value.remittance)) {
                        alertFlag = true;
                        value.invalidEmail = false;
                        toaster.pop('error', "Please enter valid remittance email");
                    }
                }
            });
            if (alertFlag) {
                return;
            }
            // Backend validations 

            angular.forEach($scope.bankExtras, function (item, key) {
                if (!alertFlag) {
					item.chinaCase = false;					
					
                    //Account No. Validation
                    var idArray = $filter('filter')($scope.chooseCountries, {'id': item.bankCountryCode});
                    
                    var countryCode = ''
                    if (idArray[0].code) {
                        countryCode = idArray[0].code
                    }
					
					// CHINA - diffrent case
					if(idArray[0].code == 'CN' && idArray[0].currencyCode == 'CNY' ){
						
						//if(!item.branch_information_alt){							
							item.chinaCase = true;													
						//}
					}
					debugger;
					
					
                    $scope.loader = true;
                    supplier.AccountNumberFormat(item.bankAccountNumber, countryCode).then(function (data) {

                        if (data.data == "true") {
                            item.acFormatValidation = true;

                            supplier.LocalRoutingFormat(item.abaRouting, countryCode).then(function (data) {

                                if (data.data == "true") {
                                    item.localRoutingValidation = true;

                                    
									if (item.failingCaseTrue == false || item.failingCaseTrue == null) {
										// SWIFT call on rule engine success
										supplier.abaNumberRouting(item.abaRouting, countryCode).then(function (data) {


											if (data) {
												//$scope.goNextPage = true;
												
													supplier.getBranchInfo(item.abaRouting, countryCode).then(function (data) {
														item.failingCaseTrue = false;
														if (data.length == 0) {
															if (item.branch_information == null || item.institution_name == null || item.address1 == null || item.town_name == null || item.country_subdivision == null || item.country_name == null) {
																item.showForm = true;
																toaster.pop('error', "Mandatory Fields", "Please fill all the mandatory fields");
																return;
															} else {
																item.bankName = item.institution_name;
																item.addressLine1 = item.address1;
																item.addressLine2 = item.address2;
																item.addressLine3 = item.address3;
																item.addressLine4 = item.address4;
																item.bankCountryCode = item.bankCountryCode;
																item.bankCountryName = item.country_name;
																item.bankStateName = item.country_subdivision;
																item.bankCityName = item.town_name;
																item.bankBranchInformation = item.branch_information;
																item.bankInstitutionName = item.institution_name;
																item.bankpoBoxNumber = item.POBnumber;

															}

														} else {
															item.bankName = data.institution_name;
															item.addressLine1 = data.address.address_lines[0];
															item.addressLine2 = data.address.address_lines[1];
															item.addressLine3 = data.address.address_lines[2];
															item.addressLine4 = data.address.address_lines[3];
															item.bankCountryCode = item.bankCountryCode;
															item.bankCountryName = data.address.country_name;
															item.bankStateName = data.address.country_subdivision;
															item.bankCityName = data.address.town_name;
															item.bankBranchInformation = data.branch_information;
															item.bankInstitutionName = data.institution_name;
															item.bankpoBoxNumber = data.address.post_office_box;
															// Fill form with fields - if china
															if(item.chinaCase && !item.institution_name_alt ) {
																alertFlag=true;
																item.showForm = true;
																item.branch_information_alt =  data.branch_information;
																item.institution_name_alt =  data.institution_name;
																item.address1 = data.address.address_lines[0];
																item.zip_code = data.address.post_code[0];
																item.town_name = data.address.town_name;
																item.POBnumber = data.address.post_office_box;
																item.country_name = item.bankCountryCode;
																$scope.getStateListForBankCountry(item);																
															}
														}
														if (key == ($scope.bankExtras.length - 1) && !alertFlag) {

															// clear all address - Delete remittance if there is any 
															var indexes = [];
															angular.forEach(WfModel.supplier.addresses, function (address, key) {
																var typeKey = address.addressTypes.indexOf('REMITTANCE');
																if (typeKey != -1) {

																	if (address.addressTypes.length == 1) {
																		indexes.push(key);
																	}

																	if (address.addressTypes.length > 1) {
																		address.addressTypes.splice(typeKey, 1);
																	}
																}
															});
															angular.forEach(indexes, function (value, key) {
																WfModel.supplier.addresses.splice(value, 1);
															});


															WfModel.supplier.banks = [];
															angular.forEach($scope.bankExtras, function (value, key) {
																var obj = {
																	partyAccountName: value.bankAccountName,
																	partyAccountNameAlt: null,
																	partyBankInfo: {
																		//institutionName: value.bankInstitutionName,
																		bankNameAlt: value.institution_name_alt,
																		branchNameAlt: value.branch_information_alt ,
																		bankCountryCode: value.bankCountryCode,
																		bankCountryName: value.bankCountryName,
																		bankLocalRoutingNumber: value.abaRouting,
																		accountNumber: value.bankAccountNumber,
																		accountCurrencyId: value.bankCurrency,
																		iban: value.iban,
																		swift: value.swift,
																		isPrimary: value.primary,
																		remittanceEmailAddress: value.remittance,
																		addresses: [],
																		//branchInformation: value.bankBranchInformation,
																		branchName: value.bankBranchInformation,
																		bankAddress: {
																			"countryId": value.bankCountryCode,
																			"stateId": null,
																			"stateName": value.bankStateName,
																			"cityName": value.bankCityName,
																			"provinceName": value.bankStateName,
																			"postalCode": null,
																			"addressLine1": value.addressLine1,
																			"addressLine2": value.addressLine2,
																			"addressLine3": value.addressLine3,
																			"addressLine4": value.addressLine4,
																			"poBoxNumber": value.bankpoBoxNumber
																		},
																		bankName: value.bankName
																				//bankName: 'BANK OF AMERICA N.A.'
																	},
																	useFurtherCreditTo: value.bankCreditDetails,
																	furtherCreditTo: {
																		bankName: value.bankCreditName,
																		accountNumber: value.bankCreditNumber,
																		beneficiaryName: value.bankCreditBenName
																	}
																};
																angular.forEach(value.associateWithAddress, function (address, key) {
																	if (address.selected) {
																		obj.partyBankInfo.addresses.push(address.internalId);
																	}
																});
																WfModel.supplier.banks.push(obj);
																console.log("WfModel.supplier.banks::", WfModel.supplier.banks);
																console.log("WfModel.supplier.banks::" + JSON.stringify(WfModel.supplier.banks));
															});
															saveWorkflow(redirect);
														}

													}, function (data) {
														$scope.loader = false;
														alertFlag=true;
														item.failCounter++;
														if(item.failCounter>=2) {
															item.showForm = true;
															item.failingCaseTrue = true;
														}

														if (item.branch_information == null || item.institution_name == null || item.address1 == null || item.town_name == null || item.country_subdivision == null || item.country_name == null) {
															if(item.failCounter>=2){
																item.showForm = true;
																toaster.pop('error', "Mandatory Fields", "Please fill all the mandatory fields manually.");
																return;
															}															
														}
														debugger;
														if (data.httpStatusCode == 404) {
															$scope.uiMessage = data.uiMessage;
															toaster.pop('error', item.routingLabel + " Format Valid", $scope.uiMessage);
														   
															return;
														}
													});
											   
												$scope.loader = false;
											}
										}, function (data) {
											debugger;
											$scope.loader = false;
											alertFlag=true;
											item.failCounter++;											 										 
												if(item.failCounter>=2){
													item.showForm = true;
													item.failingCaseTrue = true;													
												}													

												if (item.branch_information == null || item.institution_name == null || item.address1 == null || item.town_name == null || item.country_subdivision == null || item.country_name == null) {
													if(item.failCounter>=2) {
														item.showForm = true;
														toaster.pop('error', "Mandatory Fields", "Please fill all the mandatory fields manually.");														
														return;
													}													
												
												}
													
											if (data.httpStatusCode == 404) {
												$scope.uiMessage = data.uiMessage;
												toaster.pop('error', item.routingLabel + " Format Valid", $scope.uiMessage);
											   
												return;
											}
										});
										
									}else {
											if (key == ($scope.bankExtras.length - 1) && !alertFlag) {

												// clear all address - Delete remittance if there is any 
												var indexes = [];
												angular.forEach(WfModel.supplier.addresses, function (address, key) {
													var typeKey = address.addressTypes.indexOf('REMITTANCE');
													if (typeKey != -1) {

														if (address.addressTypes.length == 1) {
															indexes.push(key);
														}

														if (address.addressTypes.length > 1) {
															address.addressTypes.splice(typeKey, 1);
														}
													}
												});
												angular.forEach(indexes, function (value, key) {
													WfModel.supplier.addresses.splice(value, 1);
												});
                                                WfModel.supplier.banks = [];
												angular.forEach($scope.bankExtras, function (value, key) {
																										
													var obj = {
															partyAccountName: value.bankAccountName,
															partyAccountNameAlt: null,
															partyBankInfo: {
																//institutionName: value.bankInstitutionName,
																bankNameAlt: value.institution_name_alt,
																branchNameAlt: value.branch_information_alt ,
																bankCountryCode: value.bankCountryCode,
																bankCountryName: value.bankCountryName,
																bankLocalRoutingNumber: value.abaRouting,
																accountNumber: value.bankAccountNumber,
																accountCurrencyId: value.bankCurrency,
																iban: value.iban,
																swift: value.swift,
																isPrimary: value.primary,
																remittanceEmailAddress: value.remittance,
																addresses: [],
																//branchInformation: value.bankBranchInformation,
																branchName: value.branch_information,
																bankAddress: {
																	"countryId": value.bankCountryCode,
																	"stateId": value.country_subdivision,
																	"stateName": null,
																	"cityName": value.town_name,
																	"provinceName": value.bankStateName,
																	"postalCode": value.zip_code,
																	"addressLine1": value.address1,
																	"addressLine2": value.address2,
																	"addressLine3": value.address3,
																	"addressLine4": value.address4,
																	"poBoxNumber": value.POBnumber
																},
																bankName: value.institution_name
																		//bankName: 'BANK OF AMERICA N.A.'
															},
															useFurtherCreditTo: value.bankCreditDetails,
															furtherCreditTo: {
																bankName: value.bankCreditName,
																accountNumber: value.bankCreditNumber,
																beneficiaryName: value.bankCreditBenName
															}
													};
													
													debugger;
													
																										
													angular.forEach(value.associateWithAddress, function (address, key) {
																	if (address.selected) {
																		obj.partyBankInfo.addresses.push(address.internalId);
																	}
																});
													WfModel.supplier.banks.push(obj);
												});
                                                
                                                console.log("WfModel.supplier.banks_error::", WfModel.supplier.banks);
                                                console.log("WfModel::", WfModel);
                                                console.log("WfModel.supplier.banks_error::" + JSON.stringify(WfModel.supplier.banks));
                                                saveWorkflow(redirect);
											}
                                    }



                                } else {
                                    alertFlag = true;
                                    $scope.loader = false;
                                    item.localRoutingValidation = false;
                                    toaster.pop('error', item.routingLabel + "Format is not Valid", data.statusMessage);
                                    return;
                                }

                            });
                        } else {
                            alertFlag = true;
                            $scope.loader = false;
                            item.acFormatValidation = false;
                            toaster.pop('error', "Account Number Format is not valid", data.statusMessage);
                            return;
                        }
                    });

                }
            });



        }


    }

    var saveWorkflow = function (redirect) {
        $scope.loader = true;
        //$scope.localRouting(item);	
        WorkFlow.setVariablesV2(WfModel).then(function (data) {
            $scope.loader = false;
            $rootScope.supplierProfileBankDone = true;
            if (redirect) {
                $state.go('supplierProfileContacts');
            }
            toaster.pop('success', "Saved successfully");
        }, function (data) {
            $scope.loader = false;
            toaster.pop('error', "Workflow Api failed");
        });
    }


    //abaNumberRoute
    $scope.abaNumberRoute = function (item) {
        $scope.loader = true;
        var abanumber = item.abaRouting;
        var aba_number_country = $scope.CountryCode;
        //console.log(abanumber);


        supplier.abaNumberRouting(abanumber, aba_number_country).then(function (data) {
            toaster.pop('success', "ABA Routing Number Validation", "ABA Routing Number is valid");
            $scope.loader = false;
            console.log(aba_number_country);
            if (data.data == "true") {
                $scope.abaNumberRouteValidation = true;
                toaster.pop('success', "ABA Routing Number Validation", "ABA Routing Number is valid")
            }
            // else{
            // 	$scope.loader=false;
            // 	$scope.abaNumberRouteValidation=false;
            // 	toaster.pop('error', "aba Number Route Validation", "aba Number Route is not valid")
            // } 

        }, function (data) {
            if (data.httpStatusCode == 404) {
                $scope.uiMessage = data.uiMessage;
                toaster.pop('info', "ABA Routing Number Validation", $scope.uiMessage);
                $scope.loader = false;
            }
            //toaster.pop('error', "aba Number Route Validation", "aba Number Route is not valid");
            //toaster.pop('error', "aba Number Route Validation", " aba Number Route API not responding")
        });
    }

    //IBAN Validation
    $scope.ibanAccount = function (item) {
        $scope.loader = true;
        var bbanNumber = item.iban;
        console.log(bbanNumber);

        supplier.IbanAccountValidation(bbanNumber).then(function (data) {
            $scope.loader = false;
            toaster.pop('success', "IBAN Number  Validation", "IBAN Number is  valid")
            /*if(data.data=="true"){
             $scope.IBANValidation=true;
             //toaster.pop('success', "IBAN Number  Validation", "IBAN Number is  valid")
             }
             else{
             $scope.loader=false;
             $scope.IBANValidation=false;
             //toaster.pop('error', "IBAN Number  Validation", "IBAN Number is not valid")
             }*/

        }, function (data) {
            $scope.loader = false;
            toaster.pop('error', "IBAN Number Validation", "IBAN Number not valid")
        });
    }


    //swiftValidation Validation
    $scope.swiftValidation = function (item) {
        $scope.loader = true;
        var swift = item.swift;
        console.log(swift);

        supplier.swiftValidation(swift).then(function (data) {
            $scope.loader = false;
            toaster.pop('success', "SWIFT/BIC Number  Validation", "IBAN Number is  valid")
            /*if(data.data=="true"){
             $scope.swiftValidation=true;
             //toaster.pop('success', "IBAN Number  Validation", "IBAN Number is  valid")
             }
             else{
             $scope.loader=false;
             $scope.swiftValidation=false;
             //toaster.pop('error', "IBAN Number  Validation", "IBAN Number is not valid")
             }*/

        }, function (data) {
            $scope.loader = false;
            toaster.pop('error', "SWIFT/BIC Number  Validation", " IBAN Number not valid")
        });
    }

    //Account No. Validation
    /*$scope.acNumberFormat=function(){
     $scope.loader=true;
     var acnumber = $scope.supplierInfo.acNumberValidate;
     var acno_format_country = $scope.CountryCode;
     console.log(acnumber);
     console.log(acno_format_country);
     
     
     supplier.AccountNumberFormat(acnumber,acno_format_country).then(function(data) {				
     //toaster.pop('success', "Account Number Validation", "Account Number Format  is valid");
     $scope.loader=false;
     console.log(data.statusMessage);
     if(data.data=="true"){
     $scope.acFormatValidation=true;
     toaster.pop('success', "Account Number Validation", data.statusMessage)
     }
     else{
     $scope.loader=false;
     $scope.acFormatValidation=false;
     toaster.pop('error', "Account Number Format is not valid", data.statusMessage)
     }
     
     });
     }*/

    //LOCALROUTING_FORMAT_VALIDATION
    $scope.localRouting = function (item) {
        //$scope.loader=true;
        var localformat = item.abaRouting;
        var local_routing_country = $scope.CountryCode;
        var aba_number_country = $scope.CountryCode;

        supplier.LocalRoutingFormat(localformat, local_routing_country).then(function (data) {
            //toaster.pop('success', "Local Routing Format Validation", "Local Routing Format is valid");
            //$scope.loader=false;
            console.log(data.data);
            if (data.data == "true") {
                $scope.localRoutingValidation = true;
                //toaster.pop('success', "Local Routing Format Validation", data.statusMessage)
                // SWIFT call on rule engine success
                supplier.abaNumberRouting(localformat, aba_number_country).then(function (data) {
                    //$scope.loader=false;

                    if (data) {
                        $scope.localRoutingValidation = true;
                        supplier.getBankName(localformat, aba_number_country).then(function (data) {
                            item.bankName = data.national_ids[0].institution_name;
                        }, function (data) {
                            //$scope.loader = false;
                        });

                        //$scope.loader = false;		
                    }
                }, function (data) {
                    if (data.httpStatusCode == 404) {
                        $scope.uiMessage = data.uiMessage;
                        return;
                        //toaster.pop('info',$scope.routingLabel+" Format Valid", $scope.uiMessage);
                        //$scope.loader=false;
                    }
                });
            } else {
                $scope.loader = false;
                $scope.localRoutingValidation = false;
                //toaster.pop('error', $scope.routingLabel+"Format is not Valid", data.statusMessage)
            }

        });
    }


    $scope.getStateListForAddressCountry = function (item) {
		item.stateLabel = 'State';                    
        item.stateList = '';		
        angular.forEach($scope.chooseCountries, function (value, key) {
            if (value.id == item.addressCountryCode) {
                supplier.getStatesList(value.code).then(function (data) {
                    item.stateLabel = data[0].authorityName;                    
                    item.stateList = data[0].subdivisions;
                }, function () {
                    toaster.pop('error', "State", "server not responding");
                });
            }
        });


    }
	
    $scope.getStateListForBankCountry = function (item, stateId) {
		item.stateBankLabel = 'State';                    
        item.stateBankList = '';
		
        angular.forEach($scope.chooseCountries, function (value, key) {
            if (value.id == item.country_name) {
                supplier.getStatesList(value.code).then(function (data) {
                    item.stateBankLabel = data[0].authorityName;                    
                    item.stateBankList = data[0].subdivisions;
					if(stateId){
						debugger;
						item.country_subdivision= stateId;
					}
                }, function () {
                    toaster.pop('error', "State", "server not responding");
                });
            }
        });


    }

    $scope.bankRuleUI = function (item) {
		item.showForm = false;
		item.failingCaseTrue = false;

        var ruleObj = {
            "request": {
                "isElectronicBanking": ($scope.notElectronic) ? ($scope.notElectronic) : true,
                "erpIds": (WfModel.subscription) ? WfModel.subscription.erpId : [],
                "banks": [
                    {
                        "bankCountry": item.bankCountryCode,
                        "isUseFurtherCreditTo": (item.bankCreditDetails) ? (item.bankCreditDetails) : false,
                        "id": "123"
                    }
                ]
            }
        }
        supplier.getBankUIRule(ruleObj).then(function (data) {
            item.bankRule = data;			
        }, function () {
            toaster.pop('error', "Bank Rule", "server not responding");
        });

        // reset IBAN and AC number on change
        // $scope.supplierInfo.iban = undefined;
        // $scope.supplierInfo.maskedAccountNumber = undefined;		

    }

    // Get State List
    $scope.getStates = function (code) {
        supplier.getCountryById(code).then(function (data) {
            $scope.CountryCode = data.code
        })
        supplier.getStatesList($scope.CountryCode).then(function (data) {
            $scope.stateList = data.subdivisions;
            $scope.loader = false;

        }, function () {
            $scope.loader = false;
            toaster.pop('error', "State list", "server not responding");
        });
    }

    $scope.showRemittanceOnly = function (item) {

        //console.log(item.addressTypes)
        // Need to confirm
        //debugger;
        if (item.addressTypes.indexOf('REMITTANCE') == -1) {
            return item;
        }

        if (item.addressTypes.indexOf('REMITTANCE') != -1 && item.addressTypes.length > 1) {
            return item;
        }
    }

    $scope.currencyChange = function (item) {
        console.log(item);
    }

    supplier.getCountryList().then(function (data) {
        $scope.chooseCountries = data;
		supplier.getCurrencyList().then(function (currencyData) {
		$scope.currencyList = currencyData;
	

				WorkFlow.getVariablesV2().then(function (workflowData) {

					WfModel = workflowData.data;
					$scope.loader = false;
					if (WfModel.supplier.canReceiveFundsElectronically == null) {
						$scope.notElectronic = false;
					} else {
						$scope.notElectronic = !(WfModel.supplier.canReceiveFundsElectronically);
					}

					$scope.bankExtras[0]['bankCreditDetails'] = false; 
					// if(WfModel.supplier.banks.length <= 0){
					$scope.bankExtras[0]['bankCountryCode'] = parseInt(WfModel.supplier.countryId);
					if(WfModel.supplier.banks){
						if(WfModel.supplier.banks.length==0) {
							$scope.bankExtras[0]['primary'] = true;					
						}
					}
					$scope.bankExtras[0].failCounter = 0;	
				   
					
					// }				

					$scope.tempAddressArray = [];
					angular.forEach(WfModel.supplier.addresses, function (value, key) {
						var idArray = $filter('filter')($scope.chooseCountries, {'id': value.location.countryId});
						console.log(idArray[0].name);
						value.location.countryName = '';
						if (idArray[0].name) {
							value.location.countryName = idArray[0].name;
						}
						if (value.addressTypes.indexOf("ORDER_FULLFILLING") != -1) {
							//$scope.add1 = value.location.addressLine1;
							$scope.tempAddressArray.push(value);
						}
					});

					$scope.associateWithAddress = $scope.tempAddressArray;
					$scope.bankExtras[0]['associateWithAddress'] = angular.copy($scope.associateWithAddress);
					$scope.addresses = WfModel.supplier.addresses;



					//$scope.bankExtras = [];		
					angular.forEach(WfModel.supplier.banks, function (bank, key) {
						$scope.acFormatValidation = true;

						$scope.bankCountry = parseInt(bank.partyBankInfo.bankAddress.countryId);

						var obj = {
							bankAccountName: bank.partyAccountName,
							bankCountryCode: $scope.bankCountry,
							abaRouting: bank.partyBankInfo.bankLocalRoutingNumber,
							bankAccountNumber: bank.partyBankInfo.accountNumber,
							maskedAccountNumber: (bank.partyBankInfo.accountNumber) ? bank.partyBankInfo.accountNumber.replace(/\d(?=\d{4})/g, "*") : '',
							bankCurrency: parseInt(bank.partyBankInfo.accountCurrencyId),
							iban: bank.partyBankInfo.iban,
							swift: bank.partyBankInfo.iban,
							primary: bank.partyBankInfo.isPrimary,
							remittance: bank.partyBankInfo.remittanceEmailAddress,
							addresses: bank.partyBankInfo.addresses,
							bankCreditDetails: (bank.useFurtherCreditTo)?bank.useFurtherCreditTo:false,
							bankCreditName: (bank.furtherCreditTo)?bank.furtherCreditTo.bankName:null,
							bankCreditNumber: (bank.furtherCreditTo)?bank.furtherCreditTo.accountNumber:null,
							bankCreditBenName: (bank.furtherCreditTo)?bank.furtherCreditTo.beneficiaryName:null,
							bankName: bank.partyBankInfo.bankName,
							associateWithAddress: angular.copy($scope.associateWithAddress),
							branch_information: bank.partyBankInfo.branchName,
							branch_information_alt: bank.partyBankInfo.branchNameAlt,
							institution_name_alt: bank.partyBankInfo.bankNameAlt,
							institution_name: bank.partyBankInfo.bankName,
							POBnumber: bank.partyBankInfo.bankAddress.poBoxNumber,
							address1: bank.partyBankInfo.bankAddress.addressLine1,
							town_name: bank.partyBankInfo.bankAddress.cityName,
							country_name: parseInt(bank.partyBankInfo.bankAddress.countryId),
							country_subdivision: parseInt(bank.partyBankInfo.bankAddress.stateId),
							zip_code: bank.partyBankInfo.bankAddress.postalCode,
							
							
						};
						debugger;
						obj.failCounter = 0;
						
						
					

						
						angular.forEach(obj.associateWithAddress, function (value, key1) {
							if (bank.partyBankInfo.addresses.indexOf(value.internalId) != -1) {
								value.selected = true;
							}
						});
						//$scope.bankExtras.push(obj);
						if (key == 0) {
							$scope.bankExtras[0] = obj;
						} else {
							$scope.bankExtras.push(obj);
							$scope.bankRuleUI($scope.bankExtras[key]);
							$scope.setRoutingLabel($scope.bankExtras[key]);
							$scope.setCurrency($scope.bankExtras[key]);
						}
						
						$scope.getStateListForBankCountry(obj, parseInt(bank.partyBankInfo.bankAddress.stateId))

					});

					$scope.bankRuleUI($scope.bankExtras[0]);
					$scope.setRoutingLabel($scope.bankExtras[0]);
					$scope.setCurrency($scope.bankExtras[0]);

					angular.forEach(WfModel.supplier.addresses, function (value, key) {

						if (value.addressTypes.indexOf('REMITTANCE') != -1) {
							if (value.addressTypes.length > 1) {
								var obj = {
									id: value.internalId,
									associateWithAddress: angular.copy($scope.associateWithAddress)
								};
								obj.selectedAddress = value.internalId;
								$scope.bankAddresses.push(obj);
							} else {

								var obj = {
									address1: value.location.addressLine1,
									address2: value.location.addressLine2,
									address3: value.location.addressLine3,
									address4: value.location.addressLine4,
									city: value.location.cityName,
									addressCountryCode: parseInt(value.location.countryId),
									postalCode: value.location.postalCode,
									stateId: parseInt(value.location.stateId),
									stateName: value.location.stateName,
									types: value.addressTypes,
									id: value.internalId,
									associateWithAddress: angular.copy($scope.associateWithAddress)
								};

								$scope.bankAddresses.push(obj);
								$scope.getStateListForAddressCountry(obj);
							}

							angular.forEach(obj.associateWithAddress, function (valueAssoc, keyAssoc) {
								if (value.boundAddresses.indexOf(valueAssoc.internalId) != -1) {
									valueAssoc.selected = true;
								}
							});

						}


					});

					if ($scope.bankAddresses.length < 1) {
						var obj = {};
						obj.associateWithAddress = angular.copy($scope.associateWithAddress);
						$scope.bankAddresses.push(obj);
					}
					//$scope.bankAddresses.push({});
				}, function (data) {
					$scope.loader = false;
				})
		
		}, function () {
			toaster.pop('error', "Currency list", "server not responding");
		});
    }, function () {
        toaster.pop('error', "Country list", "server not responding");
    });



    $scope.maskCredit = function (item) {

        if (item.bankAccountNumber.indexOf('*') == -1)
        {
            item.unmaskedBankCreditNumber = item.bankAccountNumber;
        }

        item.bankCreditNumber = bankCreditNumber.replace(/\d(?=\d{4})/g, "*");
    }


    $scope.bankValidation = true;
    $scope.bankAccountCheck = function (item, country) {
        var acnumber = item.maskedAccountNumber;
        var acno_format_country = $scope.CountryCode;
        if (item.maskedAccountNumber.indexOf('*') == -1)
        {
            item.bankAccountNumber = item.maskedAccountNumber;
        }

        item.maskedAccountNumber = item.maskedAccountNumber.replace(/\d(?=\d{4})/g, "*");

        //Account No. Validation
        /*
         supplier.AccountNumberFormat(acnumber,acno_format_country).then(function(data) {								
         $scope.loader=false;
         console.log(data.statusMessage);
         if(data.data=="true"){
         item.acFormatValidation=true;
         $scope.acFormatValidation=true;
         //toaster.pop('success', "Account Number Validation", data.statusMessage)
         }
         else{
         $scope.loader=false;
         item.acFormatValidation=false;
         $scope.acFormatValidation = false;
         toaster.pop('error', "Account Number Format is not valid", data.statusMessage)
         }
         }); */


    }

    // Branch Information
    $scope.branchInformation = [];

    $scope.branchInfo = function (item) {

        if (item.bankCountryCode == null || item.abaRouting == null) {
            toaster.pop('error', "Invalid fields", "Please fill the mandatory fields");
            return;
        }

        console.log("item::", item);
        console.log("entered");
        console.log(item);
        //supplier.getBranchInfo(item);
        supplier.getBranchInfo
                (
                        item.abaRouting,
                        $scope.CountryCode
                        )
                .then(function (data) {
                    $scope.branchInformation.push(data);
                    console.log("$scope.branchInformation::", $scope.branchInformation);
                }, function (error) {
                    console.log("$scope.branchInformation::", $scope.branchInformation);
                });


    };





    /* -------- Branch Info code END -----------*/








    $scope.prevForBusinessInfo = function () {
        $state.go('supplierProfileAddress');
    }


});
