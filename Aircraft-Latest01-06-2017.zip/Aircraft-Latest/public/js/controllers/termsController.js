
app.controller('termsController', function($scope, $filter, $http, $rootScope,$state,Auth,$timeout,toaster,constants,
		$cookies,$cookieStore,$location, WorkFlow, supplier) {
	// Auth.getRoles().then(function(roles){
	//     // if (Auth.isRoleExists(roles.authorities , 'ADD_SUPPLIER')){
	// 	   //  	//$scope.inviteEnabled = true;
	//     // 	$cookieStore.put("Persona","Sourcing");
	//     // }else{
	//     // 	$cookieStore.put("Persona","Supplier");
	//     // }
	//     $cookieStore.put("Persona",roles.roles[0].name);
	// 	$cookieStore.put("uId", roles.id);
	// 	$scope.persona = $cookieStore.get("Persona");
	// }, function() {
	// 	toaster.pop('error', "Role list", "server not responding");
	// });	
	$scope.accept = function(){
		supplier.termsApprove().then(function(data) {
			$state.go('supplierHome'); 
			
			}, function() {
			toaster.pop('error', "Approve api", "server not responding");
		});
		
	}
	
});


app.controller('getermsController', function($scope, $filter, $http, $rootScope,$state,Auth,$timeout,toaster,constants,
		$cookies,$cookieStore,$location, WorkFlow, supplier) {
		// Auth.getRoles().then(function(roles){
		//     if (Auth.isRoleExists(roles.authorities , 'ADD_SUPPLIER')){
		// 	    	//$scope.inviteEnabled = true;
		//     	$cookieStore.put("Persona","Sourcing");
		//     }else{
		//     	$cookieStore.put("Persona","Supplier");
		//     }
		//     $cookieStore.put("Persona",roles.roles[0].name);
		// 	$cookieStore.put("uId", roles.id);
		// 	$scope.persona = $cookieStore.get("Persona");
		// }, function() {
		// 	toaster.pop('error', "Role list", "server not responding");
		// });	
		$scope.accept = function(){
			supplier.termsApprove().then(function(data) {
				$state.go('homePage'); 
				
				}, function() {
				toaster.pop('error', "Approve api", "server not responding");
			});
			
		}
	
});