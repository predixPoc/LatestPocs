var responseJsonDataForFlight=[{"elevatorPosition":-7.36,"peakValleyIndicator":" ","flightId":101,"flapPosition":15.15,"fleetId":1,"verticalAcceleration":1.0,"rollAcceleration":-0.87,"leftAileronPosition":0.36,"startTime":"22:49","retardantDoorOpen":1.00,"timestamp":"49:32.2","pressureAltitude":1047.27,"strainGauge3":-14.81,"retardantTankFloat":-3.68,"strainGauge2":-11.84,"strainGauge1":-2.96,"triggerChannel":" ","recordType":"PE","airspeed":54.2,"gearUpAndLocked":0.00,"armRetardantTankDoor":0.00,"strainGauge9":" ","strainGauge8":8.88,"beaconStartStopRecording":0.00,"strainGauge7":11.84,"strainGauge6":-5.92,"strainGauge5":-5.92,"startDate":"6-26-2004","elapsedTime":14.18,"strainGauge4":0.0}
,{"elevatorPosition":-7.31,"peakValleyIndicator":" ","flightId":101,"flapPosition":15.14,"fleetId":2,"verticalAcceleration":1.0,"rollAcceleration":-0.88,"leftAileronPosition":0.36,"startTime":"22:49","retardantDoorOpen":1.00,"timestamp":"49:47.2","pressureAltitude":1047.27,"strainGauge3":-14.81,"retardantTankFloat":-5.26,"strainGauge2":-5.92,"strainGauge1":-5.92,"triggerChannel":" ","recordType":"PE","airspeed":" ","gearUpAndLocked":0.00,"armRetardantTankDoor":0.00,"strainGauge9":" ","strainGauge8":11.84,"beaconStartStopRecording":0.00,"strainGauge7":5.92,"strainGauge6":-8.88,"strainGauge5":-8.88,"startDate":"6-26-2004","elapsedTime":29.18,"strainGauge4":-5.92}
,{"elevatorPosition":-7.31,"peakValleyIndicator":" ","flightId":101,"flapPosition":0.0,"fleetId":3,"verticalAcceleration":1.01,"rollAcceleration":-0.89,"leftAileronPosition":0.33,"startTime":"22:49","retardantDoorOpen":1.00,"timestamp":"50:02.2","pressureAltitude":992.58,"strainGauge3":-17.77,"retardantTankFloat":-2.11,"strainGauge2":-2.96,"strainGauge1":-8.88,"triggerChannel":" ","recordType":"PE","airspeed":54.2,"gearUpAndLocked":0.00,"armRetardantTankDoor":0.00,"strainGauge9":" ","strainGauge8":11.84,"beaconStartStopRecording":0.00,"strainGauge7":11.84,"strainGauge6":-8.88,"strainGauge5":-8.88,"startDate":"6-26-2004","elapsedTime":44.18,"strainGauge4":-8.88}];

alert(JSON.stringify(responseJsonDataForFlight));

var myArrayNew;
$(document).ready(function() {
	var flightDataDataTable;
	
		//$(".loadingChart5").css("visibility", "visible");
	  myArrayNew = [
                { "sTitle": "Flight Id", "mData": "flightId" },
				{ "sTitle": "Elapsed Time ", "mData": "elapsedTime" },
				{ "sTitle": "Record Type", "mData": "recordType" },
                { "sTitle": "Air Speed", "mData": "airspeed" },
				{ "sTitle": "Pressure Altitude", "mData": "pressureAltitude" },
				 { "sTitle": "Vertical Acceleration", "mData": "verticalAcceleration" },
                { "sTitle": "Roll Acceleration ", "mData": "rollAcceleration" },
				{ "sTitle": "Strain Gauge 1", "mData": "strainGauge1" },
				{ "sTitle": "Strain Gauge 2", "mData": "strainGauge2" },
				 { "sTitle": "Strain Gauge 3", "mData": "strainGauge3" },
				 { "sTitle": "Strain Gauge 4", "mData": "strainGauge4" },
				  { "sTitle": "Strain Gauge 5", "mData": "strainGauge5" },
				  { "sTitle": "Strain Gauge 6", "mData": "strainGauge6" },
				   { "sTitle": "Strain Gauge 7", "mData": "strainGauge7" },
				   { "sTitle": "Strain Gauge 8", "mData": "strainGauge8" },
				     { "sTitle": "Strain Gauge 9", "mData": "strainGauge9" },				
                { "sTitle": "Elevator Position", "mData": "elevatorPosition" },
                { "sTitle": "Peak Valley Indicator ", "mData": "peakValleyIndicator" },
				 { "sTitle": "Flap Position", "mData": "flapPosition" },
                { "sTitle": "Fleet Id", "mData": "fleetId" },               
				 { "sTitle": "Left Aileron Position", "mData": "leftAileronPosition" },
                { "sTitle": "Retardant Door Open", "mData": "retardantDoorOpen" },
                { "sTitle": "Timestamp", "mData": "timestamp" },
                { "sTitle": "Retardant Tank Float", "mData": "retardantTankFloat" },
                { "sTitle": "Trigger Channel", "mData": "triggerChannel" },                
                { "sTitle": "Gear Up And Locked ", "mData": "gearUpAndLocked" },
				 { "sTitle": "Arm Retardant Tank Door", "mData": "armRetardantTankDoor" },          
                { "sTitle": "Beacon Start Stop Recording", "mData": "beaconStartStopRecording" }
                           
            ]; 
			
	getFlightData();
	
	



function getFlightData(){
	//var flightIdUrl="https://aircraft-svcrakesh1.run.aws-usw02-pr.ice.predix.io/getAllFlightsData";
	//var flightIdUrl = "https://aircraft-svcrakesh1.run.aws-usw02-pr.ice.predix.io/view/getFlightDetailsWithDynamicfilter2/101/PE/''/0/2000";
	//$.ajax({
			//url:flightIdUrl,
		//	type: "GET",
		//	headers : {
		//	'Content-Type' : 'application/json'
		//	},
		//	success: function(responseData) {
				
			//responseJsonDataForFlight=responseData;
			
			showDataTable(responseJsonDataForFlight);
			
			//$(".loadingChart5").css("visibility", "hidden");
	
  // },

  // error: function ( xhr, status, error) {
	//   $(".loadingChart5").css("visibility", "hidden");
   // console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
   // }
   // });	
}

function showDataTable(responseJsonDataForFlight){
	var ndx=0;
	flightDataDataTable=$('#invoicedataTable').dataTable({
				"aaData": responseJsonDataForFlight,
                  dom: 'lBfrtip',
				  "bFilter" : false, 
				  "bPaginate": true,
				 "lengthMenu": [10,25,50,100,500],
				  "scrollY": 200,
				"scrollX": true,
                 buttons: ['excel' , 'print','copyHtml5'],
                  "aoColumns":myArrayNew,
				  
			   
			   //"initComplete": function(settings){
					//$('#invoicedataTable thead th').each(function () {
					  // var $td = $(this);
					  // $td.attr('title', $td.text());
					//});

					/* Apply the tooltips */
					//$('#invoicedataTable thead th[title]').tooltip(
					//{
					  // "container": 'body'
					//}); 
							//var detail=data.poNumber;       
							//alert('detail'+detail);							
				//} 

               }).yadcf([
				
					{
					  			column_number: 1,
								filter_type: "range_number_slider"
					}
				
					
							
					]);   
					
				
					
			   
	

}

	
	
	
});