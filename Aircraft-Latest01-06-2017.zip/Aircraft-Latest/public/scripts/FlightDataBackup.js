var responseJsonDataForFlight;
var myArrayNew;
$(document).ready(function() {
	var flightDataDataTable;
	
		$(".loadingChart5").css("visibility", "visible");
	  myArrayNew = [
                { "sTitle": "Flight Id", "mData": "flightId" },
				{ "sTitle": "Elapsed Time ", "mData": "elapsedTime" },
				{ "sTitle": "Record Type", "mData": "recordType" },
                { "sTitle": "Air Speed", "mData": "airspeed" },
				{ "sTitle": "Pressure Altitude", "mData": "pressureAltitude" },
				 { "sTitle": "Vertical Acceleration", "mData": "verticalAcceleration" },
                { "sTitle": "Roll Acceleration ", "mData": "rollAcceleration" },
				{ "sTitle": "Strain Gauge 1", "mData": "strainGauge1" },
				{ "sTitle": "Strain Gauge 2", "mData": "strainGauge2" },
				 { "sTitle": "Strain Gauge 3", "mData": "strainGauge3" },
				 { "sTitle": "Strain Gauge 4", "mData": "strainGauge4" },
				  { "sTitle": "Strain Gauge 5", "mData": "strainGauge5" },
				  { "sTitle": "Strain Gauge 6", "mData": "strainGauge6" },
				   { "sTitle": "Strain Gauge 7", "mData": "strainGauge7" },
				   { "sTitle": "Strain Gauge 8", "mData": "strainGauge8" },
				     { "sTitle": "Strain Gauge 9", "mData": "strainGauge9" },				
                { "sTitle": "Elevator Position", "mData": "elevatorPosition" },
                { "sTitle": "Peak Valley Indicator ", "mData": "peakValleyIndicator" },
				 { "sTitle": "Flap Position", "mData": "flapPosition" },
                { "sTitle": "Fleet Id", "mData": "fleetId" },               
				 { "sTitle": "Left Aileron Position", "mData": "leftAileronPosition" },
                { "sTitle": "Retardant Door Open", "mData": "retardantDoorOpen" },
                { "sTitle": "Timestamp", "mData": "timestamp" },
                { "sTitle": "Retardant Tank Float", "mData": "retardantTankFloat" },
                { "sTitle": "Trigger Channel", "mData": "triggerChannel" },                
                { "sTitle": "Gear Up And Locked ", "mData": "gearUpAndLocked" },
				 { "sTitle": "Arm Retardant Tank Door", "mData": "armRetardantTankDoor" },          
                { "sTitle": "Beacon Start Stop Recording", "mData": "beaconStartStopRecording" }
                           
            ]; 
			
	getFlightData();
	
	



function getFlightData(){
	var flightIdUrl="https://aircraft-svcrakesh1.run.aws-usw02-pr.ice.predix.io/getAllFlightsData";
	//var flightIdUrl = "https://aircraft-svcrakesh1.run.aws-usw02-pr.ice.predix.io/view/getFlightDetailsWithDynamicfilter2/101/PE/''/0/2000";
	$.ajax({
			url:flightIdUrl,
			type: "GET",
			headers : {
			'Content-Type' : 'application/json'
			},
			success: function(responseData) {
				
			responseJsonDataForFlight=responseData;
			
			showDataTable(responseJsonDataForFlight);
			
			$(".loadingChart5").css("visibility", "hidden");
	
   },

   error: function ( xhr, status, error) {
	   $(".loadingChart5").css("visibility", "hidden");
    console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
    }
    });	
}

function showDataTable(responseJsonDataForFlight){
	var ndx=0;
	flightDataDataTable=$('#invoicedataTable').dataTable({
				"aaData": responseJsonDataForFlight,
				//"bStateSave": true,
				// "bJQueryUI": true,
				//"bProcessing": true,
                  dom: 'lBfrtip',
				  //"bFilter" : false, 
				  "bPaginate": true,
				 "lengthMenu": [10,25,50,100,500],
				  "scrollY": 200,
				"scrollX": true,
                 buttons: ['excel' , 'print','copyHtml5'],
                  "aoColumns":myArrayNew,
               }).yadcf([{
				column_number: 0
				}, {
				column_number: 1,
				filter_type: "range_number_slider"
				}, {
				column_number: 2,
					filter_type: "auto_complete"
					}, {
					column_number: 3
					}, {
					column_number: 4
						}]); 
			   
	

}

	
	
	
});