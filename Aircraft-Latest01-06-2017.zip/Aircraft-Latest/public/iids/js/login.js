$(document).ready(function () {
	 $("#loginId").click(function(){
		 $("#invalid-login").hide();
		 if($("#username").val()=='techm' && $("#password").val()=='it2dt'){
			 window.location="MainPage.html";
		 }else{
			 $("#invalid-login").show();
			 $("#username").val('');
			 $("#password").val('');
		 }
		 
		 
	 });
	  
 });