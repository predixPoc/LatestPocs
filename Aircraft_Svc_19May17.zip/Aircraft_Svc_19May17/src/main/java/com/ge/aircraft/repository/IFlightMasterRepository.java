/*
 * Copyright (c) 2017 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */
 
package com.ge.aircraft.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.ge.aircraft.entity.FlightMaster;

/**
 * 
 * @author predix -
 */
public interface IFlightMasterRepository extends CrudRepository<FlightMaster, Long>,PagingAndSortingRepository<FlightMaster, Long>{
	
	String GET_FLIGHT_TIMESTAMP_BY_DATE_TIME = "select a.flightId as flightId,a.startTime as  startTime from FlightMaster a where a.startDate =? and a.startTime=?";

	String GET_FLIGHTS_IN_DATE_RANGE = "select a.flightId as flightId, a.startDate as startDate, a.startTime as startTime from FlightMaster a where a.startDate between ?1 and ?2 ";
	
	String GET_FLIGHTS_IN_DATE_RANGE2 = "select a.flightId as flightId, a.start_timestamp as startDateTime from FlightMaster a where a.start_timestamp between ?1 and ?2 ";
	
	List<FlightMaster> findByStartDate(String startdate);
	
	
	//@query
	List<FlightMaster> findByStartTime(String starttime);
	
	
	@Query(GET_FLIGHT_TIMESTAMP_BY_DATE_TIME)
	List<Object[]> findByStartTimeAndDate(String startDate,String startTime);
	
	
	//rakesh : 21-Apr-17 : start
	@Query(GET_FLIGHTS_IN_DATE_RANGE)
	List<Object[]> findFlightsInDateRange(String fromDate,String toDate);
	
	@Query(GET_FLIGHTS_IN_DATE_RANGE2)
	List<Object[]> findFlightsInDateRange2(Date fromDateTime,Date toDateTime);
	//rakesh : 21-Apr-17 : end

}
