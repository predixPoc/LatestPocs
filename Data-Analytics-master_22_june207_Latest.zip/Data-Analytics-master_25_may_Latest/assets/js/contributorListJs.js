 $(document).ready(function () {
	 
	 var queryParam = window.location.search.substring(1);
        var userName=queryParam.split("userName=");
        userType=queryParam.split("userType=")[1].trim();				
        encryptedUserName = userName[1].substring(0,userName[1].indexOf("&"));
	 
	 
	/*var predixurl="https://data-analytic-service-25thmay.run.aws-usw02-pr.ice.predix.io/data-analytic/getAllContributorList";
	
		     $.ajax({
		          url:predixurl,
                  type: "GET", //send it through GET method
                  success: function(responseData) {
                   /// alert(responseData.status);
					
						for (var i = 0; i < responseData.object.length; i++) {
					$('#sel1').append($('<option>', { 
						value: JSON.stringify(responseData.object[i].trim()),
						text : JSON.stringify(responseData.object[i].trim())
				}));
				}
					
					
					
					
     		     },
                 error: function ( xhr, status, error) {
				   console.log("Error while fetching Automation tracker data.");
	             }
		     });*/
			 
			 
   $("#contributorNameIdList").change(function () {	
   
   var projectNameList='';
	 var data=$(this).val();
	var predixurl="https://data-analytic-service-25thmay.run.aws-usw02-pr.ice.predix.io/data-analytic/getRewardDetailsForContriutor";
	
		     $.ajax({
		          url:predixurl+"/"+data,
                  type: "GET", //send it through GET method
                  success: function(responseData) {
                  
					
						for (var i = 0; i < responseData.length; i++) {
							if(i==0){
								$("#businessName").html(responseData[i].businessName);
								$("#contributorNameId").html(responseData[i].contributorName);
							}
							
							projectNameList=projectNameList+responseData[i].projectName+"<br>";
								
							
							
				
						}
					$("#projectnameId").html(projectNameList);
					
					
					
     		     },
                 error: function ( xhr, status, error) {
				   console.log("Error while fetching Automation tracker data.");
	             }
		     });

   });   
   
   
   
   
    $("#automationId").click(function(){
        window.location="index_home.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 
	 $("#contributorIdList").click(function(){
				window.location.href="contributorList.html?userName="+encryptedUserName+"&userType="+userType;
				
		 
	 });
	 
	 $("#workId").click(function(){
		window.location="index_home.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 $("#serviceId").click(function(){
		window.location="index_home.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 $("#homeId").click(function(){
		window.location="index_home.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 $("#teamId").click(function(){
		window.location="index_home.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 
	  $("#demographicsId").click(function(){
		window.location="index_home.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	  $("#contributorIdList").click(function(){
				window.location.href="contributorList.html?userName="+encryptedUserName+"&userType="+userType;
				
		 
	 });
   
   
   
   
   
   
   
   
		 
	 
 });