package com.ge.data.analytic.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ge.data.analytic.entity.AutomationTrackerData;

public interface AutomationTrackerRepo extends JpaRepository<AutomationTrackerData, Long>{
	
	String GET_DOWNLOAD_COUNT_BY_PROJECTNAME_AUTOMATION_NAME = "from AutomationTrackerData t where t.projectName =?1 and t.automationName=?2";
	//String GET_DOWNLOAD_COUNT_BY_PROJECTNAME_AUTOMATION_NAME = "from AutomationTrackerData t where t.projectName=:projectName and t.automationName=:automationName";
	
	@Override
	List<AutomationTrackerData> findAll();
	List<AutomationTrackerData> findByAutomationId(Long automationId);
	
	@Query(GET_DOWNLOAD_COUNT_BY_PROJECTNAME_AUTOMATION_NAME)
	List<AutomationTrackerData> getDownloadCount(String projectName, String automationName);

}
