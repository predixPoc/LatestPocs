package com.ge.data.analytic.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ge.data.analytic.entity.Reward;

@Repository
public interface RewardRepo extends JpaRepository<Reward, Long>{
	String GET_ALL_REWARD_NAME = "from Reward r where r.contributorName=?1";
	
	@Query(GET_ALL_REWARD_NAME)
	List<Reward> findRewardName(String contributorName);

}

