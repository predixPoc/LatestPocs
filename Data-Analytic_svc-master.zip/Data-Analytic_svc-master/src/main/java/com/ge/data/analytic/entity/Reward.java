package com.ge.data.analytic.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the REWARD database table.
 * 
 */

@Entity
@Table(name="REWARD")
@NamedQuery(name="Reward.findAll", query="SELECT r FROM Reward r")
public class Reward {
	@Id
	@SequenceGenerator(name="REWARD_REWARDID_GENERATOR", sequenceName="REWARD_SEQ1")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="REWARD_REWARDID_GENERATOR")
	@Column(name="REWARD_ID")
	private long rewardId;
	
	@Column(name="REWARD_NAME")
	private String rewardName;
	
	@Column(name="CONTRIBUTOR_NAME")
	private String contributorName;

	public long getRewardId() {
		return rewardId;
	}

	public void setRewardId(long rewardId) {
		this.rewardId = rewardId;
	}

	public String getRewardName() {
		return rewardName;
	}

	public void setRewardName(String rewardName) {
		this.rewardName = rewardName;
	}

	public String getContributorName() {
		return contributorName;
	}

	public void setContributorName(String contributorName) {
		this.contributorName = contributorName;
	}

	
    

}


