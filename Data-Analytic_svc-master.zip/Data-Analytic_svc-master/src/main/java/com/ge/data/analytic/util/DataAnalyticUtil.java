/*
 * Copyright (c) 2017 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */

package com.ge.data.analytic.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.ge.data.analytic.entity.AutomationTrackerData;
import com.ge.data.analytic.entity.ReuseData;

/**
 * 
 * @author predix -
 */
public class DataAnalyticUtil {
	
	/*public static void main(String args[]){
		 readExcelFile();
	}*/

	@SuppressWarnings("deprecation")
	public static List<AutomationTrackerData> readExcelFile(File file) {
		List<AutomationTrackerData> dataList = new ArrayList<AutomationTrackerData>();
		try {
			System.out.println("File Path : " + file);
            //String FILE_NAME="D:/GEGDC/BD470389/PREDIX_DOCS/Automation Template GEA_New.xlsx";
			//String FILE_NAME=filePath+"/Automation Template GEA_New.xlsx";
			FileInputStream excelFile = new FileInputStream(file);
			Workbook workbook = new XSSFWorkbook(excelFile);
			Sheet datatypeSheet = workbook.getSheetAt(0);
			Iterator<Row> iterator = datatypeSheet.iterator();
			

			while (iterator.hasNext()) {

				Row currentRow = iterator.next();
				Iterator<Cell> cellIterator = currentRow.iterator();
				AutomationTrackerData trackerData = new AutomationTrackerData();
				//System.out.println("Current Row : "+ currentRow.getRowNum());
                if(currentRow.getRowNum() > 0){
				while (cellIterator.hasNext()) {

					Cell currentCell = cellIterator.next();
					// getCellTypeEnum shown as deprecated for version 3.15
					// getCellTypeEnum ill be renamed to getCellType starting
					// from version 4.0
					/*String cellValue= "";
					if (currentCell.getCellTypeEnum() == CellType.STRING) {
						System.out.print(currentCell.getStringCellValue() + "--");
						System.out.println("String :" + currentCell.getColumnIndex());
						cellValue = currentCell.getStringCellValue();
					} else if (currentCell.getCellTypeEnum() == CellType.NUMERIC) {
						System.out.print(currentCell.getNumericCellValue() + "--");
						System.out.println("Int :"+ currentCell.getColumnIndex());
						cellValue = currentCell.getNumericCellValue();
					}*/
					if(currentCell.getColumnIndex() == 0){
						trackerData.setSerialNum((int)currentCell.getNumericCellValue());
						
					}else if(currentCell.getColumnIndex() == 1){
						trackerData.setBusinessName(currentCell.getStringCellValue());
						
					}else if(currentCell.getColumnIndex() == 2){
						trackerData.setProjectName(currentCell.getStringCellValue());
						
					}else if(currentCell.getColumnIndex() == 3){
						trackerData.setUploadedFileName(currentCell.getStringCellValue());
						
					}else if(currentCell.getColumnIndex() == 5){
						trackerData.setAutomationName(currentCell.getStringCellValue());
						
					}else if(currentCell.getColumnIndex() == 4){
						trackerData.setContactPerson(currentCell.getStringCellValue());
						
					}else if(currentCell.getColumnIndex() == 6){
						trackerData.setTechnology(currentCell.getStringCellValue());
						
					}else if(currentCell.getColumnIndex() == 7){
						trackerData.setVersion(currentCell.getStringCellValue());
						
					}else if(currentCell.getColumnIndex() == 8){
						trackerData.setEffortSaving(Double.toString(currentCell.getNumericCellValue()));
						
					}else if(currentCell.getColumnIndex() == 9){
						trackerData.setSavingToGE(Double.toString(currentCell.getNumericCellValue()));
						
					}else if(currentCell.getColumnIndex() == 10){
						trackerData.setReused(currentCell.getStringCellValue());
						
					}else if(currentCell.getColumnIndex() == 11){
						trackerData.setSummary(currentCell.getStringCellValue());
						
					}

				}
				System.out.println("Row "+ currentRow.getRowNum() + "completed");
				dataList.add(trackerData);
				//System.out.println(dataList.get(0).getIbuName());
               }

			}
			System.out.println(dataList.size() +" " +  dataList.get(0).getBusinessName());
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		return dataList;

	}
	
	
	@SuppressWarnings("deprecation")
	public static List<ReuseData> readExcelFileForReuse(File file) {
		List<ReuseData> dataList = new ArrayList<ReuseData>();
		try {
			System.out.println("File Path : " + file);
            //String FILE_NAME="D:/GEGDC/BD470389/PREDIX_DOCS/Automation Template GEA_New.xlsx";
			//String FILE_NAME=filePath+"/Automation Template GEA_New.xlsx";
			FileInputStream excelFile = new FileInputStream(file);
			Workbook workbook = new XSSFWorkbook(excelFile);
			Sheet datatypeSheet = workbook.getSheetAt(0);
			Iterator<Row> iterator = datatypeSheet.iterator();
			

			while (iterator.hasNext()) {

				Row currentRow = iterator.next();
				Iterator<Cell> cellIterator = currentRow.iterator();
				ReuseData reuseData = new ReuseData();
				//System.out.println("Current Row : "+ currentRow.getRowNum());
                if(currentRow.getRowNum() > 0){
				while (cellIterator.hasNext()) {

					Cell currentCell = cellIterator.next();
					// getCellTypeEnum shown as deprecated for version 3.15
					// getCellTypeEnum ill be renamed to getCellType starting
					// from version 4.0
					/*String cellValue= "";
					if (currentCell.getCellTypeEnum() == CellType.STRING) {
						System.out.print(currentCell.getStringCellValue() + "--");
						System.out.println("String :" + currentCell.getColumnIndex());
						cellValue = currentCell.getStringCellValue();
					} else if (currentCell.getCellTypeEnum() == CellType.NUMERIC) {
						System.out.print(currentCell.getNumericCellValue() + "--");
						System.out.println("Int :"+ currentCell.getColumnIndex());
						cellValue = currentCell.getNumericCellValue();
					}*/
					if(currentCell.getColumnIndex() == 0){
						reuseData.setSerialNum((int)currentCell.getNumericCellValue());
						
					}else if(currentCell.getColumnIndex() == 1){
						reuseData.setBusinessName(currentCell.getStringCellValue());
						
					}else if(currentCell.getColumnIndex() == 2){
						reuseData.setProjectName(currentCell.getStringCellValue());
						
					}else if(currentCell.getColumnIndex() == 3){
						reuseData.setUploadedFileName(currentCell.getStringCellValue());
						
					}else if(currentCell.getColumnIndex() == 4){
						reuseData.setReuseComponentName(currentCell.getStringCellValue());
						
					}else if(currentCell.getColumnIndex() == 5){
						reuseData.setContactPerson(currentCell.getStringCellValue());
						
					}else if(currentCell.getColumnIndex() == 6){
						reuseData.setTechnology(currentCell.getStringCellValue());
						
					}else if(currentCell.getColumnIndex() == 7){
						reuseData.setSavingToGE(Double.toString(currentCell.getNumericCellValue()));
						
					}else if(currentCell.getColumnIndex() == 8){
						reuseData.setReused(currentCell.getStringCellValue());
						
					}else if(currentCell.getColumnIndex() == 9){
						reuseData.setSummary(currentCell.getStringCellValue());
						
					}

				}
				System.out.println("Row "+ currentRow.getRowNum() + "completed");
				dataList.add(reuseData);
				//System.out.println(dataList.get(0).getIbuName());
               }

			}
			System.out.println(dataList.size() +" " +  dataList.get(0).getBusinessName());
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		return dataList;

	}
	
	
}
