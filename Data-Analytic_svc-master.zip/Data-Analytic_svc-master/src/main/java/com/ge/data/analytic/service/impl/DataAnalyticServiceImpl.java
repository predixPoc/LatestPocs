package com.ge.data.analytic.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ge.data.analytic.entity.AutomationTrackerData;
import com.ge.data.analytic.entity.ReuseData;
import com.ge.data.analytic.entity.Reward;
import com.ge.data.analytic.entity.UserData;
import com.ge.data.analytic.exception.DataAnalyticException;
import com.ge.data.analytic.repository.AutomationTrackerRepo;
import com.ge.data.analytic.repository.DownloadRepository;
import com.ge.data.analytic.repository.ReuseRepo;
import com.ge.data.analytic.repository.RewardRepo;
import com.ge.data.analytic.repository.UserDataRepository;
import com.ge.data.analytic.service.IDataAnalyticService;

@Component
public class DataAnalyticServiceImpl implements IDataAnalyticService {
	private static final Logger LOGGER = LoggerFactory
			.getLogger(DataAnalyticServiceImpl.class);
	
	
	@Autowired
	private UserDataRepository userRepo;
	
	@Autowired
	private AutomationTrackerRepo trackerRepo;
	
	@Autowired
	private ReuseRepo reuseRepo;
	
	@Autowired
	private RewardRepo rewardRepo;
	
	@Autowired
	private DownloadRepository downloadRepo;


	@Override
	public UserData createNewUser(UserData user)
			throws DataAnalyticException {
		UserData current;
		try {
			current = userRepo.save(user);
			LOGGER.debug("User created: " + current.getUserId());
		} catch (Exception e) {
			throw new DataAnalyticException("Error while creating User", e);
		}
		return current;
	}
	@Override
	public UserData findExistingUser(String userName) throws DataAnalyticException{
		UserData existUser;
		try {
			existUser = userRepo.findUser(userName);
		} catch (Exception e) {
			throw new DataAnalyticException("Error while creating User", e);
		}
		return existUser;
	}
	@Override
	public List<AutomationTrackerData> getAllTrackerData() throws DataAnalyticException{
		List<AutomationTrackerData> dataList= null;
		try {
			dataList = trackerRepo.findAll();
		} catch (Exception e) {
			throw new DataAnalyticException("Error while fetching Tracker Data", e);
		}
		return dataList;
	}
	
	@Override
	public List<ReuseData> getAllReuseData() throws DataAnalyticException{
		List<ReuseData> dataList= null;
		try {
			dataList = reuseRepo.findAll();
		} catch (Exception e) {
			throw new DataAnalyticException("Error while fetching Reuse Data", e);
		}
		return dataList;
	}
	
	@Override
    public List<AutomationTrackerData> saveAutomationDataList(List<AutomationTrackerData> dataList) throws DataAnalyticException {
	    List<AutomationTrackerData> currentSet;
	    try {
	      currentSet = trackerRepo.save(dataList);
	    } catch (Exception e) {
	      throw new DataAnalyticException("Error while saving Automation tracker Data", e);
	    }
	    return currentSet;
	}
	
	@Override
    public AutomationTrackerData saveAutomationData(AutomationTrackerData data) throws DataAnalyticException {
	    AutomationTrackerData currentSet;
	    try {
	      currentSet = trackerRepo.save(data);
	    } catch (Exception e) {
	      throw new DataAnalyticException("Error while saving Automation tracker Data", e);
	    }
	    return currentSet;
	}
	
	@Override
    public List<ReuseData> saveReuseDataList(List<ReuseData> dataList) throws DataAnalyticException {
	    List<ReuseData> currentSet;
	    try {
	      currentSet = reuseRepo.save(dataList);
	    } catch (Exception e) {
	      throw new DataAnalyticException("Error while saving Reuse Data", e);
	    }
	    return currentSet;
	}
	
	@Override
	public List<Reward> getRewardList(String contributorName) throws DataAnalyticException{
		List<Reward> dataList= null;
		try {
			dataList = rewardRepo.findRewardName(contributorName);
		} catch (Exception e) {
			throw new DataAnalyticException("Error while fetching Reward Data", e);
		}
		return dataList;
	}
	
	/*@Override
	public List<DownloadCounter> getAllDownloadData() throws DataAnalyticException{
		List<DownloadCounter> dataList= null;
		try {
			dataList = downloadRepo.findAll();
		} catch (Exception e) {
			throw new DataAnalyticException("Error while fetching DownloadCounter Data", e);
		}
		return dataList;
	}
	
	@Override
	public DownloadCounter updateDownloadConter() throws DataAnalyticException{
		DownloadCounter data= null;
		try {
			List<DownloadCounter> dataList = getAllDownloadData();
			int totalDownloadNum = dataList.get(0).getTotalNoOfDownload();
			dataList.get(0).setTotalNoOfDownload(totalDownloadNum+1);
			data = downloadRepo.save(dataList.get(0));
		} catch (Exception e) {
			throw new DataAnalyticException("Error while updating DownloadCounter Data", e);
		}
		return data;
	}*/
	
	@Override
	public List<AutomationTrackerData> getDownloadCount(Long automationId) throws DataAnalyticException{
		List<AutomationTrackerData> data= null;
		try {
			data = trackerRepo.findByAutomationId(automationId);
			System.out.println(data.size());
		} catch (Exception e) {
			e.printStackTrace();
			throw new DataAnalyticException("Error while fetching download count from Automation_Tracker table", e);
		}
		return data;
	}
	
	@Override
	public AutomationTrackerData updateDownloadCount(Long automationId) throws DataAnalyticException{
		AutomationTrackerData data= null;
		try {
			List<AutomationTrackerData> trackerData = getDownloadCount(automationId);
			Integer totalCount = trackerData.get(0).getTotalDownloadCount();
			if(totalCount == null){
				totalCount=0;
			}
			trackerData.get(0).setTotalDownloadCount(totalCount.intValue()+1);
			data = trackerRepo.save(trackerData.get(0));
		} catch (Exception e) {
			throw new DataAnalyticException("Error while updating Download Count data in Automation Tracker table.", e);
		}
		return data;
	}
}
