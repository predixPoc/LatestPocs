package com.ge.data.analytic.service;

import java.util.List;

import com.ge.data.analytic.entity.AutomationTrackerData;
import com.ge.data.analytic.entity.ReuseData;
import com.ge.data.analytic.entity.Reward;
import com.ge.data.analytic.entity.UserData;
import com.ge.data.analytic.exception.DataAnalyticException;


public interface IDataAnalyticService {

	UserData createNewUser(UserData user) throws DataAnalyticException;
	UserData findExistingUser(String userName) throws DataAnalyticException;
	
	List<AutomationTrackerData> getAllTrackerData() throws DataAnalyticException;
	List<AutomationTrackerData> saveAutomationDataList(List<AutomationTrackerData> automationDataList) throws DataAnalyticException;
	AutomationTrackerData saveAutomationData(AutomationTrackerData automationData) throws DataAnalyticException;
	List<AutomationTrackerData> getDownloadCount(Long automationId) throws DataAnalyticException;
	AutomationTrackerData updateDownloadCount(Long automationId) throws DataAnalyticException;
	
	List<ReuseData> getAllReuseData() throws DataAnalyticException;
	List<ReuseData> saveReuseDataList(List<ReuseData> automationDataList) throws DataAnalyticException;
	
	List<Reward> getRewardList(String contributorName) throws DataAnalyticException;
	
	//List<DownloadCounter> getAllDownloadData() throws DataAnalyticException;	
	//DownloadCounter updateDownloadConter() throws DataAnalyticException;
	
	
}
