package com.ge.data.analytic.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.ge.data.analytic.entity.AutomationTrackerData;
import com.ge.data.analytic.entity.ReuseData;
import com.ge.data.analytic.entity.Reward;
import com.ge.data.analytic.entity.UserData;
import com.ge.data.analytic.exception.DataAnalyticException;
import com.ge.data.analytic.service.IDataAnalyticService;
import com.ge.data.analytic.util.DataAnalyticUtil;
import com.ge.data.analytic.util.RestResponse;

@RestController
//@Controller
@RequestMapping(value = "/data-analytic")
@Configuration
@ComponentScan("com.ge.data.analytic.service")
public class DataAnalyticController {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(DataAnalyticController.class);
	@Autowired
	private IDataAnalyticService iDataAnalyticService;

	/**
	 * Test Method
	 */
	@RequestMapping(value = "/test", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody String test() {

		return "Testing";
	}

	/**
	 * This method is to save the new user details in USER_DATA table.
	 * 
	 * @param user -- Holds UserData object
	 * @return RestResponse
	 * @throws DataAnalyticException
	 */
	@RequestMapping(value = "/saveUserRegistration", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public RestResponse createNewUser(@RequestBody @Valid final UserData user)
			throws DataAnalyticException {
		LOGGER.info("Inside createNewUser method--");
		RestResponse response = new RestResponse();
		try {

			UserData checkUser = iDataAnalyticService.findExistingUser(user
					.getUserName().toUpperCase());

			if (null != checkUser) {
				response.setStatus(201);
				response.setMessage("Exists");
				// response.setObject(checkUser);
				return response;
			} else {
				//
				checkUser = new UserData();
				// TtUser user = new TtUser();
				checkUser.setUserName(user.getUserName().toUpperCase());
				// checkUser.setLastName(user.getLastName());
				checkUser.setEmail(user.getEmail());
				checkUser.setPassword(user.getPassword().toUpperCase());
				checkUser.setConfirmPassword(user.getConfirmPassword()
						.toUpperCase());
				checkUser.setPhone(user.getPhone());
				iDataAnalyticService.createNewUser(checkUser);
				response.setStatus(200);
				response.setMessage("Success");
				// response.setObject(checkUser);
				return response;
			}

		}

		catch (Exception ex) {
			System.out.println("DataAnalyticController.createNewUser()");
			response.setStatus(201);
			response.setMessage("Failure");
			return response;

		}

		// return status;

	}

	/**
	 * This method is to verify whether the logged in user is valid or not.
	 * 
	 * @param user -- Holds UserData object
	 * @return RestResponse
	 */
	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public RestResponse login(@RequestBody @Valid final UserData user) {
		RestResponse response = new RestResponse();
		try {

			UserData checkUser = iDataAnalyticService.findExistingUser(user
					.getUserName().toUpperCase());
			LOGGER.info("checkUser" + checkUser);

			if (null != checkUser) {

				if ((checkUser.getUserName().equalsIgnoreCase(user
						.getUserName()))
						&& (checkUser.getPassword().equalsIgnoreCase(user
								.getPassword()))) {
					response.setObject(checkUser);
					response.setStatus(200);
					response.setMessage("Success");
					LOGGER.info("checkUser" + response);

				} else {
					response.setMessage("Failure");
					response.setStatus(201);

				}
				LOGGER.info("Response: " + response);
			} else {
				response.setMessage("NotExist");
				response.setStatus(201);

			}

		}

		catch (Exception ex) {
			LOGGER.info("Data-Analytic.login()");
			response.setStatus(201);
			return response;

		}
		// return status;
		return response;

	}

	/**
	 * This method is to get all the automation Tracker records from the AUTOMATION_TRACKER table.
	 *  
	 * @return RestResponse
	 * @throws DataAnalyticException
	 */
	@RequestMapping(value = "/getAllTrackerData", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public RestResponse getAllTrackerData() throws DataAnalyticException {
		RestResponse response = new RestResponse();
		try {

			List<AutomationTrackerData> dataList = iDataAnalyticService
					.getAllTrackerData();

			if (CollectionUtils.isEmpty(dataList)) {
				response.setMessage("No Data Found");
				response.setStatus(200);
				return response;
			}
			response.setMessage("Success");
			response.setStatus(200);
			response.setObject(dataList);
			return response;
		} catch (Exception e) {
			e.printStackTrace();
			throw new DataAnalyticException("Error while fetching Automation Tracker data.");
		}

	}
	
	/**
	 * This method is to get all the reuse records from the REUSE table.
	 *  
	 * @return RestResponse
	 * @throws DataAnalyticException
	 */
	@RequestMapping(value = "/getReuseData", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public RestResponse getAllReuseData() throws DataAnalyticException {
		RestResponse response = new RestResponse();
		try {

			List<ReuseData> dataList = iDataAnalyticService
					.getAllReuseData();

			if (CollectionUtils.isEmpty(dataList)) {
				response.setMessage("No Data Found");
				response.setStatus(200);
				return response;
			}
			response.setMessage("Success");
			response.setStatus(200);
			response.setObject(dataList);
			return response;
		} catch (Exception e) {
			throw new DataAnalyticException("Error while fetching Reuse data.");
		}

	}
	
	/**
	 * This method is to extract the data from the uploaded excel file and insert those data in AUTOMATION_TRACKER table.
	 * 
	 * @param uploadfile -- Holds multipart uploaded file
	 * @return RestResponse
	 * @throws DataAnalyticException
	 */
	@RequestMapping(value = "/uploadExcelFile", method = RequestMethod.POST, headers=("content-type=multipart/*"))
	@ResponseBody
	public RestResponse uploadFile(
	      @RequestParam("uploadfile") MultipartFile uploadfile) throws DataAnalyticException {
		RestResponse response = new RestResponse();
		try {

			File convFile = new File(uploadfile.getOriginalFilename());
		    convFile.createNewFile(); 
		    FileOutputStream fos = new FileOutputStream(convFile); 
		    fos.write(uploadfile.getBytes());
		    fos.close(); 
            List<AutomationTrackerData> dataList = DataAnalyticUtil.readExcelFile(convFile);
            List<AutomationTrackerData> trackerDataList = iDataAnalyticService.saveAutomationDataList(dataList);
			if (CollectionUtils.isEmpty(trackerDataList)) {
				response.setMessage("No Data Found");
				response.setStatus(200);
				return response;
			}
			response.setMessage("Success");
			response.setStatus(200);
			response.setObject(trackerDataList);
			return response;

        } catch (IOException e) {
            e.printStackTrace();
        }

		return response;
		
	}
	
	/**
	 * This method is to save the uploaded PPT file name in the AUTOMATION_TRACKER table.
	 * 
	 * @param uploadfile -- Holds multipart uploaded file
	 * @return RestResponse
	 * @throws DataAnalyticException
	 */
	@RequestMapping(value = "/uploadFile", method = RequestMethod.POST, headers=("content-type=multipart/*"))
	@ResponseBody
	public RestResponse uploadPPTFile(
	      @RequestParam("uploadfile") MultipartFile uploadfile) throws DataAnalyticException {
		RestResponse response = new RestResponse();
		try {
			AutomationTrackerData updatedData = new AutomationTrackerData();
			String fileName = uploadfile.getOriginalFilename();
			String fileNameWithotExt = fileName.substring(0,fileName.lastIndexOf("."));
			String ext = fileName.substring(fileName.lastIndexOf(".")+1);
			if(ext.equalsIgnoreCase("pptx") || ext.equalsIgnoreCase("pps")){
				List<AutomationTrackerData> dataList = iDataAnalyticService
						.getAllTrackerData();
				if(dataList.size() > 0){
					for(int i=0; i< dataList.size(); i++){
						String uploadedFileName = dataList.get(i).getUploadedFileName();
						if(uploadedFileName == "" || uploadedFileName == null){
							dataList.get(i).setUploadedFileName(fileNameWithotExt);
							updatedData = dataList.get(i);
							break;
						}
					}
					 AutomationTrackerData trackerData = iDataAnalyticService.saveAutomationData(updatedData);
				}
			}
			response.setMessage("Success");
			response.setStatus(200);
			return response;

        } catch (Exception e) {
            e.printStackTrace();
        }

		return response;
		
	}
	
	/**
	 * This method is to extract the data from the uploaded excel file and insert those data in REUSE table.
	 * 
	 * @param uploadfile -- Holds multipart uploaded file
	 * @return RestResponse
	 * @throws DataAnalyticException
	 */
	@RequestMapping(value = "/uploadExcelFileForReuse", method = RequestMethod.POST, headers=("content-type=multipart/*"))
	@ResponseBody
	public RestResponse uploadFileForReuse(
	      @RequestParam("uploadfile") MultipartFile uploadfile) throws DataAnalyticException {
		RestResponse response = new RestResponse();
		try {

			File convFile = new File(uploadfile.getOriginalFilename());
		    convFile.createNewFile(); 
		    FileOutputStream fos = new FileOutputStream(convFile); 
		    fos.write(uploadfile.getBytes());
		    fos.close(); 
            List<ReuseData> dataList = DataAnalyticUtil.readExcelFileForReuse(convFile);
            List<ReuseData> reuseDataList = iDataAnalyticService.saveReuseDataList(dataList);
			if (CollectionUtils.isEmpty(reuseDataList)) {
				response.setMessage("No Data Found");
				response.setStatus(200);
				return response;
			}
			response.setMessage("Success");
			response.setStatus(200);
			response.setObject(reuseDataList);
			return response;

        } catch (IOException e) {
            e.printStackTrace();
        }

		return response;
		
	}
	
	/**
	 * This method is to get the Reward data from the REWARD table with the given contributor name.
	 * 
	 * @param contributorName -- Holds Contributor Name
	 * @return RestResponse
	 * @throws DataAnalyticException
	 */
	@RequestMapping(value = "/getRewardNameList/{contributorName}", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public RestResponse getRewardNameList(
			@PathVariable("contributorName") String contributorName) throws DataAnalyticException {
		LOGGER.info("Inside getRewardNameList()");
		List<Reward> rewardList = new ArrayList<Reward>();
		RestResponse response = new RestResponse();
		try {
			rewardList =  iDataAnalyticService.getRewardList(contributorName);
			if (CollectionUtils.isEmpty(rewardList)) {
				response.setMessage("No Data Found");
				response.setStatus(200);
				return response;
			}
			response.setMessage("Success");
			response.setStatus(200);
			response.setObject(rewardList);
			return response;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response;
	}
	
	/**
	 * This method is to get all the records form DOWNLOAD_COUNTER table.
	 * 
	 * @return
	 * @throws DataAnalyticException
	 */
	/*@RequestMapping(value = "/getDownloadData", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public RestResponse getAllDownloadData() throws DataAnalyticException {
		RestResponse response = new RestResponse();
		try {

			List<DownloadCounter> dataList = iDataAnalyticService
					.getAllDownloadData();

			if (CollectionUtils.isEmpty(dataList)) {
				response.setMessage("No Data Found");
				response.setStatus(200);
				return response;
			}
			response.setMessage("Success");
			response.setStatus(200);
			response.setObject(dataList);
			return response;
		} catch (Exception e) {
			throw new DataAnalyticException("Error while fetching DownloadCounter data.");
		}

	}*/
	
	/**
	 * This method is to update the TOTAL_DOWNLOAD column value by 1 in DOWNLOAD_COUNTER table.
	 * 
	 * @return RestResponse object
	 * @throws DataAnalyticException
	 */
	/*@RequestMapping(value = "/updateDownloadData", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public RestResponse updateDownloadData() throws DataAnalyticException {
		LOGGER.info("Inside updateDownloadData()");
		DownloadCounter data = new DownloadCounter();
		RestResponse response = new RestResponse();
		try {
			data =  iDataAnalyticService.updateDownloadConter();
			
			response.setMessage("Success");
			response.setStatus(200);
			response.setObject(data);
			return response;
		} catch (Exception e) {
			e.printStackTrace();
			response.setStatus(201);
			response.setMessage("Failure");
			return response;
		}
		
	}*/
	
    /**
     * This method is to get the value of DOWNLOAD_COUNT column from
	 * AUTOMATION_TRACKER table with the given project name and automation name.
	 * 
     * @param projectName -- Holds project Name
     * @param automationName -- Holds automation name
     * @return RestResponse
     * @throws DataAnalyticException
     */
	@RequestMapping(value = "/getDownloadCount/{automationId}", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public RestResponse getDownloadCount(@PathVariable("automationId") String automationId) throws DataAnalyticException {
		LOGGER.info("Inside getDownloadCount()");
		List<AutomationTrackerData> data = new ArrayList<AutomationTrackerData>();
		RestResponse response = new RestResponse();
		try {
			//LOGGER.info("Project Name :" + projectName + "Automation Name : "+ automationName);
			
			
			data =  iDataAnalyticService.getDownloadCount(Long.parseLong(automationId));
			LOGGER.info("@@@@@@@@@@@@@@@@@@@@@@@@" + data);
			if(data != null){
				response.setMessage("Success");
				response.setStatus(200);
				response.setObject(data);
			}else{
				response.setMessage("Failure");
				response.setStatus(201);
   		    }
			
			return response;
		} catch (Exception e) {
			e.printStackTrace();
			response.setStatus(201);
			response.setMessage("Failure");
			return response;
		}
		
	}
	
	/**
     * This method is to update the value of DOWNLOAD_COUNT column in
	 * AUTOMATION_TRACKER table with the given project name and automation name.
	 * 
     * @param projectName -- Holds project Name
     * @param automationName -- Holds automation name
     * @return RestResponse
     * @throws DataAnalyticException
     */
	@RequestMapping(value = "/updateDownloadCounter/{automationId}", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public RestResponse updateDownloadCount(@PathVariable("automationId") String automationId) throws DataAnalyticException {
		LOGGER.info("Inside updateDownloadCount()");
		AutomationTrackerData data = new AutomationTrackerData();
		RestResponse response = new RestResponse();
		try {
			data =  iDataAnalyticService.updateDownloadCount(Long.parseLong(automationId));
			
			response.setMessage("Success");
			response.setStatus(200);
			response.setObject(data);
			return response;
		} catch (Exception e) {
			e.printStackTrace();
			response.setStatus(201);
			response.setMessage("Failure");
			return response;
		}
		
	}
	
	
	
	@RequestMapping(value = "/getUserIdFromUserName/{decryptedUserName1}", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public RestResponse getUserIdFromUserName(@PathVariable("decryptedUserName1") String userName) throws DataAnalyticException {
		LOGGER.info("Inside updateDownloadCount()");
		UserData data = new UserData();
		RestResponse response = new RestResponse();
		try {
			data =  iDataAnalyticService.getUserIdFromUserName(userName);
			LOGGER.info("Inside)"+data.getUserId()+"+++++++++++++++++++++++");
			
			response.setMessage("Success");
			response.setStatus(200);
			response.setObject(data);
			return response;
		} catch (Exception e) {
			e.printStackTrace();
			response.setStatus(201);
			response.setMessage("Failure");
			return response;
		}
		
	}
	
	
	/**
	 * This method is to save the new user details in USER_DATA table.
	 * 
	 * @param user -- Holds UserData object
	 * @return RestResponse
	 * @throws DataAnalyticException
	 */
	@RequestMapping(value = "/saveRewardDetails", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public RestResponse saveRewardDetails(@RequestBody @Valid final Reward reward)throws DataAnalyticException {
		LOGGER.info("Inside createNewUser method--");
		RestResponse response = new RestResponse();
		Reward rewardData;
		try {

			 rewardData = iDataAnalyticService.findExistingReward(reward.getAutomationName(),reward.getProjectName(),reward.getContributorName());
			LOGGER.info("Inside RewardDetails Service method--"+rewardData);
			
			LOGGER.info("***********************--"+reward.getButtonval());
			
			if(reward.getButtonval().equalsIgnoreCase("save")){
				rewardData = new Reward();
				rewardData.setAutomationName(reward.getAutomationName());
				rewardData.setComment(reward.getComment());
				rewardData.setUserId(reward.getUserId());
				rewardData.setProjectName(reward.getProjectName());
				rewardData.setContributorName(reward.getContributorName());
				rewardData.setStarRating(reward.getStarRating());
				iDataAnalyticService.saveRewardData(rewardData);
				response.setStatus(200);
				response.setMessage("Success");
				return response;
			}else{
				rewardData.setRewardId(reward.getRewardId());
				response.setStatus(201);
				response.setMessage("Exists");
				response.setObject(rewardData);
				return response;
			}
			
			

		//	response.setObject(rewardData.getProjectName());

		}

		catch (Exception ex) {
			System.out.println("DataAnalyticController.createNewUser()");
			response.setStatus(201);
			response.setMessage("Failure");
			return response;

		}
	

	

	}
	
	
	
	
	
	/**
	 * This method is to save the new user details in USER_DATA table.
	 * 
	 * @param user -- Holds UserData object
	 * @return RestResponse
	 * @throws DataAnalyticException
	 */
	@RequestMapping(value = "/rewardAlreadyExist", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public RestResponse rewardAlreadyExist(@RequestBody @Valid final Reward reward)throws DataAnalyticException {
		LOGGER.info("Inside createNewUser method--");
		RestResponse response = new RestResponse();
		Reward rewardData;
		try {
			 rewardData = iDataAnalyticService.findExistingReward(reward.getAutomationName(),reward.getProjectName(),reward.getContributorName());
			LOGGER.info("Inside RewardDetails Service method--"+rewardData);

			if (null != rewardData) {
				response.setStatus(201);
				response.setMessage("Exists");
				response.setObject(rewardData);
				return response;
			} else {
				response.setStatus(200);
				response.setMessage("Not Exists");
				return response;
			}

		}
		
		

		catch (Exception ex) {
			System.out.println("DataAnalyticController.createNewUser()");
			response.setStatus(201);
			response.setMessage("Failure");
			return response;

		}

	}
	
	
	/**
	 * This method is to get all the automation Tracker records from the AUTOMATION_TRACKER table.
	 *  
	 * @return RestResponse
	 * @throws DataAnalyticException
	 */
	@RequestMapping(value = "/getAllContributorList", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public RestResponse getAllContributorList() throws DataAnalyticException {
		RestResponse response = new RestResponse();
		try {
         
			List<AutomationTrackerData> dataList = iDataAnalyticService.getAllContributorListData();
			LOGGER.info("All contribution List@@@@@@@@@@@@@@@@@@@@"+dataList);
			if (CollectionUtils.isEmpty(dataList)) {
				response.setMessage("No Data Found");
				response.setStatus(200);
				return response;
			}
			response.setMessage("Success");
			response.setStatus(200);
			response.setObject(dataList);
			return response;
		} catch (Exception e) {
			e.printStackTrace();
			throw new DataAnalyticException("Error while fetching Automation Tracker data.");
		}

	}
	
	/*@RequestMapping(value = "/getAllContributorList", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<Map<String, Object>> getAllContributorList() {	
		
		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		List<Object[]> contributorList = null;
	
	
		try {
			
			contributorList = iDataAnalyticService.getAllContributorListData1();
			
			for (int i = 0; i < contributorList.size(); i++) {

				objMap = new HashMap<String, Object>();
				objMap.put("contributorName", (contributorList.get(i))[0]);
				
				list.add(objMap);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}*/
	
	@RequestMapping(value = "/getRewardDetailsForContriutor/{contributorName}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<Map<String, Object>> getRewardDetailsForContriutor(
			@PathVariable("contributorName") String contributorName) {
		
		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		List<Object[]> contributorList = null;
	
		try {

				contributorList = iDataAnalyticService.rewardDetailsAsPerContributor(contributorName);

				for (int i = 0; i < contributorList.size(); i++) {
					objMap = new HashMap<String, Object>();
					objMap.put("businessName", (contributorList.get(i))[0]);
					objMap.put("projectName", (contributorList.get(i))[1]);
					objMap.put("contributorName", (contributorList.get(i))[2]);
					objMap.put("rewardName", (contributorList.get(i))[3]);
					objMap.put("starRating", (contributorList.get(i))[4]);
			
					
					list.add(objMap);
				}
			}
	
		catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
	

}
