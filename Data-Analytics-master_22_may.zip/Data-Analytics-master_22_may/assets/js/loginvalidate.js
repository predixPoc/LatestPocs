 
 //var myArrayNew;
 $(document).ready(function () {
	 // $('#example').DataTable();
	 
	   		         	 	
	 $("#loginId").click(function(){

		 $("#invalid-login").hide();
		 var predixurl="https://data-analytic-service-19thmay.run.aws-usw02-pr.ice.predix.io/data-analytic/login";
		 $.ajax({
		         url:predixurl,
                         type: "POST", //send it through post method
			 contentType: "application/json",
                         data :JSON.stringify({
						  userName :$("#username").val(),
						  password :$("#password").val() 
					     }),
                         success: function(responseData) {
				 console.log(responseData.status);
                	         if((responseData.status == 200)&&(responseData.message == "Success")){
                	 	      console.log("Success");
                                      var encryptedUserName = btoa($("#username").val());
                	 	      window.location="index_home.html?userName="+encryptedUserName;
                	         }else{
                	 	      console.log("Error");
                	 	      $("#invalid-login").show();
			              $("#username").val('');
			              $("#password").val('');
                	         }
				
     			},
                        error: function ( xhr, status, error) {
				
				 console.log("Error while Login");
				 $("#invalid-login").show();
			         $("#username").val('');
          		         $("#password").val('');
		        }
		});

		 /*if($("#username").val()=='Techm' && $("#password").val()=='Techm@123'){

			 window.location="index_home.html";

		 }else{

			 $("#invalid-login").show();

			 $("#username").val('');

			 $("#password").val('');

		 }*/

	 });
	 
	 
	 $("#automationId").click(function(){
                window.location="index_home.html?userName="+encryptedUserName;
		 
	 });
	 
	 
	 
	  $("#workId").click(function(){
		window.location="index_home.html?userName="+encryptedUserName;
		 
	 });
	 
	 $("#serviceId").click(function(){
		window.location="index_home.html?userName="+encryptedUserName;
		 
	 });
	 
	  $("#homeId").click(function(){
		window.location="index_home.html?userName="+encryptedUserName;
		 
	 });
	 
	 
	  $("#teamId").click(function(){
		window.location="index_home.html?userName="+encryptedUserName;
		 
	 });

         $("#registerXbtn").click(function(){
            $("#errorDiv").hide();
            $("#userName").val('');
            $("#email").val('');
            $("#phone").val('');
            $("#pass").val('');
            $("#confirmPassword").val('');
         });

         $("#registerCloseBtn").click(function(){
            $("#errorDiv").hide();
            $("#userName").val('');
            $("#email").val('');
            $("#phone").val('');
            $("#pass").val('');
            $("#confirmPassword").val('');
         });

         $("#registerId").click(function(){
	      var userName=$("#userName").val();
              var emailId=$("#email").val();
              var phone=$("#phone").val();
              var password=$("#pass").val();
              var confirmPassword=$("#confirmPassword").val();
              
              var userNameRegExp=/^[a-zA-Z]+$/;
              var emailRegExp=/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
              var phoneRegExp=/^[0-9]+$/;
              var pwdRegExp=/^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{8,}$/;

              var errorMessage="<ul>";
              if(userName==null || userName==''){
                  errorMessage=errorMessage+"<li>User Name is required.</li>";
              }else if(!(userName.match(userNameRegExp))){
                  errorMessage=errorMessage+"<li>User Name should have only alphabets.</li>";
              }
              if(emailId==null || emailId==''){
                  errorMessage=errorMessage+"<li>Email id is required.</li>";
              }else if(!(emailId.match(emailRegExp))){
                 errorMessage=errorMessage+"<li>Invalid email id.</li>";
              }

              if(phone==null || phone==''){
                  errorMessage=errorMessage+"<li>Phone number is required.</li>";
              }else if(!(phone.match(phoneRegExp))){
                 errorMessage=errorMessage+"<li>Phone number should have only digits.</li>";
              }else if(phone.length < 10){
                  errorMessage=errorMessage+"<li>Phone number must contains 10 digits.</li>";
              }
              
              if(password==null || password==''){
                  errorMessage=errorMessage+"<li>Password is required.</li>";
              }else if(!(password.match(pwdRegExp))){
                 errorMessage=errorMessage+"<li>Invalid Password.</li>";
              }
              if(confirmPassword==null || confirmPassword==''){
                  errorMessage=errorMessage+"<li>Confirm Password is required.</li>";
              }else if(!(confirmPassword.match(pwdRegExp))){
                 errorMessage=errorMessage+"<li>Invalid Confirm Password.</li>";
              }
              
              if((password!=null || password!='') && (confirmPassword!=null || confirmPassword!='') ){
                   if(!(password == confirmPassword)){
                      errorMessage=errorMessage+"<li>Password & Confirm Password must be same.</li>";
                   }
              }
              errorMessage=errorMessage+"</ul>";

		//alert( errorMessage);
              if(!(errorMessage=="<ul></ul>")){
                  $("#errorDiv").show();
                  $("#errorDiv").css("background-color", "rgba(255, 0, 0, 0.45)");
                  $("#errorDiv").html(errorMessage);
              }else{

                  var predixurl="https://data-analytic-service-19thmay.run.aws-usw02-pr.ice.predix.io/data-analytic/saveUserRegistration";
	          $.ajax({
		       url:predixurl,
                       type: "POST", //send it through post method
		       contentType: "application/json",
                       data :JSON.stringify({
						  userName :$("#userName").val(),
						  email :$("#email").val(),
                                                  phone:$("#phone").val(),
                                                  password: $("#pass").val(),
                                                  confirmPassword: $("#confirmPassword").val(),
					    }),
                       success: function(responseData) {
				 console.log(responseData.status);
                	         if((responseData.status == 200)&&(responseData.message == "Success")){
                	 	     console.log("Success");
                                     var encryptedUserName = btoa($("#userName").val());
                	 	     window.location="index_home.html?userName="+encryptedUserName;
                	         }else{
                	 	     console.log("Error");
                	 	     $("#errorDiv").show();
                                     $("#errorDiv").css("background-color", "red");
                                     $("#errorDiv").html("Error while doing Registration");
			            
                	         }
				
     		       },
                       error: function ( xhr, status, error) {
				
				 console.log("Error while doing registration.");
				
	               }
		});
            }//end of else

	 });
	 
	 
	 
 });
