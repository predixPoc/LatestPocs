var rfpTableHeader;
var rfpjsonData;

	rfpjsonData={
	"data": [{
		"serialNum": 1,
		"opportunityName": "Asia Bank Reconciliation Automation",
		"crmId": 1,
		"highLevelSummary": "Automate the cash/account reconciliation process for the Global Ops Asia center.",
		"opportunityCategory": "RFP",
		"receivedDate": "27-07-2017",
		"submittedDate": "1-08-2017",
		"programManagerName": "Dillip.Nayak@TechMahindra.com",
		"brmName": "Srinivas.Burra@TechMahindra.com",
		"rfpDoc": "Asia_Bank_Reconciliation_RFP.zip",
		"proposalDoc": "Asia_Bank_Reconciliation_Proposal.zip"
	}]
};
$(document).ready(function () {

	        var queryParam = window.location.search.substring(1);
        var userName=queryParam.split("userName=");
        userType=queryParam.split("userType=")[1].trim();				
        encryptedUserName = userName[1].substring(0,userName[1].indexOf("&"));
            if(queryParam.includes("userName")){
				
            }else{
               //alert("Restrict");
               window.location="index.html";
            }
	
	
	rfpTableHeader = [
                { "sTitle": "S.No", "mData": "serialNum" },
                { "sTitle": "Opportunity Name", "mData": "opportunityName" },
                { "sTitle": "CRM ID", "mData": "crmId" },
				{ "sTitle": "High-level summary", "mData": "highLevelSummary" },
				{ "sTitle": "Opportunity Category", "mData": "opportunityCategory" },
				{ "sTitle": "Received Date", "mData": "receivedDate" },
				{ "sTitle": "Submitted Date", "mData": "submittedDate" },
                { "sTitle": "Program Manager Name", "mData": "programManagerName" },
				{ "sTitle": "BRM Name", "mData": "brmName" },
				{ "sTitle": "RFP Document", "mData": "rfpDoc" },
				{ "sTitle": "Proposal Document", "mData": "proposalDoc"}
              ];

	 $("#automationId").click(function(){
         window.location="automationTraker.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 $("#workId").click(function(){
		window.location="index_home.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 $("#serviceId").click(function(){
		window.location="reuseTracker.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 $("#homeId").click(function(){
		window.location="index_home.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 $("#teamId").click(function(){
		window.location="teamInfoLink.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	   $("#demographicsId").click(function(){
		window.location="demographics.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 $("#contributorIdList").click(function(){
				window.location.href="contributorList.html?userName="+encryptedUserName+"&userType="+userType;		 
	 });
	  $("#rfpId").click(function(){
				window.location.href="rfpcolleteral.html?userName="+encryptedUserName+"&userType="+userType;
	  })

	 
	    $('#rfpTable').dataTable({         
         "aaData": rfpjsonData.data,
         dom: 'lBfrtip',
         "bFilter" : true, 
	     "bPaginate": true,
	     "lengthMenu": [5,10,15,20,25],
         buttons: ['excel' , 'print','copyHtml5'],
         "language": {
		   "emptyTable": "No data available in table"
	     },
         // "scrollY": 200,
         "scrollX": true,
         "aoColumns":rfpTableHeader,
		 columnDefs: [
			   {
             
                  "render": function ( data, type, row ) {
                 	 if(data == '' || data == null){
					    return data;
					 }else{
					    return data = '<a href="assets/rfpdocs/'+data+'"><img src="assets/img/zipIcon.png"/>&nbsp;' + data + '</a>';
					 }
                  },
                  "targets": 9
                },
				 {
             
                  "render": function ( data, type, row ) {
                 	 if(data == '' || data == null){
					    return data;
					 }else{
					    return data = '<a href="assets/rfpdocs/'+data+'"><img src="assets/img/zipIcon.png"/>&nbsp;' + data + '</a>';
					 }
                  },
                  "targets": 10
                }
		        ]
		
    }); 

 });


