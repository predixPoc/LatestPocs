 $(document).ready(function () {
		var queryParam = window.location.search.substring(1);
        var userName=queryParam.split("userName=");
        userType=queryParam.split("userType=")[1].trim();				
        encryptedUserName = userName[1].substring(0,userName[1].indexOf("&"));
		
		$("#automationId").click(function(){
        window.location="automationTraker.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 
	 $("#contributorIdList").click(function(){
				window.location.href="contributorList.html?userName="+encryptedUserName+"&userType="+userType;
				
		 
	 });
	 
	 $("#workId").click(function(){
		window.location="index_home.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 
	 
	 $("#serviceId").click(function(){
		window.location="reuseTracker.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 $("#homeId").click(function(){
		window.location="index_home.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	
	 
	$("#demographicsId").click(function(){
		window.location="demographics.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 $("#teamId").click(function(){
		window.location="teamInfoLink.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	  $("#rfpId").click(function(){
				window.location.href="rfpcolleteral.html?userName="+encryptedUserName+"&userType="+userType;
	  })
	 
 });