 var encryptedUserName="";
 var userType;
 var reuseprojectName;
 var reuseSummary;
 var reuseContactPersonName;
 var reuseAutomationName;
 var reuseExcelDownloadId;
 var reusedownloadCount;
 var reusedownloadCountval;
 $(document).ready(function () {
		$("#loadingDiv").show();
	$(window).on('load', function(){
	        var queryParam = window.location.search.substring(1);
        var userName=queryParam.split("userName=");
        userType=queryParam.split("userType=")[1].trim();				
        encryptedUserName = userName[1].substring(0,userName[1].indexOf("&"));
            if(queryParam.includes("userName")){
				
				showReuseTableData();
				
			
            }else{
               //alert("Restrict");
               window.location="index.html";
            }
	});//End of onload()
	
	reuseArrayHeader = [
                { "sTitle": "S.No", "mData": "serialNum" },
                { "sTitle": "Business Name", "mData": "businessName" },
                { "sTitle": "Project Name", "mData": "projectName" },
				{ "sTitle": "Reusable Component Name", "mData": "reuseComponentName" },
				{ "sTitle": "Summary", "mData": "summary" },
				{ "sTitle": "Technology", "mData": "technology" },
				{ "sTitle": "Saving To GE ($)", "mData": "savingToGE" },
                { "sTitle": "Can be Reused", "mData": "reused" },
				{ "sTitle": "Contact Person", "mData": "contactPerson" },
				{ "sTitle": "Artefacts", "mData": "uploadedFileName" },
				{ "sTitle": "Total Download", "mData": "downloadCounter"},
				{ "sTitle": "ReuseUseId", "mData": "reuseId" ,"visible": false}
              ]

	 $("#automationId").click(function(){
         window.location="automationTraker.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 $("#workId").click(function(){
		window.location="index_home.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 $("#serviceId").click(function(){
		window.location="reuseTracker.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 $("#homeId").click(function(){
		window.location="index_home.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 $("#teamId").click(function(){
		window.location="teamInfoLink.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	   $("#demographicsId").click(function(){
		window.location="demographics.html?userName="+encryptedUserName+"&userType="+userType;
	 });
	 
	 $("#contributorIdList").click(function(){
				window.location.href="contributorList.html?userName="+encryptedUserName+"&userType="+userType;		 
	 });
	  $("#rfpId").click(function(){
				window.location.href="rfpcolleteral.html?userName="+encryptedUserName+"&userType="+userType;
	  })
	 
	
	
	 
	 
  $("#ratingId").rating();
   $("#ratingId").rating("update", 0);	 
	 
	 
	 
 });


function showReuseTableData(){

var predixurl="https://data-analytic-service-25thmay.run.aws-usw02-pr.ice.predix.io/data-analytic/getReuseData";
		        $.ajax({
		             url:predixurl,
                     type: "GET", //send it through GET method
                     success: function(responseData) {
                        console.log(responseData.status);
						$("#loadingDiv").hide();
                        if(responseData.object.length > 0){
                           showReuseTable(responseData.object);
                        }
     		         },
                     error: function ( xhr, status, error) {
				       console.log("Error while fetching Automation tracker data.");
	                 }
		        });

}

  
function showReuseTable(jsonData){
    $('#reuseTable').addClass( 'nowrap' ).dataTable({
         "rowCallback": function( row, data, index ) {
            if(index%2 == 0){
                $(row).removeClass('myodd myeven');
                $(row).addClass('myodd');
            }else{
                $(row).removeClass('myodd myeven');
                 $(row).addClass('myeven');
            }
         },
         "aaData": jsonData,
         dom: 'lBfrtip',
         "bFilter" : true, 
	     "bPaginate": true,
	     "lengthMenu": [5,10,15,20,25],
         buttons: ['excel' , 'print','copyHtml5'],
         "language": {
		   "emptyTable": "No data available in table"
	     },
         // "scrollY": 200,
         "scrollX": true,
         "aoColumns":reuseArrayHeader,
		 columnDefs: [
			   { targets: 4, render: $.fn.dataTable.render.ellipsis( 60, true ) },
			   { targets: 7, render: $.fn.dataTable.render.ellipsis( 30 ) },
			   {
                 "render": function ( data, type, row ) {
                 	 if(data == ''){
					 
					    return data;
					 }else{
					    if(data=='Reuse Case studies'){
					    return data = '<a href="assets/ppt/'+data+'.pps"><img src="assets/img/file-icon.jpg"/>&nbsp;' + data + '</a>';
						}else{
							 return data = '<a href="assets/ppt/'+data+'.pptx"><img src="assets/img/file-icon.jpg"/>&nbsp;' + data + '</a>';
						}
					 }
                 },
                 "targets": 9
                },
				
				 {
                  "render": function ( data, type, row ) {
                 	  if(data == '' || data == null){
					    return data;
					  }else{
						return data = '<a  data-toggle="modal" href="#" data-target="#reUseModal">' + data + '</a>';
					  }
                   },
                   "targets": 3
                },
				
				
				
		    ]
    }); 
    $('#reuseTable_length').find('label').css({"margin-left": "0px"});
    $('#reuseTable_length').find('label').css({"color": "black"});
    $('#reuseTable_filter').addClass("pull-right");
    $('#reuseTable_filter').find('label').css({"color": "black"});
	jQuery('.dataTable').wrap('<div class="dataTables_scroll" />');
	
	 var table = $('#reuseTable').DataTable();
	$('#reuseTable tbody').on( 'click', 'tr td:nth-child(4)', function () {
		
		reuseprojectName = table.row($(this)).data().projectName;
		reuseSummary=table.row($(this)).data().summary;
		reuseContactPersonName=table.row($(this)).data().contactPerson;
		reuseAutomationName=table.row($(this)).data().reuseComponentName;
		reusedownloadCountval=table.row($(this)).data().downloadCounter;
		//alert();
	//contributorNamevar=table.row($(this)).data().contributorName;
	//slnovar=table.row($(this)).data().serialNum;
	//automationNameVar=table.row($(this)).data().automationName;
	//businessNamevar=table.row($(this)).data().businessName;
	//contactPersonNamevar=table.row($(this)).data().contactPerson;
	//fileNameVar=table.row($(this)).data().uploadedFileName;
	//automationIdvar=table.row($(this)).data().automationId;
		showRowData();
	} );
	
	$('#reuseTable tbody').on( 'click', 'tr td:nth-child(10)', function () {
		reuseExcelDownloadId=table.row($(this)).data().reuseId;
		reusedownloadCount=table.row($(this)).data().downloadCounter;
		updateDownloadCount(reuseExcelDownloadId);
		var cell = table.cell(this);
		var cell2 = table.cell(cell.index().row,cell.index().column+1);
		cell2.data( cell2.data() + 1 ).draw();

	
	} );
	
} 
function showRowData() {
		 // var contributorName = contributorNamevar;
		//  var projectName =projectNamevar;
         // var automationName = automationNameVar;
		   		// var predixurl="https://data-analytic-service-25thmay.run.aws-usw02-pr.ice.predix.io/data-analytic/rewardAlreadyExist";
			/*	$.ajax({
						url:predixurl,
                         type: "POST", //send it through post method
						contentType: "application/json",
						data :JSON.stringify({
						  automationName :automationNameVar,
						  projectName : projectNamevar,
						  contributorName:contributorNamevar,
						  userId:userId,
					     }),
						
                         success: function(responseData) {
						
						
                	         if((responseData.status == 201)&&(responseData.message == "Exists")){
                	 	     
                                  $("#contributorFeedBackId").prop('value', 'update');
								  $("#commentId").html(responseData.object.comment);
								  
                	         }else{
								 $("#contributorFeedBackId").prop('value', 'save');
								 $("#commentId").html('');
                	         }
				
     			},
                 error: function ( xhr, status, error) {
				 console.log("Error while Login");
				 
		        }
		});*/
		/* if(automationIdvar!=''){
			   totalCount(automationIdvar);
		   }*/
		  
          // var businessName = $(this).children('td').eq(1).text();
		  
		  // var summary = summaryArray[slnovar];
		  // var fileName=$(this).children('td').eq(11).text();
		  
		   
		   $('#projectName').html(reuseprojectName);
		 $('#automationName').html(reuseAutomationName);
		   $('#summaryId').html(reuseSummary);
		  $('#pptFileId').html(reusedownloadCountval);
		  // $('#contributorId').html(contributorNamevar);
		  // if(fileNameVar != '' ){
		  // }else{
		  //    $('#pptFileId').html('');
		 //  }
		  $('#contactPersonID').html(reuseContactPersonName);
                        
        //});
    //});
	
}
function updateDownloadCount(reuseExcelDownloadId){
			 if(reuseExcelDownloadId!=''){
		        var predixurl="https://data-analytic-service-25thmay.run.aws-usw02-pr.ice.predix.io/data-analytic/updateDownloadCountForReuse/"+reuseExcelDownloadId;
		        $.ajax({
		             url:predixurl,
                     type: "GET", //send it through GET method
                     success: function(responseData) {
						   
                        console.log(responseData.status);
                        if(responseData.status == 200 && responseData.message=="Success"){
						   // totalCount(automationId);
                        }
     		         },
                     error: function ( xhr, status, error) {
				        console.log("Error while updating download count in Automation_Tracker table.");
	                }
		       });
		     }
			 
        // });
    //});
} // End of updateDownloadCount()
