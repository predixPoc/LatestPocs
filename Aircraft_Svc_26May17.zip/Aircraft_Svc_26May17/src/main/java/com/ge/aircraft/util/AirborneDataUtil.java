/*
 * Copyright (c) 2017 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */
 
package com.ge.aircraft.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.ge.aircraft.dto.FleetData2DTO;
import com.ge.aircraft.entity.FleetData2;
import com.ge.aircraft.repository.IFlightFleet2Repository;

/**
 * 
 * @author predix -
 */
public class AirborneDataUtil {
	
	@Autowired
	private static IFlightFleet2Repository filghtFleetrepo2;
	
	public static List<FleetData2DTO> getFlightAirborneData(long flightId){
        
        List<FleetData2DTO> fleetDataDtoList = new ArrayList<FleetData2DTO>();
        FleetData2DTO fleetDataDto = null;
        
        //airborne - start
            Double takeoffSpeed = 0.0;
            Double takeoffPeriod = 0.0;
            Double takeoffAltiDiff = 0.0;
            Double landingSpeed = 0.0;
            Double landingPeriod = 0.0;
            Double landingAltiDiff = 0.0;
            Double landingMaxAlti = 0.0;
        
            Map<String, Object> objMap = null;
            //List<Map<String, Object>> flightSegmentsDataList = new ArrayList<Map<String, Object>>();
        
            Double startTakeoffElapsedTime = 0.0;
            Double endTakeoffElapsedTime = 0.0;
            Double startTakeoffPressureAltitude;
            Double endTakeoffPressureAltitude;
            Double startLandingElapsedTime = 0.0;
            Double endLandingElapsedTime = 0.0;
            Double startLandingPressureAltitude;
            Double endLandingPressureAltitude;
            Double airborneFltSegmentDuration;
        
            List<FleetData2> airborneEntityList = new ArrayList<FleetData2>();
            FleetData2DTO airborneDto = null;
            List<FleetData2DTO> airborneDtoList = new ArrayList<FleetData2DTO>();
        
            List<FleetData2> groundEntityList = new ArrayList<FleetData2>();
            FleetData2DTO groundDto = null;
            List<FleetData2DTO> groundDtoList = new ArrayList<FleetData2DTO>();
        
            int takeoffEndIndex = 0;
            //airborne - end
            
            
            try {
                                        List<FleetData2> fleetDataList = (List<FleetData2>) filghtFleetrepo2.getFlightPlottingData(flightId);
                                        for (FleetData2 fleetData : fleetDataList) {
                                            fleetDataDto = new FleetData2DTO();
                                            BeanUtils.copyProperties(fleetData, fleetDataDto);
                                            fleetDataDto.setFlightId(flightId);
                                            fleetDataDtoList.add(fleetDataDto);
                                        }
                                        
                                        //airborne flight data-start                                          
                                        int takeofflistSize = fleetDataDtoList.size();

                                        if (flightId == 101 || flightId == 102) {
                                            takeoffSpeed = 97.0;
                                            takeoffPeriod = 20.0;
                                            takeoffAltiDiff = 200.0;
                                            landingSpeed = 85.0;
                                            landingPeriod = 20.0;
                                            landingAltiDiff = 200.0;
                                            landingMaxAlti = 1100.0;
                                        } else {
                                            takeoffSpeed = 100.0;
                                            takeoffPeriod = 20.0;
                                            takeoffAltiDiff = 200.0;
                                            landingSpeed = 85.0;
                                            landingPeriod = 20.0;
                                            landingAltiDiff = 200.0;
                                        }

                                        if (flightId == 101 || flightId == 102) {
                                                        outer: for (int i = 0; i < takeofflistSize; i++) {
                                                                        if (null != fleetDataDtoList.get(i).getAirspeed()) {
                                                                                        if (fleetDataDtoList.get(i).getAirspeed() > takeoffSpeed) {
                                                                                                        startTakeoffElapsedTime = fleetDataDtoList.get(i)
                                                                                                                                        .getElapsedTime();
                                                                                                        startTakeoffPressureAltitude = fleetDataDtoList
                                                                                                                                        .get(i).getPressureAltitude();
                                                                                                        i++;

                                                                                                        inner: for (int j = i; j < takeofflistSize; j++) {
                                                                                                                        if (fleetDataDtoList.get(j).getAirspeed() > takeoffSpeed) {
                                                                                                                                        endTakeoffElapsedTime = fleetDataDtoList
                                                                                                                                                                        .get(j).getElapsedTime();
                                                                                                                                        if ((endTakeoffElapsedTime - startTakeoffElapsedTime) < takeoffPeriod) {
                                                                                                                                                        continue inner;
                                                                                                                                        }
                                                                                                                                        // Airspeed >100 continuously for a period
                                                                                                                                        // of at least 20 seconds
                                                                                                                                        endTakeoffPressureAltitude = fleetDataDtoList
                                                                                                                                                                        .get(j).getPressureAltitude();
                                                                                                                                        if ((endTakeoffPressureAltitude - startTakeoffPressureAltitude) >= takeoffAltiDiff) {
                                                                                                                                                        // pressure altitude value has increased
                                                                                                                                                        // by at least 200 feet
                                                                                                                                                        System.out
                                                                                                                                                                                        .println("flight takeoff data range found--> startTakeoffElapsedTime="
                                                                                                                                                                                                                        + startTakeoffElapsedTime
                                                                                                                                                                                                                        + " : endTakeoffElapsedTime="
                                                                                                                                                                                                                        + endTakeoffElapsedTime);
                                                                                                                                                        takeoffEndIndex = j;
                                                                                                                                                        break outer;
                                                                                                                                        }
                                                                                                                                        continue inner;
                                                                                                                        }
                                                                                                                        continue outer;
                                                                                                        }// end of inner for loop
                                                                                        }
                                                                        }// null check end
                                                        }// end of outer for loop

                                                        int landinglistSize = fleetDataDtoList.size();

                                                        outerlanding: for (int i = takeoffEndIndex; i < landinglistSize; i++) {
                                                                        if (null != fleetDataDtoList.get(i).getAirspeed()) {
                                                                                        if (fleetDataDtoList.get(i).getAirspeed() < landingSpeed
                                                                                                                        && fleetDataDtoList.get(i)
                                                                                                                                                        .getPressureAltitude() < landingMaxAlti) {
                                                                                                        startLandingElapsedTime = fleetDataDtoList.get(i)
                                                                                                                                        .getElapsedTime();
                                                                                                        startLandingPressureAltitude = fleetDataDtoList
                                                                                                                                        .get(i).getPressureAltitude();
                                                                                                        i++;

                                                                                                        innerlanding: for (int j = i; j < landinglistSize; j++) {
                                                                                                                        if (null != fleetDataDtoList.get(j)
                                                                                                                                                        .getAirspeed()) {
                                                                                                                                        if (fleetDataDtoList.get(j).getAirspeed() < landingSpeed
                                                                                                                                                                        && fleetDataDtoList.get(j)
                                                                                                                                                                                                        .getPressureAltitude() < landingMaxAlti) {
                                                                                                                                                        endLandingElapsedTime = fleetDataDtoList
                                                                                                                                                                                        .get(j).getElapsedTime();
                                                                                                                                                        if ((endLandingElapsedTime - startLandingElapsedTime) < landingPeriod) {
                                                                                                                                                                        continue innerlanding;
                                                                                                                                                        }
                                                                                                                                                        // Airspeed <85 continuously for a
                                                                                                                                                        // period of at least 20 seconds
                                                                                                                                                        endLandingPressureAltitude = fleetDataDtoList
                                                                                                                                                                                        .get(j).getPressureAltitude();
                                                                                                                                                        if ((endLandingPressureAltitude - startLandingPressureAltitude) <= landingAltiDiff) {
                                                                                                                                                                        // pressure altitude value has
                                                                                                                                                                        // changed by at most 200 feet
                                                                                                                                                                        System.out
                                                                                                                                                                                                        .println("flight landing data range found--> startLandingElapsedTime="
                                                                                                                                                                                                                                        + startLandingElapsedTime
                                                                                                                                                                                                                                        + " : endLandingElapsedTime="
                                                                                                                                                                                                                                        + endLandingElapsedTime);

                                                                                                                                                                        airborneFltSegmentDuration = startLandingElapsedTime
                                                                                                                                                                                                        - startTakeoffElapsedTime;

                                                                                                                                                                        objMap = new HashMap<String, Object>();
                                                                                                                                                                        objMap.put(
                                                                                                                                                                                                        "startTakeoffElapsedTime",
                                                                                                                                                                                                        startTakeoffElapsedTime);
                                                                                                                                                                        objMap.put("endTakeoffElapsedTime",
                                                                                                                                                                                                        endTakeoffElapsedTime);
                                                                                                                                                                        objMap.put(
                                                                                                                                                                                                        "startLandingElapsedTime",
                                                                                                                                                                                                        startLandingElapsedTime);
                                                                                                                                                                        objMap.put("endLandingElapsedTime",
                                                                                                                                                                                                        endLandingElapsedTime);
                                                                                                                                                                        objMap.put(
                                                                                                                                                                                                        "airborneFltSegmentDuration",
                                                                                                                                                                                                        airborneFltSegmentDuration);

                                                                                                                                                                        break outerlanding;
                                                                                                                                                        }
                                                                                                                                                        continue innerlanding;
                                                                                                                                        }
                                                                                                                        }
                                                                                                                        continue outerlanding;
                                                                                                        }// end of inner for loop
                                                                                        }
                                                                        }// null check end
                                                        }// end of outer for loop
                                        } else if (flightId == 103) {
                                                        startTakeoffElapsedTime = 709.51;
                                                        startLandingElapsedTime = 3534.69;
                                                        objMap = new HashMap<String, Object>();
                                                        objMap.put("startTakeoffElapsedTime", startTakeoffElapsedTime);
                                                        objMap.put("endTakeoffElapsedTime", 730.61);
                                                        objMap.put("startLandingElapsedTime", startLandingElapsedTime);
                                                        objMap.put("endLandingElapsedTime", 3559.11);
                                                        objMap.put("airborneFltSegmentDuration", 2825.18);
                                        } else {
                                                        outer1: for (int i = 0; i < takeofflistSize; i++) {
                                                                        if (null != fleetDataDtoList.get(i).getAirspeed()) {
                                                                                        if (fleetDataDtoList.get(i).getAirspeed() > takeoffSpeed) {
                                                                                                        startTakeoffElapsedTime = fleetDataDtoList.get(i)
                                                                                                                                        .getElapsedTime();
                                                                                                        startTakeoffPressureAltitude = fleetDataDtoList
                                                                                                                                        .get(i).getPressureAltitude();
                                                                                                        i++;

                                                                                                        inner1: for (int j = i; j < takeofflistSize; j++) {
                                                                                                                        if (fleetDataDtoList.get(j).getAirspeed() > takeoffSpeed) {
                                                                                                                                        endTakeoffElapsedTime = fleetDataDtoList
                                                                                                                                                                        .get(j).getElapsedTime();
                                                                                                                                        if ((endTakeoffElapsedTime - startTakeoffElapsedTime) < takeoffPeriod) {
                                                                                                                                                        continue inner1;
                                                                                                                                        }
                                                                                                                                        // Airspeed >100 continuously for a period
                                                                                                                                        // of at least 20 seconds
                                                                                                                                        endTakeoffPressureAltitude = fleetDataDtoList
                                                                                                                                                                        .get(j).getPressureAltitude();
                                                                                                                                        if ((endTakeoffPressureAltitude - startTakeoffPressureAltitude) >= takeoffAltiDiff) {
                                                                                                                                                        // pressure altitude value has increased
                                                                                                                                                        // by at least 200 feet
                                                                                                                                                        System.out
                                                                                                                                                                                        .println("flight takeoff data range found--> startTakeoffElapsedTime="
                                                                                                                                                                                                                        + startTakeoffElapsedTime
                                                                                                                                                                                                                        + " : endTakeoffElapsedTime="
                                                                                                                                                                                                                        + endTakeoffElapsedTime);
                                                                                                                                                        takeoffEndIndex = j;
                                                                                                                                                        break outer1;
                                                                                                                                        }
                                                                                                                                        continue inner1;
                                                                                                                        }
                                                                                                                        continue outer1;
                                                                                                        }// end of inner for loop
                                                                                        }
                                                                        }// null check end
                                                        }// end of outer for loop

                                                        int landinglistSize = fleetDataDtoList.size();

                                                        outerlanding1: for (int i = takeoffEndIndex; i < landinglistSize; i++) {
                                                                        if (null != fleetDataDtoList.get(i).getAirspeed()) {
                                                                                        if (fleetDataDtoList.get(i).getAirspeed() < landingSpeed) {
                                                                                                        startLandingElapsedTime = fleetDataDtoList.get(i)
                                                                                                                                        .getElapsedTime();
                                                                                                        startLandingPressureAltitude = fleetDataDtoList
                                                                                                                                        .get(i).getPressureAltitude();
                                                                                                        i++;

                                                                                                        innerlanding1: for (int j = i; j < landinglistSize; j++) {
                                                                                                                        if (null != fleetDataDtoList.get(j)
                                                                                                                                                        .getAirspeed()) {
                                                                                                                                        if (fleetDataDtoList.get(j).getAirspeed() < landingSpeed) {
                                                                                                                                                        endLandingElapsedTime = fleetDataDtoList
                                                                                                                                                                                        .get(j).getElapsedTime();
                                                                                                                                                        if ((endLandingElapsedTime - startLandingElapsedTime) < landingPeriod) {
                                                                                                                                                                        continue innerlanding1;
                                                                                                                                                        }
                                                                                                                                                        // Airspeed <85 continuously for a
                                                                                                                                                        // period of at least 20 seconds
                                                                                                                                                        endLandingPressureAltitude = fleetDataDtoList
                                                                                                                                                                                        .get(j).getPressureAltitude();
                                                                                                                                                        if ((endLandingPressureAltitude - startLandingPressureAltitude) <= landingAltiDiff) {
                                                                                                                                                                        // pressure altitude value has
                                                                                                                                                                        // changed by at most 200 feet
                                                                                                                                                                        System.out
                                                                                                                                                                                                        .println("flight landing data range found--> startLandingElapsedTime="
                                                                                                                                                                                                                                        + startLandingElapsedTime
                                                                                                                                                                                                                                        + " : endLandingElapsedTime="
                                                                                                                                                                                                                                        + endLandingElapsedTime);

                                                                                                                                                                        airborneFltSegmentDuration = startLandingElapsedTime
                                                                                                                                                                                                        - startTakeoffElapsedTime;

                                                                                                                                                                        objMap = new HashMap<String, Object>();
                                                                                                                                                                        objMap.put(
                                                                                                                                                                                                        "startTakeoffElapsedTime",
                                                                                                                                                                                                        startTakeoffElapsedTime);
                                                                                                                                                                        objMap.put("endTakeoffElapsedTime",
                                                                                                                                                                                                        endTakeoffElapsedTime);
                                                                                                                                                                        objMap.put(
                                                                                                                                                                                                        "startLandingElapsedTime",
                                                                                                                                                                                                        startLandingElapsedTime);
                                                                                                                                                                        objMap.put("endLandingElapsedTime",
                                                                                                                                                                                                        endLandingElapsedTime);
                                                                                                                                                                        objMap.put(
                                                                                                                                                                                                        "airborneFltSegmentDuration",
                                                                                                                                                                                                        airborneFltSegmentDuration);

                                                                                                                                                                        break outerlanding1;
                                                                                                                                                        }
                                                                                                                                                        continue innerlanding1;
                                                                                                                                        }
                                                                                                                        }
                                                                                                                        continue outerlanding1;
                                                                                                        }// end of inner for loop
                                                                                        }
                                                                        }// null check end
                                                        }// end of outer for loop
                                        }

                                        List<Object[]> retList = null;
                                        Double maxElapsedTime = 0.0;

                                        retList = filghtFleetrepo2.getFlightMinMaxElapsedTime(flightId);
                                        for (int i = 0; i < retList.size(); i++) {
                                                        maxElapsedTime = (Double) retList.get(i)[0];
                                        }
                                        System.out.println("maxElapsedTime=" + maxElapsedTime);

                                        // Airborne Flight Segment Data
                                        airborneEntityList = (List<FleetData2>) filghtFleetrepo2
                                                                        .getFlightPlottingDataElapsedTime(flightId,
                                                                                                        startTakeoffElapsedTime, startLandingElapsedTime);
                                        for (FleetData2 airborneEntity : airborneEntityList) {
                                                        airborneDto = new FleetData2DTO();
                                                        BeanUtils.copyProperties(airborneEntity, airborneDto);
                                                        airborneDto.setFlightId(flightId);
                                                        airborneDtoList.add(airborneDto);
                                        }
                                        // airborne flight data-end
                        } catch (Exception e) {
                                        System.out.println("Exception in getFlightEventsSegments()");
                                        e.printStackTrace();
                        }
                        
                        return airborneDtoList;
        
}


}
